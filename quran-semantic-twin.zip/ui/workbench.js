'use strict';
// Presentation and navigation only. Source data and analytical records remain immutable.
(function(){
 const icons={home:'M3 10 12 3l9 7v10H3Z M9 20v-7h6v7',names:'M8 6a2 2 0 1 0-4 0 2 2 0 0 0 4 0 M20 7a2 2 0 1 0-4 0 2 2 0 0 0 4 0 M14 19a2 2 0 1 0-4 0 2 2 0 0 0 4 0 M8 7l8 0 M7 8l4 9 M17 9l-4 8',semantic:'M4 5h6v6H4Z M15 14h6v6h-6Z M10 8h8v6 M7 11v6h8',reading:'M12 5C8 2 4 3 2 4v15c4-2 7-1 10 1 3-2 6-3 10-1V4c-4-1-7-2-10 1Z M12 5v15',studies:'M4 4h12v15H4Z M8 8h5 M8 12h5 M16 7h4v15H8v-3',model:'m12 2 10 6-10 6L2 8Z M2 12l10 6 10-6 M2 16l10 6 10-6',word:'M3 6h10 M8 3v3 M5 6c0 6 4 9 8 11 M12 6c-1 5-4 9-9 11 M14 21l4-11 4 11 M16 17h4',network:'M12 3v5 M4 9l5 3 M20 9l-5 3 M7 20l3-5 M17 20l-3-5 M15 12a3 3 0 1 0-6 0 3 3 0 0 0 6 0',surahs:'M4 3h16v18H4Z M8 7h8 M8 12h8 M8 17h5',journal:'M4 20l1-5L17 3l4 4L9 19Z M14 6l4 4',method:'M12 3 3 7v6c0 4 4 7 9 9 5-2 9-5 9-9V7Z M12 8v6 M12 17h.01',archive:'M3 3h18v5H3Z M5 8v13h14V8 M9 12h6'};
 const icon=(name,cls='')=>`<svg class="ui-icon ${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[name]||icons.archive}"/></svg>`;
 const groups=[['استكشف',['home','names','semantic','network']],['اقرأ وقارن',['reading','studies','word','surahs']],['النموذج والبحث',['model','journal','method']]];
 let menuOpen=false,expanded=null,expandOpener=null,searchOpener=null,searchItems=[],activeSearch=-1,queryTimer,searchNavigating=false,drawnQuery='',inerted=[],menuInerted=[];
 const mobile=matchMedia('(max-width:900px)');
 function navItem(id){const label=pages.find(p=>p[0]===id)?.[1]||id;return `<button class="nav-button ${state.page===id?'active':''}" data-page="${id}" ${state.page===id?'aria-current="page"':''}>${icon(id)}<span>${E(label)}</span>${id==='names'?'<span class="nav-tag">شبكة</span>':''}</button>`;}
 function navigation(){return groups.map(([title,ids])=>`<section class="nav-group"><h2>${title}</h2>${ids.map(navItem).join('')}</section>`).join('')+`<details class="nav-group nav-archive" ${['systems','relations','claims'].includes(state.page)?'open':''}><summary>${icon('archive')}<span>الإصدار الأول</span></summary>${['systems','relations','claims'].map(navItem).join('')}</details>`;}
 function setMenu(open,restore=true){for(const [el,was] of menuInerted)el.inert=was;menuInerted=[];menuOpen=!!open;$('navToggle').setAttribute('aria-expanded',String(menuOpen));document.body.toggleAttribute('data-nav-open',menuOpen);$('navBackdrop').hidden=!menuOpen;const aside=$('appSidebar');if(mobile.matches){aside.inert=!menuOpen;if(menuOpen){for(const el of [$('main'),document.querySelector('.masthead'),document.querySelector('footer')]){menuInerted.push([el,el.inert]);el.inert=true;}aside.setAttribute('role','dialog');aside.setAttribute('aria-modal','true');$('navClose').focus();}else{aside.removeAttribute('role');aside.removeAttribute('aria-modal');if(restore)$('navToggle').focus();}}else{aside.inert=false;aside.removeAttribute('role');aside.removeAttribute('aria-modal');}}
 function visibleFocus(root){return [...root.querySelectorAll('button:not(:disabled),a[href],input,select,textarea,summary,[tabindex="0"]')].filter(e=>e.getClientRects().length&&!e.closest('[inert]'));}
 function trap(e,root){const els=visibleFocus(root);if(!els.length)return;if(e.shiftKey&&document.activeElement===els[0]){e.preventDefault();els.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===els.at(-1)){e.preventDefault();els[0].focus();}}
 function closeExpanded(restore=true){if(!expanded)return;expanded.classList.remove('graph-expanded');expanded.removeAttribute('role');expanded.removeAttribute('aria-modal');expanded.querySelectorAll('[data-expand-graph]').forEach(b=>{b.setAttribute('aria-pressed','false');b.textContent='توسيع الرسم';});for(const [el,was] of inerted)el.inert=was;inerted=[];document.body.classList.remove('has-expanded-graph');expanded=null;if(restore)(expandOpener?.isConnected?expandOpener:$('main')).focus();}
 function expandGraph(button){const chart=button.closest('.chart-shell')||button.closest('.graph-panel')?.querySelector('.chart-shell');if(!chart)return;if(expanded===chart){closeExpanded();return;}closeExpanded(false);expanded=chart;expandOpener=button;chart.classList.add('graph-expanded');chart.setAttribute('role','dialog');chart.setAttribute('aria-modal','true');chart.setAttribute('aria-label','العرض الموسع للشبكة');for(let branch=chart;branch.parentElement&&branch!==document.body;branch=branch.parentElement){for(const el of branch.parentElement.children)if(el!==branch&&el.tagName!=='DIALOG'&&!['SCRIPT','STYLE'].includes(el.tagName)){inerted.push([el,el.inert]);el.inert=true;}}button.setAttribute('aria-pressed','true');button.textContent='إغلاق العرض الموسع';document.body.classList.add('has-expanded-graph');button.focus();}
 function enhance(){
  document.body.dataset.view=state.page;$('activePageName').textContent=pages.find(p=>p[0]===state.page)?.[1]||'';
  document.querySelectorAll('[data-open-search]').forEach(b=>b.onclick=()=>openSearch(b));
  for(const chart of $('view').querySelectorAll('.chart-shell')){
   if(!chart.querySelector('[data-motion-node]'))continue;
   if(!chart.querySelector('[data-expand-graph]')){const bar=document.createElement('div');bar.className='graph-view-actions';bar.innerHTML='<span>مساحة الشبكة</span><button data-expand-graph aria-pressed="false">توسيع الرسم</button>';chart.prepend(bar);}
  }
  document.querySelectorAll('[data-expand-graph]').forEach(b=>{b.setAttribute('aria-pressed','false');b.onclick=()=>expandGraph(b);});
  for(const table of $('view').querySelectorAll('table')){if(!table.parentElement.classList.contains('matrix-scroll')&&!table.parentElement.classList.contains('table-scroll')){const wrap=document.createElement('div');wrap.className='table-scroll';wrap.setAttribute('tabindex','0');wrap.setAttribute('role','region');wrap.setAttribute('aria-label','جدول قابل للتمرير أفقيًا');table.before(wrap);wrap.append(table);}}
  for(const button of $('view').querySelectorAll('[data-overview-pair]')){
   button.onclick=()=>{
    const [source,target]=button.dataset.overviewPair.split('|');
    const edge=NN.edges.find(candidate=>candidate.source===source&&candidate.target===target);
    if(edge)namePairDetail(edge);
   };
  }
  $('view').querySelectorAll('[data-overview-focus]').forEach(button=>{
   button.onclick=()=>{
    Object.assign(state,{nameFocus:button.dataset.overviewFocus,nameCategory:'',nameSurah:0,nameMinimum:1,nameOptional:false,nameHideDivine:false,nameListPage:0});
    navigate('names');
   };
  });
  if(state.page==='method')$('view').insertAdjacentHTML('beforeend',designReferences());
 }
 const textIndex=terms.map(t=>({t,key:norm((t.forms?.[0]?.text||t.id)+' '+t.id)}));
 function getSearchItems(query){const q=norm(query.trim()),ref=latinDigits(query.trim()).replace(/\s/g,'');if(!q)return [{title:'شبكة أسماء الأعلام',meta:'استكشف الأسماء والآيات المشتركة',run:()=>navigate('names')},{title:'قراءة النص كله',meta:'تصفح الآيات ومقاطع القراءة',run:()=>navigate('reading')},{title:'الدراسات المقارنة',meta:'بوابات الاستعمال والشواهد',run:()=>navigate('studies')},{title:'شبكة العلاقات الدلالية',meta:'العلاقات المسندة ومجالاتها',run:()=>navigate('semantic')}];
  const found=[];
  if(ayahMap.has(ref)){const a=ayahMap.get(ref);found.push({title:'الآية '+ref+' · '+a.surahName,meta:a.text.slice(0,120),run:()=>showEvidence(ref)});}
  for(const n of NN.nodes.filter(n=>norm(n.label).includes(q)).slice(0,7))found.push({title:n.label,meta:`اسم مسجل · ${num(n.ayahCount)} آية${n.includedByDefault?'':' · تسمية محتملة'}`,run:()=>{Object.assign(state,{nameFocus:n.id,nameCategory:'',nameSurah:0,nameMinimum:1,nameOptional:!n.includedByDefault,nameHideDivine:false,nameListPage:0});navigate('names');}});
  for(const s of corpus.surahs.filter(s=>norm(s.name).includes(q)).slice(0,4))found.push({title:'سورة '+s.name,meta:`${num(s.ayahs.length)} آية · قراءة النص`,run:()=>{state.readingSurah=s.number;state.readingUnit=FR.units.find(u=>u.surah===s.number).id;navigate('reading');}});
  for(const s of Object.values(FR.authoredStudies).filter(s=>norm(s.title).includes(q)).slice(0,5))found.push({title:s.title,meta:'دراسة مقارنة · شواهد واستعمالات',run:()=>{state.study=s.id;state.studyPage=0;navigate('studies');}});
  for(const {t} of textIndex.filter(x=>x.key.includes(q)).sort((a,b)=>Number(b.t.id===q)-Number(a.t.id===q)||b.t.df-a.t.df).slice(0,6))found.push({title:wordLabel(t.id),meta:`فهرس الألفاظ · ${num(t.df)} آية · مفتاح «${t.id}»`,run:()=>selectWord(t.id)});
  return found.slice(0,22);
 }
 function searchRender(){drawnQuery=$('globalSearchInput').value;searchItems=getSearchItems(drawnQuery);activeSearch=-1;$('globalSearchResults').innerHTML=searchItems.length?searchItems.map((x,i)=>`<button data-search-index="${i}"><span>${E(x.title)}</span><small>${E(x.meta)}</small><span class="result-arrow" aria-hidden="true">←</span></button>`).join(''):'<div class="search-empty"><strong>لا توجد نتائج مطابقة</strong><p>جرّب صورة أخرى للفظ، أو أدخل مرجعًا مثل <bdi>49:6</bdi>.</p></div>';$('searchStatus').textContent=searchItems.length?`${num(searchItems.length)} نتيجة متاحة`:'لا توجد نتائج مطابقة';$('globalSearchResults').querySelectorAll('button').forEach(b=>b.onclick=()=>runSearch(+b.dataset.searchIndex));}
 function runSearch(i){const item=searchItems[i];if(!item)return;searchNavigating=true;$('searchDialog').close();if($('evidenceDialog').open)closeDialog();item.run();if(!$('evidenceDialog').open)$('main').focus({preventScroll:true});}
 function openSearch(opener=$('globalSearchButton')){if(expanded)closeExpanded(false);if(menuOpen)setMenu(false,false);searchOpener=opener;$('searchDialog').showModal();$('globalSearchInput').value='';searchRender();$('globalSearchInput').focus();}
 $('globalSearchButton').onclick=()=>openSearch();$('closeSearch').onclick=()=>$('searchDialog').close();$('searchDialog').addEventListener('close',()=>{if(!searchNavigating&&searchOpener?.isConnected)searchOpener.focus({preventScroll:true});searchNavigating=false;});
 $('globalSearchInput').addEventListener('input',()=>{clearTimeout(queryTimer);queryTimer=setTimeout(searchRender,90);});
 $('searchDialog').addEventListener('keydown',e=>{if((e.key==='ArrowDown'||e.key==='ArrowUp'||e.key==='Enter')&&drawnQuery!==$('globalSearchInput').value){clearTimeout(queryTimer);searchRender();}if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();activeSearch=Math.max(0,Math.min(searchItems.length-1,activeSearch+(e.key==='ArrowDown'?1:-1)));$('globalSearchResults').querySelectorAll('button').forEach((b,i)=>b.classList.toggle('search-active',i===activeSearch));$('globalSearchResults').querySelector(`[data-search-index="${activeSearch}"]`)?.focus({preventScroll:true});$('globalSearchResults').querySelector(`[data-search-index="${activeSearch}"]`)?.scrollIntoView({block:'nearest'});}else if(e.key==='Enter'&&document.activeElement===$('globalSearchInput')){e.preventDefault();runSearch(Math.max(0,activeSearch));}});
 $('navToggle').onclick=()=>setMenu(!menuOpen);$('navClose').onclick=()=>setMenu(false);$('navBackdrop').onclick=()=>setMenu(false);mobile.addEventListener('change',()=>setMenu(false,false));setMenu(false,false);
 document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if(!$('searchDialog').open)openSearch();}if(e.key==='Escape'){if($('evidenceDialog').open||$('searchDialog').open)return;if(expanded){e.preventDefault();closeExpanded();}else if(menuOpen){e.preventDefault();setMenu(false);}}if(e.key==='Tab'){if(menuOpen&&mobile.matches)trap(e,$('appSidebar'));else if(expanded&&!$('evidenceDialog').open)trap(e,expanded);}});
 // Restore keyboard focus even when a source button was replaced during navigation.
 $('evidenceDialog').addEventListener('close',()=>{if(!document.activeElement||document.activeElement===document.body||!document.activeElement.isConnected)$('main').focus({preventScroll:true});});
 const requested=location.hash.slice(1);if(pages.some(([id])=>id===requested))state.page=requested;
 window.addEventListener('popstate',()=>{const page=location.hash.slice(1)||'home';if(pages.some(([id])=>id===page)){if(menuOpen)setMenu(false,false);closeExpanded(false);state.page=page;render();$('main').focus({preventScroll:true});window.scrollTo({top:0,behavior:'instant'});}});
 function designReferences(){
  const references=[
   {
    title:'مساحة الرسم والمفتاح والشواهد',
    detail:'يظهر الرسم بجوار مفتاح الفئات وقائمة التفاصيل. انتقلنا من عرض متتابع إلى مساحة واحدة على الشاشات الواسعة، ورتبناها عموديًا عند ضيق العرض.',
    links:[['واجهة Neo4j Bloom المشروحة','https://neo4j.com/docs/bloom-user-guide/current/bloom-visual-tour/bloom-overview/'],['لوحة تفاصيل العنصر','https://neo4j.com/docs/bloom-user-guide/current/bloom-visual-tour/card-list/']]
   },
   {
    title:'القائمة وشريط التطبيق',
    detail:'شريط علوي مشترك وقائمة جانبية مجمعة تتقلص عند ضيق الشاشة. يعكس الملف موضع القائمة لتلائم العربية. طبقات الواجهة محايدة، والأزرق يميز الإجراء والاختيار.',
    links:[['Carbon UI Shell','https://www.carbondesignsystem.com/building-blocks/core/components/ui-shell-header/guidelines'],['Carbon Color','https://www.carbondesignsystem.com/building-blocks/foundations/color/overview'],['لوحات المتابعة في Carbon','https://www.carbondesignsystem.com/building-blocks/data-visualization/dashboards'],['تخطيط آبل','https://developer.apple.com/design/human-interface-guidelines/layout']]
   },
   {
    title:'ألوان الفئات وأنواع العلاقات',
    detail:'الفئات المتقطعة لها درجات متميزة من لوحة IBM. تعيين كل درجة لفئة أو نوع علاقة قرار تصميم خاص بهذا الملف. يرافق اللون شكل في شبكة الأعلام، ونمط خط وتسمية في شبكة العلاقات.',
    links:[['لوحات Carbon للبيانات','https://www.carbondesignsystem.com/building-blocks/data-visualization/color-palettes'],['مفاتيح الرسوم في Carbon','https://www.carbondesignsystem.com/building-blocks/data-visualization/legends'],['استخدام اللون في W3C','https://www.w3.org/WAI/WCAG22/Understanding/use-of-color.html']]
   },
   {
    title:'الكثافة والتشابه والأوزان',
    detail:'درجات الأزرق تتدرج مع المقدار في خرائط الكثافة والمصفوفات، والأرقام تعرض القيمة. سُمك خط الأعلام يحمل عدد الآيات المشتركة، وطول شريط الإسناد يبين حصته من السجلات.',
    links:[['التدرج العددي في Carbon','https://www.carbondesignsystem.com/building-blocks/data-visualization/color-palettes#sequential-palettes'],['الخرائط والمصفوفات في Carbon','https://www.carbondesignsystem.com/building-blocks/data-visualization/spatial-charts'],['الأشرطة في Carbon','https://www.carbondesignsystem.com/building-blocks/data-visualization/simple-charts']]
   }
  ];
  return `<section class="section design-reference-panel" id="designReferences">
   <header><span class="eyebrow">مصادر التطبيق المرئي</span><h3>مراجع تصميم الواجهة</h3><p class="small muted">تخص المراجع تخطيط الواجهة وعرض البيانات. مرجع القراءة والتحليل هو النص المرفق.</p></header>
   <div class="design-reference-grid">${references.map((reference,index)=>`
    <article class="design-reference"><span class="eyebrow">${num(index+1)}</span><h4>${reference.title}</h4><p>${reference.detail}</p>
      <div class="design-reference-links">${reference.links.map(([label,url])=>`<a href="${E(url)}" target="_blank" rel="noopener noreferrer"><bdi>${E(label)}</bdi> ↗</a>`).join('')}</div>
    </article>`).join('')}</div>
  </section>`;
 }

 function preview(){
  const center=NN.nodes.find(node=>node.label==='موسى');
  if(!center)return '';
  const neighbors=NN.edges.filter(edge=>edge.source===center.id||edge.target===center.id)
    .map(edge=>({edge,node:nameNodes.get(edge.source===center.id?edge.target:edge.source)}))
    .filter(({node})=>node.includedByDefault)
    .sort((first,second)=>second.edge.weight-first.edge.weight).slice(0,5);
  const points=[[344,52],[505,108],[481,246],[190,252],[126,112]];
  const cx=316,cy=154;
  const lines=neighbors.map(({edge},index)=>{
   const [x,y]=points[index];
   return `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="var(--graph-edge)" stroke-width="${1.2+Math.log2(edge.weight+1)}" opacity=".72"/>`;
  }).join('');
  const nodes=neighbors.map(({node},index)=>{
   const [x,y]=points[index];
   return `<g transform="translate(${x} ${y})">${nameMarker(node.category,13)}</g><text x="${x}" y="${y+34}" text-anchor="middle">${E(node.label)}</text>`;
  }).join('');
  const peers=neighbors.map(({edge,node})=>`<button type="button" class="overview-peer" data-overview-pair="${E(edge.source+'|'+edge.target)}">
    <span class="overview-peer-name"><svg viewBox="-1.4 -1.4 2.8 2.8" aria-hidden="true">${nameMarker(node.category)}</svg>${E(node.label)}</span>
    <bdi>${num(edge.weight)}</bdi><span aria-hidden="true">‹</span>
  </button>`).join('');
  return `<section class="overview-scene" aria-labelledby="overviewSceneTitle">
   <div class="overview-scene-main">
    <div class="overview-scene-header"><div><span class="eyebrow">شبكة الأعلام</span><h3 id="overviewSceneTitle">جوار موسى في الآيات</h3></div><span class="pill">${num(neighbors.length)} أسماء من الجوار</span></div>
    <svg viewBox="0 0 640 318" role="img" aria-label="خمس تسميات تجتمع مع موسى في آيات. تفاصيل العدد والشواهد في اللوح المجاور.">
     ${lines}${nodes}<g transform="translate(${cx} ${cy})">${nameMarker(center.category,23)}</g>
     <circle cx="${cx}" cy="${cy}" r="29" fill="none" stroke="var(--accent)" stroke-width="2"/><text x="${cx}" y="${cy+52}" text-anchor="middle" font-weight="700">موسى</text>
    </svg>
    <div class="overview-scene-foot"><span>سُمك الخط بحسب عدد الآيات المشتركة</span><button class="text-button" type="button" data-overview-focus="${E(center.id)}">افتح هذا الجوار ←</button></div>
   </div>
   <section class="overview-inspector" aria-label="الآيات المشتركة في المعاينة">
    <h4>الآيات المشتركة</h4><p class="small muted">اختر اسمًا لفتح قائمة الشواهد.</p>
    <div class="overview-peers">${peers}</div>
   </section>
  </section>`;
 }

 function home(){
  const metrics=[
   [FR.coverage.sourceAyahs,'آية في النص المحفوظ'],
   [NN.counts.defaultLabels,'تسمية علم في العرض الافتراضي'],
   [SN.edges.length,'علاقة مسندة بشاهد وقيد'],
   [Object.keys(FR.authoredStudies).length,'دراسة مقارنة للاستعمال']
  ];
  const paths=[
   ['names','الأعلام','اجتماع الأسماء في الآيات وأعداد الشواهد.'],
   ['semantic','العلاقات الدلالية','أنواع الإسناد وجهة القول وسياقه.'],
   ['reading','قراءة النص','الآيات ومقاطع القراءة.'],
   ['studies','الدراسات المقارنة','صور البحث والاستعمالات والشواهد.']
  ];
  const accepted=Object.values(FR.independentReviews).filter(review=>review.status==='accepted_as_scoped').length;
  const systemsReviewed=SM.systems.filter(system=>system.reviewStatus==='independently_reviewed_as_scoped').length;
  return `<section class="overview-heading">
    <div><span class="eyebrow">مختبر النص · الاستكشاف</span><h2>استكشاف القرآن</h2><p>تصفح الألفاظ والآيات، واستكشف العلاقات، وافتح شواهدها من موضعها.</p></div>
    <button class="primary" data-open-search>ابحث في الملف</button>
   </section>
   <div class="overview-stats">${metrics.map(([value,label])=>`<div><strong class="value">${num(value)}</strong><span>${label}</span></div>`).join('')}</div>
   ${preview()}
   <section class="section overview-paths" aria-label="مسارات الاستكشاف">
    <h3>مسارات الاستكشاف</h3><div class="overview-path-list">${paths.map(([id,title,detail])=>`
     <button data-page="${id}">${icon(id)}<strong>${title}</strong><span>${detail}</span><span aria-hidden="true">←</span></button>`).join('')}</div>
   </section>
   <details class="overview-review"><summary>نطاق القراءة والمراجعة · ${num(FR.units.length)} مقطعًا · ${num(SM.systems.length)} منظومة</summary><p>تغطي المقاطع المكتوبة آيات المرفق كلها. لعدد ${num(accepted)} منها مراجعة مستقلة مطابقة لمحتواها. تضم المقارنة ${num(Object.keys(FR.authoredStudies).length)} بوابة بحث، منها دراسات مصنفة بحسب شواهدها. تضم المنظومات ${num(systemsReviewed)} توليفًا مراجعًا ضمن نطاقه. تُجرى المراجعة بين مسارات التحليل الآلية.</p><p>تضم شبكة الأعلام ${num(NN.counts.optionalLabels)} تسمية محتملة في طبقة اختيارية. القراءات وحدود الاستنتاجات متاحة في مساراتها.</p>${FR.coverage.pendingAuthorshipPairs?`<p data-pending-authorship>تنتظر ${num(FR.coverage.pendingAuthorshipPairs)} مطابقة إعادة تأليف وصف استعمالها المحلي.</p>`:''}</details>
   <details class="overview-review overview-systems"><summary>المنظومات المعرفية · ${num(SM.systems.length)}</summary>
    <div class="domain-grid">${Object.entries(SM.systemTitles).map(([id,title])=>`<button class="domain-card" data-model="${id}"><strong>${E(title)}</strong><span>${num(SM.metrics[id]?.relations||0)} سجل علاقة ضمن نطاق العدسة</span></button>`).join('')}</div>
   </details>
   <button class="text-button overview-footer-note" data-page="method">المنهج ومراجع تصميم الواجهة ←</button>`;
 }
 window.QuranWorkbench={navigation,enhance,icon,preview,home,openSearch,closeExpanded,beforeRender:()=>closeExpanded(false),beforeNavigate:()=>{if(menuOpen)setMenu(false,false);closeExpanded(false);}};
})();
