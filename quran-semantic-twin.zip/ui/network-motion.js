'use strict';
// Presentation only: positions, movement and zoom never alter network records.
(function () {
  const NS='http://www.w3.org/2000/svg', controllers=new Set(), attached=new WeakMap();
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
  let userRunning=null, scanQueued=false;
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function attach(svg,config={}) {
    if(!svg||attached.has(svg))return attached.get(svg)||null;
    const els=[...svg.querySelectorAll(config.nodeSelector||'[data-motion-node]')];
    if(!els.length)return null;
    const box=svg.viewBox.baseVal;
    const width=box.width||960,height=box.height||590;
    const removers=[], listen=(el,type,fn,options)=>{el.addEventListener(type,fn,options);removers.push(()=>el.removeEventListener(type,fn,options));};
    const nodes=els.map((el,i)=>{
      const circle=el.querySelector('circle'), initialTransform=el.getAttribute('transform')||'';
      let x=circle?Number(circle.getAttribute('cx')||0):0,y=circle?Number(circle.getAttribute('cy')||0):0;
      // Convert the shape centre to the SVG's own coordinate system, before wrapping.
      try{const p=svg.createSVGPoint();p.x=x;p.y=y;const m=svg.getCTM().inverse().multiply((circle||el).getCTM());const q=p.matrixTransform(m);x=q.x;y=q.y;}catch(_){const m=initialTransform.match(/translate\(\s*([-\d.]+)[ ,]+([-\d.]+)/);if(m){x+=Number(m[1]);y+=Number(m[2]);}}
      return {el,id:config.nodeId?config.nodeId(el):el.dataset.motionNode,x,y,ox:x,oy:y,vx:0,vy:0,fixed:false,
        radius:Number(el.dataset.motionRadius)||Number(circle?.getAttribute('r'))||7,initialTransform,phase:i*2.399963};
    });
    const byId=new Map(nodes.map(n=>[String(n.id),n]));
    const edges=[...svg.querySelectorAll(config.edgeSelector||'[data-motion-source][data-motion-target]')].map(el=>{
      const a=byId.get(String(config.source?config.source(el):el.dataset.motionSource));
      const b=byId.get(String(config.target?config.target(el):el.dataset.motionTarget));
      const lines=el.tagName.toLowerCase()==='line'?[el]:[...el.querySelectorAll('line')];
      const labels=[...el.querySelectorAll('text')].map(t=>({el:t,dx:Number(t.getAttribute('x')||0)-(a?.x+b?.x)/2,dy:Number(t.getAttribute('y')||0)-(a?.y+b?.y)/2}));
      return {el,a,b,lines,labels,weight:Math.max(1,Number(el.dataset.motionWeight)||1)};
    }).filter(e=>e.a&&e.b);
    const viewport=document.createElementNS(NS,'g');viewport.setAttribute('class','network-motion-viewport');
    for(const el of [...svg.children])if(!['defs','title','desc'].includes(el.tagName.toLowerCase()))viewport.append(el);
    svg.append(viewport);
    svg.classList.add('network-motion-svg');svg.closest('.chart-shell')?.classList.add('network-motion-shell');
    if(!svg.hasAttribute('tabindex'))svg.setAttribute('tabindex','0');
    svg.dataset.motionReady='true';
    const toolbar=document.createElement('div');toolbar.className='network-motion-tools';toolbar.setAttribute('role','group');toolbar.setAttribute('aria-label','التحكم في حركة الشبكة وتكبيرها');
    toolbar.innerHTML='<button type="button" data-motion-action="toggle"></button><button type="button" data-motion-action="in" aria-label="تكبير الشبكة">＋</button><button type="button" data-motion-action="out" aria-label="تصغير الشبكة">−</button><button type="button" data-motion-action="fit">احتواء الشبكة</button><button type="button" data-motion-action="reset">إعادة الترتيب</button><span class="network-motion-help">اسحب الاسم لتحريكه، أو الخلفية للتنقل. كبّر بالعجلة أو بإصبعين.</span>';
    svg.before(toolbar);
    const toggle=toolbar.querySelector('[data-motion-action="toggle"]');
    let running=userRunning===null?!reduced.matches:userRunning, destroyed=false, frame=0,last=0,ticks=0;
    let zoom=1,panX=0,panY=0,gesture=null,suppressClickUntil=0;
    const pointers=new Map();
    function updateViewport(){viewport.setAttribute('transform',`translate(${panX} ${panY}) scale(${zoom})`);svg.dataset.motionZoom=zoom.toFixed(4);}
    function draw(){
      for(const n of nodes)n.el.setAttribute('transform',`translate(${(n.x-n.ox).toFixed(3)} ${(n.y-n.oy).toFixed(3)}) ${n.initialTransform}`.trim());
      for(const e of edges){
        const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1;
        const pa=Math.min(e.a.radius+2,d*.3),pb=Math.min(e.b.radius+(e.lines.some(l=>l.hasAttribute('marker-end'))?5:2),d*.3);
        for(const line of e.lines){line.setAttribute('x1',e.a.x+dx/d*pa);line.setAttribute('y1',e.a.y+dy/d*pa);line.setAttribute('x2',e.b.x-dx/d*pb);line.setAttribute('y2',e.b.y-dy/d*pb);}
        for(const l of e.labels){l.el.setAttribute('x',(e.a.x+e.b.x)/2+(Number.isFinite(l.dx)?l.dx:0));l.el.setAttribute('y',(e.a.y+e.b.y)/2+(Number.isFinite(l.dy)?l.dy:0));}
      }
      svg.dataset.motionTicks=String(ticks);
    }
    function tick(now){
      frame=0;
      if(destroyed||!svg.isConnected){destroy();return;}
      if(!running||document.hidden)return;
      if(now-last<30){frame=requestAnimationFrame(tick);return;}
      const dt=clamp((now-last)/33.333,.5,1.6);last=now;ticks++;
      for(const n of nodes){n.fx=(width/2-n.x)*.00065;n.fy=(height/2-n.y)*.00065;}
      for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){
        const a=nodes[i],b=nodes[j];let dx=b.x-a.x,dy=b.y-a.y;
        if(Math.abs(dx)+Math.abs(dy)<.01){dx=.2;dy=.1;}
        const d=Math.max(10,Math.hypot(dx,dy)),spacing=Math.max(52,a.radius+b.radius+24);
        const f=Math.min(3.5,1100/(d*d)+(d<spacing?(spacing-d)*.012:0));
        a.fx-=dx/d*f;a.fy-=dy/d*f;b.fx+=dx/d*f;b.fy+=dy/d*f;
      }
      for(const e of edges){if(e.a===e.b)continue;const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.max(1,Math.hypot(dx,dy));
        const length=clamp(Math.sqrt(width*height/Math.max(nodes.length,4))*1.05,76,180);
        const f=clamp((d-length)*.0014*(1+Math.log1p(e.weight)*.12),-1.5,1.5);
        e.a.fx+=dx/d*f;e.a.fy+=dy/d*f;e.b.fx-=dx/d*f;e.b.fy-=dy/d*f;
      }
      for(const n of nodes){if(n.fixed){n.vx=0;n.vy=0;continue;}
        // A tiny time-varying drift keeps a settled layout alive without flashing.
        n.fx+=Math.sin(ticks*.017+n.phase)*.013;n.fy+=Math.cos(ticks*.014+n.phase)*.013;
        n.vx=clamp((n.vx+n.fx*dt)*.86,-3.5,3.5);n.vy=clamp((n.vy+n.fy*dt)*.86,-3.5,3.5);
        n.x=clamp(n.x+n.vx*dt,30,width-30);n.y=clamp(n.y+n.vy*dt,34,height-34);
      }
      draw();frame=requestAnimationFrame(tick);
    }
    function requestFrame(){if(running&&!document.hidden&&!destroyed&&!frame){last=performance.now()-34;frame=requestAnimationFrame(tick);}}
    function updateRunning(){toggle.textContent=running?'إيقاف الحركة':'تشغيل الحركة';toggle.setAttribute('aria-pressed',String(running));svg.dataset.motionRunning=String(running&&!document.hidden);if(frame){cancelAnimationFrame(frame);frame=0;}requestFrame();}
    function setRunning(value,remember=false){running=!!value;if(remember)userRunning=running;updateRunning();}
    function svgPoint(clientX,clientY){const p=svg.createSVGPoint();p.x=clientX;p.y=clientY;return p.matrixTransform(svg.getScreenCTM().inverse());}
    function worldPoint(clientX,clientY){const p=svgPoint(clientX,clientY);return{x:(p.x-panX)/zoom,y:(p.y-panY)/zoom};}
    function zoomAt(next,p={x:width/2,y:height/2}){next=clamp(next,.3,6);const x=(p.x-panX)/zoom,y=(p.y-panY)/zoom;zoom=next;panX=p.x-x*zoom;panY=p.y-y*zoom;updateViewport();}
    function fit(){const minX=Math.min(...nodes.map(n=>n.x-n.radius-45)),maxX=Math.max(...nodes.map(n=>n.x+n.radius+45));const minY=Math.min(...nodes.map(n=>n.y-n.radius-36)),maxY=Math.max(...nodes.map(n=>n.y+n.radius+36));zoom=clamp(Math.min(width/Math.max(1,maxX-minX),height/Math.max(1,maxY-minY))*.9,.3,2);panX=width/2-(minX+maxX)/2*zoom;panY=height/2-(minY+maxY)/2*zoom;updateViewport();}
    function reset(){for(const n of nodes){n.x=n.ox;n.y=n.oy;n.vx=0;n.vy=0;}zoom=1;panX=0;panY=0;draw();updateViewport();}
    listen(toolbar,'click',e=>{const action=e.target.closest('[data-motion-action]')?.dataset.motionAction;if(action==='toggle')setRunning(!running,true);else if(action==='in')zoomAt(zoom*1.25);else if(action==='out')zoomAt(zoom/1.25);else if(action==='fit')fit();else if(action==='reset')reset();});
    listen(svg,'wheel',e=>{e.preventDefault();zoomAt(zoom*Math.exp(clamp(-e.deltaY*.0015,-.35,.35)),svgPoint(e.clientX,e.clientY));},{passive:false});
    function startPinch(){const a=[...pointers.values()][0],b=[...pointers.values()][1];if(!a||!b)return;for(const n of nodes)n.fixed=false;const mx=(a.x+b.x)/2,my=(a.y+b.y)/2;gesture={type:'pinch',distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),zoom,anchor:worldPoint(mx,my),moved:true};}
    listen(svg,'pointerdown',e=>{
      if(e.button!==0&&e.pointerType!=='touch')return;e.preventDefault();
      const nodeEl=e.target.closest(config.nodeSelector||'[data-motion-node]');
      const edgeEl=e.target.closest(config.edgeSelector||'[data-motion-source][data-motion-target]'),captureEl=nodeEl||edgeEl||svg;
      pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,captureEl});try{captureEl.setPointerCapture(e.pointerId);}catch(_){}
      if(pointers.size>1){startPinch();return;}
      const n=nodes.find(x=>x.el===nodeEl),p=worldPoint(e.clientX,e.clientY);
      gesture=n?{type:'node',node:n,offset:{x:n.x-p.x,y:n.y-p.y},clientX:e.clientX,clientY:e.clientY,moved:false}:{type:'pan',start:svgPoint(e.clientX,e.clientY),panX,panY,clientX:e.clientX,clientY:e.clientY,moved:false};
      if(n)n.fixed=true;svg.classList.add('network-motion-dragging');
    });
    listen(svg,'pointermove',e=>{
      if(!pointers.has(e.pointerId)||!gesture)return;const captureEl=pointers.get(e.pointerId).captureEl;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,captureEl});
      if(gesture.type==='pinch'){
        const[a,b]=[...pointers.values()];if(!a||!b)return;const distance=Math.hypot(a.x-b.x,a.y-b.y),mid=svgPoint((a.x+b.x)/2,(a.y+b.y)/2);zoom=clamp(gesture.zoom*distance/gesture.distance,.3,6);panX=mid.x-gesture.anchor.x*zoom;panY=mid.y-gesture.anchor.y*zoom;updateViewport();return;
      }
      if(Math.hypot(e.clientX-gesture.clientX,e.clientY-gesture.clientY)>5)gesture.moved=true;
      if(!gesture.moved)return;
      if(gesture.type==='node'){const p=worldPoint(e.clientX,e.clientY),n=gesture.node;n.x=clamp(p.x+gesture.offset.x,15,width-15);n.y=clamp(p.y+gesture.offset.y,15,height-15);draw();}
      else{const p=svgPoint(e.clientX,e.clientY);panX=gesture.panX+p.x-gesture.start.x;panY=gesture.panY+p.y-gesture.start.y;updateViewport();}
    });
    function endPointer(e){
      if(!pointers.has(e.pointerId))return;const moved=gesture?.moved;if(gesture?.node)gesture.node.fixed=false;
      const captureEl=pointers.get(e.pointerId).captureEl;pointers.delete(e.pointerId);try{captureEl.releasePointerCapture(e.pointerId);}catch(_){}
      if(moved)suppressClickUntil=performance.now()+650;
      if(pointers.size===1){const p=[...pointers.values()][0];gesture={type:'pan',start:svgPoint(p.x,p.y),panX,panY,clientX:p.x,clientY:p.y,moved:true};}
      else if(!pointers.size){gesture=null;svg.classList.remove('network-motion-dragging');}
    }
    listen(svg,'pointerup',endPointer);listen(svg,'pointercancel',endPointer);
    listen(svg,'click',e=>{if(performance.now()<suppressClickUntil&&e.detail!==0){e.preventDefault();e.stopImmediatePropagation();}},true);
    listen(svg,'keydown',e=>{if(e.target!==svg)return;let handled=true;if(e.key==='+'||e.key==='=')zoomAt(zoom*1.2);else if(e.key==='-')zoomAt(zoom/1.2);else if(e.key==='0'||e.key==='Home')fit();else if(e.key===' ')setRunning(!running,true);else if(e.key==='ArrowLeft'){panX+=35;updateViewport();}else if(e.key==='ArrowRight'){panX-=35;updateViewport();}else if(e.key==='ArrowUp'){panY+=35;updateViewport();}else if(e.key==='ArrowDown'){panY-=35;updateViewport();}else handled=false;if(handled)e.preventDefault();});
    listen(document,'visibilitychange',updateRunning);
    listen(reduced,'change',e=>{if(e.matches)setRunning(false);});
    function destroy(){if(destroyed)return;destroyed=true;if(frame)cancelAnimationFrame(frame);frame=0;for(const remove of removers)remove();toolbar.remove();attached.delete(svg);controllers.delete(controller);delete svg.dataset.motionReady;}
    const controller={svg,setRunning,fit,reset,destroy,getState:()=>({running,zoom,panX,panY,ticks,nodes:nodes.map(n=>({id:n.id,x:n.x,y:n.y})),edgeCount:edges.length})};
    attached.set(svg,controller);controllers.add(controller);draw();updateViewport();updateRunning();return controller;
  }
  function attachAll(root=document){for(const c of [...controllers])if(!c.svg.isConnected)c.destroy();return [...root.querySelectorAll('svg')].filter(svg=>svg.querySelector('[data-motion-node]')).map(svg=>attach(svg));}
  const observer=new MutationObserver(()=>{if(scanQueued)return;scanQueued=true;queueMicrotask(()=>{scanQueued=false;attachAll();});});
  observer.observe(document.body,{childList:true,subtree:true});
  window.QuranNetworkMotion={attach,attachAll,getController:svg=>attached.get(svg)||null,destroyAll:()=>{for(const c of [...controllers])c.destroy();}};
  attachAll();
})();
