'use strict';
const NN=DATA.namesNetwork;
const nameNodes=new Map((NN?.nodes||[]).map(n=>[n.id,n]));
const nameCategories={person:'أشخاص مسمّون','named-being':'أفراد مسمّون آخرون',divine:'اسم الله',place:'أماكن مسماة',group:'جماعات مسماة','named-object':'كيانات مسماة',uncertain:'تعيين محتمل'};
// The same categorical marker appears in the scene and its key.
const nameMarkers={
 person:['--category-person','<circle r="1"/>'],
 'named-being':['--category-being','<path d="M0 -1.15 1.1 0 0 1.15 -1.1 0Z"/>'],
 divine:['--category-divine','<path d="M-.5 -.9H.5L1 0 .5 .9H-.5L-1 0Z"/>'],
 place:['--category-place','<rect x="-.86" y="-.86" width="1.72" height="1.72" rx=".2"/>'],
 group:['--category-group','<path d="M0 -1.1 1 .84H-1Z"/>'],
 'named-object':['--category-object','<path d="M0 -1.08 1.03 -.34 .64 .87H-.64L-1.03 -.34Z"/>'],
 uncertain:['--category-uncertain','<circle r=".95"/>']
};
const nameColors=Object.fromEntries(Object.entries(nameMarkers).map(([category,[color]])=>[category,`var(${color},var(--muted))`]));
function nameMarker(category,radius=1){
 const [,geometry]=nameMarkers[category]||nameMarkers.uncertain;
 const shape=category==='uncertain'?'name-marker name-marker-outline':'name-marker';
 return `<g class="${shape}" style="--name-marker-color:${nameColors[category]||nameColors.uncertain}" transform="scale(${radius})" aria-hidden="true">${geometry}</g>`;
}
Object.assign(state,{nameFocus:'',nameCategory:'',nameSurah:0,nameMinimum:1,nameOptional:false,nameHideDivine:false,nameListPage:0,nameFiltersOpen:false});
function namesScope(){
 const refOK=r=>!state.nameSurah||+r.split(':')[0]===state.nameSurah;
 const nodes=(NN?.nodes||[]).filter(n=>(state.nameOptional||n.includedByDefault)&&(!state.nameCategory||n.category===state.nameCategory)&&(!state.nameHideDivine||n.category!=='divine')).map(n=>({...n,scopeRefs:n.refs.filter(refOK)})).filter(n=>n.scopeRefs.length);
 const ids=new Set(nodes.map(n=>n.id));
 const edges=NN.edges.filter(e=>ids.has(e.source)&&ids.has(e.target)).map(e=>({...e,refs:e.refs.filter(refOK)})).map(e=>({...e,weight:e.refs.length})).filter(e=>e.weight>=state.nameMinimum).sort((a,b)=>b.weight-a.weight||a.id.localeCompare(b.id));
 if(!state.nameFocus)return {nodes,edges};
 const selected=edges.filter(e=>e.source===state.nameFocus||e.target===state.nameFocus),local=new Set([state.nameFocus,...selected.flatMap(e=>[e.source,e.target])]);
 return {nodes:nodes.filter(n=>local.has(n.id)),edges:selected};
}
function namesGraph(nodes,edges){
 const mobile=window.innerWidth<700;
 const w=mobile?640:960,h=mobile?760:650;
 const max=Math.max(...nodes.map(n=>n.scopeRefs.length),1);
 const focus=nodes.find(n=>n.id===state.nameFocus);
 const ring=focus&&nodes.length<=25;
 const neighbors=nodes.filter(n=>n.id!==focus?.id);
 const points=new Map();
 if(ring||nodes.length===1){
  points.set((focus||nodes[0]).id,{x:w/2,y:h/2});
  if(ring)neighbors.forEach((n,i)=>{
   const angle=2*Math.PI*i/neighbors.length-Math.PI/2;
   points.set(n.id,{x:w/2+w*.34*Math.cos(angle),y:h/2+h*.36*Math.sin(angle)});
  });
 }else{
  nodes.forEach((n,i)=>{
   const angle=i*2.399963,r=Math.sqrt((i+.5)/nodes.length);
   points.set(n.id,{x:w/2+w*.39*r*Math.cos(angle),y:h/2+h*.38*r*Math.sin(angle)});
  });
 }
 const captionLimit=mobile?16:24;
 const compactLabels=nodes.length>captionLimit+8;
 const thickness=weight=>1+2.2*Math.log2(1+weight);
 const scope=state.nameSurah?surahMap.get(state.nameSurah)?.name:'النص كله';
 const links=edges.map(e=>{
  const a=points.get(e.source),b=points.get(e.target);
  const label=`${nameNodes.get(e.source).label} مع ${nameNodes.get(e.target).label} · ${num(e.weight)} آية مشتركة`;
  return `<line class="name-edge" data-name-edge="${E(e.id)}" data-motion-source="${E(e.source)}" data-motion-target="${E(e.target)}" data-motion-weight="${e.weight}" data-count="${e.weight}"
   x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke-width="${thickness(e.weight)}" stroke-opacity="${.22+Math.min(.44,Math.log2(1+e.weight)*.075)}" tabindex="0" role="button" aria-label="${E(label)}"><title>${E(label)}</title></line>`;
 }).join('');
 const markers=nodes.map((n,i)=>{
  const p=points.get(n.id),radius=6+17*Math.sqrt(n.scopeRefs.length/max);
  const selected=n.id===focus?.id;
  const showCaption=!compactLabels||selected||i<captionLimit;
  const optional=n.includedByDefault?'':' · تسمية محتملة';
  const label=`${n.label} · ${nameCategories[n.category]||'تسمية'} · ${num(n.scopeRefs.length)} آية${optional}${selected?' · الاسم المحدد':''}`;
  const hitRadius=Math.max(22,radius);
  return `<g class="name-node" data-name-node="${E(n.id)}" data-motion-node="${E(n.id)}" data-motion-radius="${hitRadius}"
   data-caption="${showCaption?'shown':'on-demand'}" ${selected?'aria-current="true"':''} transform="translate(${p.x} ${p.y})" tabindex="0" role="button" aria-label="${E(label)}">
   <circle class="name-node-hit" r="${hitRadius}" fill="transparent"/>
   ${nameMarker(n.category,radius)}
   ${n.includedByDefault?'':`<circle class="name-node-optional" r="${radius+3}" aria-hidden="true"/>`}
   <circle class="name-node-ring" r="${radius+6}" aria-hidden="true"/>
   <text y="${-radius-12}" text-anchor="middle" style="font-size:${mobile?21:16}px">${E(n.label)}</text><title>${E(label)}</title></g>`;
 }).join('');
 return `<div class="chart-shell names-chart">
  <div class="names-canvas-header"><div><span class="eyebrow">${E(scope)}</span><h3>${focus?'الجوار المباشر لـ«'+E(focus.label)+'»':'خريطة أسماء الأعلام'}</h3></div><button type="button" data-expand-graph aria-controls="namesGraph">توسيع الرسم</button></div>
  <div class="names-inline-stats" role="group" aria-label="إحصاءات النطاق الظاهر">
   <div><strong id="visibleNamesCount">${num(nodes.length)}</strong><span>تسمية ظاهرة</span></div>
   <div><strong id="visibleNamesEdges">${num(edges.length)}</strong><span>زوج متصل</span></div>
   <div><strong>${num(edges.reduce((sum,e)=>sum+e.weight,0))}</strong><span>مجموع آيات الأزواج</span></div>
  </div>
  <svg id="namesGraph" style="aspect-ratio:${w}/${h}" viewBox="0 0 ${w} ${h}" role="group" aria-label="شبكة تلازم أسماء الأعلام في الآية، وكل خط يفتح شواهده">${links}${markers}</svg>
  <p class="names-canvas-footer">مقاس العقدة يعبّر عن عدد آيات الاسم. سُمك الخط يعبّر عن عدد الآيات المشتركة.${compactLabels?' تظهر بقية الأسماء عند التركيز على العقدة أو تكبير الرسم.':''}</p>
 </div>`;
}

function namesLegend(nodes){
 const counts=new Map();
 for(const node of nodes)counts.set(node.category,(counts.get(node.category)||0)+1);
 return `<section class="names-legend" aria-labelledby="namesLegendTitle">
  <div class="names-panel-heading"><h3 id="namesLegendTitle">مفتاح الرسم</h3><span class="small muted">حسب الفئة</span></div>
  ${nodes.length?`<ul>${Object.entries(nameCategories).filter(([category])=>counts.has(category)).map(([category,label])=>`<li>
    <svg viewBox="-1.4 -1.4 2.8 2.8" aria-hidden="true">${nameMarker(category)}</svg>
    <span>${E(label)}</span><strong>${num(counts.get(category))}</strong></li>`).join('')}</ul>`:'<p class="small muted">ستظهر الفئات هنا عند وجود أسماء ضمن النطاق.</p>'}
  ${nodes.some(n=>n.id===state.nameFocus)?'<p class="names-legend-note"><i class="names-selected-key" aria-hidden="true"></i>الحلقة المتصلة للاسم المحدد</p>':''}
  ${nodes.some(n=>!n.includedByDefault)?'<p class="names-legend-note"><i class="names-optional-key" aria-hidden="true"></i>الحلقة المتقطعة لتسمية محتملة</p>':''}
 </section>`;
}
function namePairDetail(e){const a=nameNodes.get(e.source),b=nameNodes.get(e.target);showRefList(`«${a.label}» مع «${b.label}» · ${num(e.refs.length)} آية مشتركة`,e.refs,[...(a.keys||[]),...(b.keys||[])]);}
function nameDetails(n,view){
 const adjacent=view.edges.filter(e=>e.source===n.id||e.target===n.id);
 const neighbors=adjacent.map(e=>{
  const other=nameNodes.get(e.source===n.id?e.target:e.source);
  return `<div><button class="chip" data-name-focus="${E(other.id)}">${E(other.label)}</button><button class="chip" data-name-pair="${E(e.id)}" aria-label="شواهد ${E(n.label+' مع '+other.label)}، ${num(e.weight)} آية مشتركة">${num(e.weight)} آية</button></div>`;
 }).join('');
 return `<section class="names-inspector" id="nameDetails" aria-labelledby="nameDetailsTitle">
  <div class="names-panel-heading"><h3 id="nameDetailsTitle">تعيين «${E(n.label)}»</h3>${badge(nameCategories[n.category]||n.category)}</div>
  <p>${E(n.note||'')}</p><p class="small">درجة التعيين <strong>${E(n.certainty||'مرشح من السياق')}</strong></p>
  <div class="chips">${n.evidenceRefs.map(r=>`<button class="ref" data-ref="${E(r)}">${E(r)}</button>`).join('')}</div>
  <h4 class="names-subheading">الجوار وفق المرشحات</h4><div class="name-neighbors">${neighbors||'<p class="small muted">لا اسم مجاور وفق المرشحات. مواضع الاسم متاحة في اللوح.</p>'}</div>
  <details class="names-disclosure"><summary>المقاييس والصور الأصلية</summary>
   <p class="small muted">في النص كله ${num(n.mentionCount)} ظهورًا في ${num(n.ayahCount)} آية، و${num(n.degree)} اسمًا مجاورًا داخل السجل. مجموع أوزان الخطوط المتصلة هو ${num(n.strength)}. هذه المقاييس تصف بنية الشبكة.</p>
   <p class="small">${[...new Set(n.occurrences.map(o=>o.surface))].map(x=>`<bdi>${E(x)}</bdi>`).join(' · ')}</p>
   <pre dir="ltr">${E(JSON.stringify({keys:n.keys,patterns:n.patterns,includeRefs:n.includeRefs,excludeRefs:n.excludeRefs},null,2))}</pre>
  </details>
 </section>`;
}

function namesPairs(view,pagesCount){
 const items=view.edges.slice(state.nameListPage*20,state.nameListPage*20+20).map(e=>`<button data-name-pair="${E(e.id)}">
  <span>${E(nameNodes.get(e.source).label)} <span class="names-pair-link" aria-hidden="true">↔</span> ${E(nameNodes.get(e.target).label)}</span>
  <strong>${num(e.weight)} <small>آية</small></strong></button>`).join('');
 return `<section class="names-pairs" aria-labelledby="namesPairsTitle">
  <div class="names-panel-heading"><h3 id="namesPairsTitle">الأزواج وشواهدها</h3><span class="names-total">${num(view.edges.length)} زوجًا</span></div>
  <p class="small muted">مرتبة بحسب عدد الآيات المشتركة. افتح الزوج لقراءة شواهده.</p>
  <div class="name-pair-list" tabindex="0" role="region" aria-label="قائمة أزواج الأعلام وأعداد الآيات">${items||'<p class="empty">لا أزواج ضمن النطاق الحالي.</p>'}</div>
  <div class="names-pagination"><button id="namesPrevious" ${!state.nameListPage?'disabled':''}>السابق</button><span>${num(state.nameListPage+1)} من ${num(pagesCount)}</span><button id="namesNext" ${state.nameListPage+1>=pagesCount?'disabled':''}>التالي</button></div>
 </section>`;
}
function renderNamesNetwork(){
 const view=namesScope(),selected=nameNodes.get(state.nameFocus),available=NN.nodes.filter(n=>(state.nameOptional||n.includedByDefault)&&(!state.nameCategory||n.category===state.nameCategory)&&(!state.nameHideDivine||n.category!=='divine'));
 const pagesCount=Math.max(1,Math.ceil(view.edges.length/20));state.nameListPage=Math.min(state.nameListPage,pagesCount-1);
 const advancedCount=Number(!!state.nameCategory)+Number(state.nameMinimum>1)+Number(state.nameOptional)+Number(state.nameHideDivine);
 const scene=view.nodes.length?namesGraph(view.nodes,view.edges):`<section class="names-empty" role="status">
  <h3>لا أسماء مطابقة لهذا النطاق</h3><p><span id="visibleNamesCount">${num(0)}</span> تسمية ظاهرة · <span id="visibleNamesEdges">${num(0)}</span> زوج متصل</p><p>غيّر الاسم أو السورة، أو أعد الضبط.</p></section>`;
 const localRefs=selected?.refs.filter(r=>!state.nameSurah||+r.split(':')[0]===state.nameSurah);
 const selection=selected?`<section class="names-selection">
  <div class="names-panel-heading"><h3>${E(selected.label)}</h3><span class="names-selected-tag">الاسم المحدد</span></div>
  <button class="names-evidence-button" data-name-evidence="${E(selected.id)}">مواضع الاسم في النطاق <strong>${num(localRefs.length)}</strong></button>
 </section>`:'';
 return heading('شبكة أسماء الأعلام','استكشف الأسماء التي تجتمع في الآية نفسها. يزداد سُمك الخط مع عدد الآيات المشتركة، وكل خط يقود إلى شواهده.','الأسماء والآيات المشتركة')+
 `<section class="names-workbench" aria-label="نطاق شبكة الأعلام"><div class="names-primary-controls"><div class="field"><label for="nameFocus">الاسم وجواره المباشر</label><select id="nameFocus"><option value="">جميع الأسماء</option>${options(available.map(n=>[n.id,n.label]),state.nameFocus)}</select></div><div class="field"><label for="nameSurah">نطاق الآيات</label><select id="nameSurah"><option value="0">النص كله</option>${options(corpus.surahs.map(s=>[s.number,`${s.number} · ${s.name}`]),state.nameSurah)}</select></div><div class="names-primary-actions"><button id="resetNames">إعادة الضبط</button><button id="exportNames">تصدير الشبكة</button></div></div>
 <details class="names-advanced" id="nameAdvancedFilters" ${state.nameFiltersOpen?'open':''}><summary><span>مرشحات إضافية ${advancedCount?`<span class="names-filter-count">${num(advancedCount)} مفعّلة</span>`:''}</span><span class="names-summary-hint">نوع الاسم، قوة الخط، والتسميات المحتملة</span></summary><div class="names-advanced-body"><div class="field"><label for="nameCategory">نوع الاسم</label><select id="nameCategory"><option value="">جميع الأنواع</option>${options(Object.entries(nameCategories),state.nameCategory)}</select></div><div class="field"><label for="nameMinimum">أقل عدد آيات مشتركة</label><input id="nameMinimum" type="number" min="1" max="6236" value="${state.nameMinimum}" inputmode="numeric"></div><div class="name-toggles"><label><input id="nameOptional" type="checkbox" ${state.nameOptional?'checked':''}> إظهار التسميات المحتملة أيضًا</label><label><input id="nameHideDivine" type="checkbox" ${state.nameHideDivine?'checked':''}> إخفاء التسميات الإلهية من هذا العرض</label></div></div></details></section>
 <div class="names-explorer">
  ${scene}
  <aside class="names-context" aria-label="مفتاح الرسم والشواهد"><div class="names-context-body">
   ${namesLegend(view.nodes)}${selection}${namesPairs(view,pagesCount)}${selected?nameDetails(selected,view):''}
  </div></aside>
 </div>
 <details class="panel names-method"><summary>كيف تُحسب الشبكة؟ وما حدودها؟</summary><div class="names-method-body"><p class="small">حجم العقدة = عدد آيات الاسم في النطاق. سُمك الخط = مقياس متزايد لوغاريتمي لعدد الآيات المشتركة؛ العدد الدقيق في الشاهد والقائمة. مواضع العقد وحركتها وطول الخط للعرض فقط. الخط بلا اتجاه ولا يثبت سببية أو علاقة تاريخية. قد تحمل الآية عدة أزواج؛ مجموع آيات الأزواج ليس عدد آيات متميزة.</p>${Object.values(NN.policy).map(v=>`<p class="small">${E(v)}</p>`).join('')}<p class="small">السجل يضم ${num(NN.counts.registeredLabels)} تسمية، منها ${num(NN.counts.optionalLabels)} محتملة في طبقة اختيارية. اضغط اسمًا لعرض سبب تعيينه وصور المطابقة الأصلية؛ لم تُستورد أسماء غير ظاهرة في النص.</p></div></details>`;
}
function bindNamesPage(){if(state.page!=='names'||!NN)return;
 const refresh=()=>{state.nameListPage=0;render();};
 $('nameAdvancedFilters').ontoggle=e=>{state.nameFiltersOpen=e.target.open;};
 for(const key of ['nameFocus','nameCategory','nameSurah','nameMinimum'])$(key).onchange=e=>{state[key]=['nameSurah','nameMinimum'].includes(key)?Math.max(key==='nameMinimum'?1:0,Math.min(6236,parseInt(latinDigits(e.target.value),10)||0)):e.target.value;if(key==='nameCategory')state.nameFocus='';refresh();};
 for(const key of ['nameOptional','nameHideDivine'])$(key).onchange=e=>{state[key]=e.target.checked;if(!namesScope().nodes.some(n=>n.id===state.nameFocus))state.nameFocus='';refresh();};
 $('resetNames').onclick=()=>{Object.assign(state,{nameFocus:'',nameCategory:'',nameSurah:0,nameMinimum:1,nameOptional:false,nameHideDivine:false});refresh();};
 $('namesPrevious').onclick=()=>{state.nameListPage--;render();};$('namesNext').onclick=()=>{state.nameListPage++;render();};
 const view=namesScope(),edges=new Map(view.edges.map(e=>[e.id,e]));
 document.querySelectorAll('[data-name-node],[data-name-focus]').forEach(el=>{el.onclick=()=>{state.nameFocus=el.dataset.nameNode||el.dataset.nameFocus;refresh();};el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.onclick();}};});
 document.querySelectorAll('[data-name-edge],[data-name-pair]').forEach(el=>{el.onclick=()=>{const edge=edges.get(el.dataset.nameEdge||el.dataset.namePair);if(edge)namePairDetail(edge);};el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.onclick();}};});
 document.querySelectorAll('[data-name-evidence]').forEach(el=>el.onclick=()=>{const n=nameNodes.get(el.dataset.nameEvidence);showRefList('مواضع الاسم «'+n.label+'»',n.refs.filter(r=>!state.nameSurah||+r.split(':')[0]===state.nameSurah),n.keys||[]);});
 $('exportNames').onclick=()=>download('quran-names-cooccurrence.json',{sourceSha256:NN.metadata.sourceSha256,policy:NN.policy,filters:{focus:state.nameFocus,category:state.nameCategory,surah:state.nameSurah,minimum:state.nameMinimum,optional:state.nameOptional,hideDivine:state.nameHideDivine},...view,rights:DATA.sourceDerivation.copyrightNotice});
}
if(NN){window.QuranTwin.names={NN,nameNodes,namesScope};if(location.hash==='#names')state.page='names';matchMedia('(max-width:699px)').addEventListener('change',()=>{if(state.page==='names')render();});}
