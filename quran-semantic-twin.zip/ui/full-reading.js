'use strict';
const FR=DATA.fullReading,SN=DATA.semanticNetwork,SM=DATA.systemModel;
const unitMap=new Map(FR.units.map(u=>[u.id,u])),semanticNodes=new Map(SN.nodes.map(n=>[n.id,n]));
const studies=Object.values(FR.authoredStudies),studyMap=new Map(studies.map(s=>[s.id,s]));
Object.assign(state,{readingSurah:1,readingUnit:FR.units[0].id,study:studies[0]?.id,studyPage:0,semanticLens:'',semanticPolarity:'',semanticNode:'',semanticPage:0,semanticLimit:35,semanticHops:1,semanticView:'local',semanticStudy:'',modelSystem:'god',modelTab:'summary'});
const systemTitle=id=>SM.systemTitles[id]||id;
const readReview=u=>FR.independentReviews[u.id]?.status==='accepted_as_scoped'?'مراجعة مستقلة مقيدة':'بانتظار المراجعة';
function resolvedStudy(s){return s?.reusesStudy?{...studyMap.get(s.reusesStudy),...s}:s;}
function studyRefs(input){const s=resolvedStudy(input),declared=s.searchScope?.allReferences||s.expandedSearchScope?.references||s.expandedSearchScope?.allReferences;if(declared)return declared;return [...new Set([...(s.usageGroups||[]),...(s.usageComparison||[]),...(s.comparisonCases||[])].flatMap(groupRefs))].sort(refSort);}
function studyKeys(input){const s=resolvedStudy(input);return s.searchScope?.keys||[...(s.expandedSearchScope?.coreKeys||[]),...(s.expandedSearchScope?.comparisonOnlyKeys||[]),...(s.expandedSearchScope?.surfaceSeparatedKey?[s.expandedSearchScope.surfaceSeparatedKey]:[])];}
const groupRefs=g=>g.refs||g.references||g.evidence||(g.ref?[g.ref]:[]);
const readButton=id=>`<button class="chip" data-reading="${E(id)}">قراءة المقطع وسياقه</button>`;
const evidenceBlock=refs=>`${refsHtml(refs)}${refs.length>12?`<button class="chip" data-all-evidence="${E(JSON.stringify(refs))}">جميع الشواهد · ${num(refs.length)}</button>`:''}`;
function confidenceHtml(x){return x?`<p class="small muted"><strong>درجة اليقين:</strong> ${E(x)}</p>`:'';}
function statementHtml(x){if(typeof x==='string')return `<p>${E(x)}</p>`;if(!x)return '';return `<article class="claim">${x.type?badge(x.type):''}${x.authoringStatus==='proposal_pending_reader_review'?badge('صياغة أولية تنتظر إعادة القراءة المحلية','warn'):''}${x.label?`<h4>${E(x.label)}</h4>`:''}<p>${E(x.statement||x.localFunction||x.localMeaning||x.usage||x.role||x.question||(x.source&&x.predicate&&x.target?[x.source,x.predicate,x.target].join(' ← '):x.left&&x.right?x.left+' ⇄ '+x.right:''))}</p>${extraDetails(x)}${x.polarity||x.modality?badge(x.polarity||x.modality,'warn'):''}${confidenceHtml(x.confidence)}${x.limits?`<p class="small"><strong>الحدود:</strong> ${E(x.limits)}</p>`:''}${x.reason?`<p class="small muted">${E(x.reason)}</p>`:''}${evidenceBlock(groupRefs(x))}</article>`;}
function extraDetails(x){const labels={systems:'المنظومات المرتبطة',scope:'مجال الاستنتاج وقيده',form:'الرسم الأصلي',forms:'صور الرسم الأصلية',surface:'الرسم الأصلي للمقارنة',key:'مفتاح البحث',keys:'مفاتيح البحث',matter:'موضوع العلاقة',referenceStatus:'تعيين المرجع',distinctiveContext:'اختلاف السياق',speaker:'جهة القول',actor:'الفاعل',object:'المتعلق',frame:'البناء المحلي',participants:'الأطراف',decision:'قرار المقارنة',relation:'العلاقة',basis:'أساس القراءة',testAgainst:'اختبار مقابل',noImportedDefinition:'حد التعريف'},arrays=new Set(['systems','forms','keys']),isolated=new Set(['form','forms','surface','key','keys']);return Object.entries(labels).filter(([k])=>typeof x[k]==='string'||(arrays.has(k)&&Array.isArray(x[k]))).map(([k,label])=>{const values=Array.isArray(x[k])?x[k]:[x[k]],value=values.map(v=>isolated.has(k)?`<bdi dir="auto">${E(v)}</bdi>`:E(v)).join(' · ');return `<p class="small"><strong>${label}:</strong> ${value}</p>`;}).join('');}
function findingsSection(title,items,open=false){if(!items||!items.length)return '';return `<details class="panel section" ${open?'open':''}><summary>${E(title)} · ${num(items.length)}</summary><div class="section">${items.map(statementHtml).join('')}</div></details>`;}
function renderFullHome(){if(window.QuranWorkbench?.home)return window.QuranWorkbench.home();const accepted=Object.values(FR.independentReviews).filter(r=>r.status==='accepted_as_scoped').length,rs=studies.filter(s=>s.reviewStatus==='independently_reviewed_as_scoped').length;return heading('من النص إلى نموذج قابل للمراجعة','قراءة مكتوبة للنص كله، ودراسات تقارن الاستعمالات، وشبكة تحفظ من قال وما أثبت أو نفى أو شرط. من كل علاقة يمكنك الرجوع إلى النص والسياق.','التوأم المعرفي · الإصدار الدلالي')+
 `<div class="stats"><div class="stat"><span class="value">${num(FR.coverage.sourceAyahs)}</span><span>آية في النص المحفوظ</span></div><div class="stat"><span class="value">${num(FR.units.length)}</span><span>مقطع قراءة مكتوب</span></div><div class="stat"><span class="value">${num(studies.length)}</span><span>دراسة مقارنة لبوابات البحث</span></div><div class="stat"><span class="value">${num(SN.edges.length)}</span><span>علاقة مسندة بشاهد وقيد</span></div></div>
 <div class="notice ${FR.metadata.draft?'':'quiet'}"><strong>${FR.metadata.draft?'نسخة عمل تحت المراجعة':'إصدار مكتوب ومراجع ضمن نطاقه'}</strong><p>المراجعة المستقلة: ${num(accepted)} من ${num(FR.units.length)} مقطع، و${num(rs)} من ${num(studies.length)} دراسة. ${num(SM.systems.filter(s=>s.reviewStatus==='independently_reviewed_as_scoped').length)} توليفًا مراجعًا من ${num(SM.systems.length)} مكتوب. المراجعة تقويم بحثي محدود؛ اعتماد المستخدم حالة مستقلة.</p>${FR.coverage.pendingAuthorshipPairs?`<p data-pending-authorship>تنتظر ${num(FR.coverage.pendingAuthorshipPairs)} مطابقة إعادة تأليف وصف استعمالها المحلي؛ لا تُحسب قراءة دلالية منجزة.</p>`:''}<p>حصر الآيات لا يعني استنفاد كل معنى ممكن. الأسئلة غير المحسومة محفوظة مع أسبابها النصية، وتسميات العقد المتشابهة ليست إثباتًا لوحدة ذواتها أو معانيها.</p></div>
 <div class="panel section names-entry"><div class="row between"><div><h3>شبكة أسماء الأعلام المتحركة</h3><p>كل اسمين في الآية نفسها يرتبطان بخط يزداد سُمكه بحسب عدد الآيات المشتركة. اسحب الأسماء واضغط الخطوط لقراءة شواهدها.</p></div><button class="primary" data-page="names">افتح شبكة الأعلام</button></div></div>
 <div class="grid three section"><button class="panel entry" data-page="reading"><h3>قراءة النص كله</h3><p>انتقل بالآية أو السورة أو المقطع. اعرض العلاقات والملاحظات والأسئلة وجهة القول.</p></button><button class="panel entry" data-page="studies"><h3>مقارنة كل استعمال</h3><p>نطاق البحث الموسع، وفروق الوظائف، والمعنى المركزي وفروعه وحدوده.</p></button><button class="panel entry" data-page="semantic"><h3>الشبكة الدلالية</h3><p>علاقات موجّهة مع الإثبات والنفي والشرط، وموقع التسميات ومقاييسها البنيوية.</p></button></div>
 <section class="panel section"><h3>طبقات يمكن تتبّع اعتمادها</h3><ol class="layer-flow"><li><strong>النص المحفوظ</strong><span>المرفق الأصلي وبصمته</span></li><li><strong>الوحدات والمواضع</strong><span>النص الخام ومفاتيح البحث</span></li><li><strong>المقاطع المقروءة</strong><span>إسناد ومقام وشواهد وأسئلة</span></li><li><strong>المقارنة بين المواضع</strong><span>فصل الاستعمال والمعنى المركزي والفرضية</span></li><li><strong>المنظومات والجسور</strong><span>توليف مقيد بالقراءة والشواهد</span></li></ol><p class="small muted">لا يحل التلازم الإحصائي محل علاقة دلالية مؤلفة. ملفات الإصدار الأول متاحة مستقلة للمقارنة في نهاية قائمة التنقل.</p></section>
 <section class="section"><h3>المنظومات الست عشرة</h3><div class="domain-grid">${Object.entries(SM.systemTitles).map(([id,title])=>`<button class="domain-card" data-model="${id}"><strong>${E(title)}</strong><span>${num(SM.metrics[id]?.relations||0)} سجل علاقة ضمن نطاق العدسة</span></button>`).join('')}</div></section>`;}
function renderFullReading(){const units=FR.units.filter(u=>u.surah===state.readingSurah);let u=unitMap.get(state.readingUnit);if(!u||u.surah!==state.readingSurah)u=units[0];state.readingUnit=u.id;return heading('قراءة النص كله','وحدات متصلة تغطي الآيات، مع بقاء السياق والقول والنفي والشرط. ترتيب المقاطع هو ترتيب النص؛ لا يمثل تواريخ نزول أو أحداث مستوردة.')+
 `<div class="controls"><div class="field"><label for="readingSurah">السورة</label><select id="readingSurah">${options(corpus.surahs.map(s=>[s.number,`${s.number} · ${s.name}`]),state.readingSurah)}</select></div><div class="field grow"><label for="readingUnit">المقطع في ترتيب النص</label><select id="readingUnit">${options(units.map(x=>[x.id,`${x.surah}:${x.start}–${x.end} · ${x.summary.slice(0,90)}`]),u.id)}</select></div><form id="readingGo" class="field"><label for="readingRef">انتقال بمرجع آية</label><div class="row"><input id="readingRef" dir="ltr" placeholder="49:6"><button>انتقل</button></div></form></div>
 <div class="row between section"><div>${badge(u.kind)} ${badge(readReview(u),'warn')}</div><div class="row"><button id="previousUnit" ${FR.units[0].id===u.id?'disabled':''}>المقطع السابق</button><button id="nextUnit" ${FR.units.at(-1).id===u.id?'disabled':''}>المقطع التالي</button><button id="exportUnit">تصدير القراءة</button></div></div>
 <section class="panel section"><h3>${E(surahMap.get(u.surah).name)} · <bdi>${u.surah}:${u.start}–${u.end}</bdi></h3><p>${E(u.summary)}</p><div class="chips">${u.lenses.map(l=>`<button class="chip" data-model="${E(l.id)}">${E(systemTitle(l.id))}</button>`).join('')}</div><details class="section"><summary>أساس اختيار العدسات</summary>${u.lenses.map(l=>statementHtml({label:systemTitle(l.id),statement:l.basis,evidence:l.evidence})).join('')}</details></section>
 <div class="grid two section"><section><h3>النص الخام</h3>${Array.from({length:u.end-u.start+1},(_,i)=>ayahHtml(`${u.surah}:${u.start+i}`)).join('')}</section><section><h3>العلاقات المسندة · ${num(u.relations.length)}</h3>${u.relations.map((r,i)=>relationCard({...r,id:`${u.id}::r${i}`,unit:u.id},false)).join('')}${findingsSection('الملاحظات',u.observations)}${findingsSection('المقابلات',u.contrasts)}${findingsSection('المفاهيم ووظائفها',u.concepts)}${findingsSection('أسئلة غير محسومة',u.openQuestions,true)}</section></div>
 <details class="panel section"><summary>استعمالات بوابات البحث في هذا المقطع · ${num(u.seedUsages.length)}</summary>${u.seedUsages.map(g=>statementHtml({...g,label:conceptMap.get(g.conceptId)?.label||g.conceptId,evidence:g.refs})).join('')}</details><div class="source-timeline section"><h3>المقاطع المجاورة في ترتيب النص</h3>${FR.units.slice(Math.max(0,FR.units.indexOf(u)-2),FR.units.indexOf(u)+3).map(x=>`<button class="timeline-item ${x.id===u.id?'active':''}" data-reading="${E(x.id)}"><bdi>${x.surah}:${x.start}–${x.end}</bdi><span>${E(x.summary)}</span></button>`).join('')}</div>`;}
function relationCard(r,link=true){return `<article class="claim relation-card"><div class="row between">${relationTypeLabel(r.polarity)}<bdi class="small muted">${r.evidence.map(E).join(' · ')}</bdi></div><h4>${E(r.sourceLabel||r.source)} <span class="relation-arrow">← ${E(r.predicate)} ←</span> ${E(r.targetLabel||r.target)}</h4><p class="small"><strong>المجال وجهة القول:</strong> ${E(r.scope)}</p><blockquote class="quran quote">${E(r.quote)}</blockquote>${confidenceHtml(r.confidence)}${evidenceBlock(r.evidence)}${link?readButton(r.unit):''}</article>`;}
function renderStudies(){const s=resolvedStudy(studyMap.get(state.study)||studies[0]),gs=s.usageGroups||s.usageComparison||[],scope=s.searchScope||s.expandedSearchScope||{},rr=studyRefs(s),units=scope.unitCount??scope.candidateUnits??s.rawUnits?.length??studyKeys(s).reduce((n,k)=>n+(termMap.get(k)?.count||0),0),gpage=state.studyPage;return heading('الدراسات المقارنة','كل دراسة تعلن صور بحثها، وتقارن مواضعها، وتختبر الحدود والشواهد المختلفة. البوابات الثماني والثمانون نقاط دخول؛ مفاهيم القراءة الكلية أوسع منها.')+
 `<div class="controls"><div class="field grow"><label for="studySelect">المفهوم أو بوابة البحث</label><select id="studySelect">${options(studies.map(x=>[x.id,x.title]),s.id)}</select></div><form id="studySearch" class="field grow"><label for="studyQuery">بحث في أسماء الدراسات</label><div class="row"><input id="studyQuery"><button>ابحث</button></div></form><button id="exportStudy">تصدير الدراسة كاملة</button></div><div id="studyMatches" class="chips"></div>
 <section class="panel section"><div class="row between"><h3>${E(s.title)}</h3>${badge(s.reviewStatus==='independently_reviewed_as_scoped'?'مراجعة مستقلة مقيدة':'بانتظار المراجعة','warn')}</div><p>${num(typeof units==='number'?units:0)} وحدة بحث مرشحة · ${num(rr.length||scope.candidateAyahs||0)} آية في النطاق المعلن · ${num(gs.length)} مجموعة مقارنة.</p><p class="small muted">قد يتضمن النطاق مقارنات مفصولة دلاليًا. عدد المطابقات لا يساوي عدد الاستعمالات المنتمية إلى المعنى المركزي.</p>${statementHtml(s.centralMeaning)}${s.reusesStudy?`<p>تعيد هذه البوابة استخدام دراسة ذات نطاق مطابق: <button class="chip" data-study="${E(s.reusesStudy)}">افتح المقارنة المشتركة</button></p>`:''}<div class="row"><button id="allStudyRefs">جميع مواضع النطاق</button><button id="studyNetwork">موضع التسمية في الشبكة</button></div><details class="section"><summary>صور البحث وحدود الحصر</summary><div class="chips">${studyKeys(s).map(k=>`<button class="chip" data-word="${E(k)}">${E(k)}</button>`).join('')}</div><p class="small">${E(scope.scopeLimit||scope.scopeWarning||s.rawEvidencePolicy||s.method||'تحفظ مطابقة الرسم منفصلة عن الانتماء الدلالي.')}</p><pre dir="ltr">${E(JSON.stringify(scope,null,2))}</pre></details></section>
 <section class="section"><div class="row between"><h3>مقارنة الاستعمالات</h3><div class="row"><button id="studyPrevious" ${gpage===0?'disabled':''}>السابق</button><span class="small">${num(gpage+1)} / ${num(Math.max(1,Math.ceil(gs.length/10)))}</span><button id="studyNext" ${(gpage+1)*10>=gs.length?'disabled':''}>التالي</button></div></div><div class="grid two">${gs.slice(gpage*10,gpage*10+10).map(statementHtml).join('')}</div></section>
 ${findingsSection('العلاقات بين المنظومات',s.crossSystemRelations)}${findingsSection('البيانات والمقارنات المخالفة',s.comparisonCases)}${findingsSection('الملاحظات',s.observations)}${findingsSection('الأنماط',s.patterns)}${findingsSection('الاستنتاجات',s.inferences)}${findingsSection('الفرضيات',s.hypotheses)}${findingsSection('أدلة العائلة اللفظية',Array.isArray(s.familyEvidence)?s.familyEvidence:[])}${findingsSection('النتائج المقيدة',s.finalBoundedResults,true)}${findingsSection('الأسئلة وحدود الحسم',s.openQuestions,true)}${s.additionalLensObservation?findingsSection('ملاحظة العدسة المشتركة',[s.additionalLensObservation],true):''}
 <details class="panel section"><summary>سجل المراجعة ومصدر القراءة</summary><p class="small">كل صورة وموضع أصليان محفوظان في تصدير الدراسة. بصمة المصدر <bdi class="hash">${E(s.sourceSha256)}</bdi>.</p><pre dir="ltr">${E(JSON.stringify(s.independentReview||{status:s.reviewStatus},null,2))}</pre></details>`;}
function semanticEdges(){const studyScope=state.semanticStudy?new Set(studyRefs(studyMap.get(state.semanticStudy))):null;const base=SN.edges.filter(e=>(!studyScope||e.evidence.some(r=>studyScope.has(r)))&&(!state.semanticLens||(SM.edgeLenses[e.id]||[]).includes(state.semanticLens))&&(!state.semanticPolarity||e.polarity===state.semanticPolarity));if(!state.semanticNode)return base;const perUnit=new Map();for(const e of base){if(!perUnit.has(e.unit))perUnit.set(e.unit,[]);perUnit.get(e.unit).push(e);}const chosen=new Set();for(const local of perUnit.values()){let reached=new Set([state.semanticNode]);for(let hop=0;hop<state.semanticHops;hop++){const next=new Set(reached);for(const e of local)if(reached.has(e.source)||reached.has(e.target)){chosen.add(e.id);next.add(e.source);next.add(e.target);}reached=next;}}return base.filter(e=>chosen.has(e.id));}
function localNetworkView(nodes,edges){if(state.semanticView==='labels')return {nodes,edges};const local=new Map(),shown=[];for(const e of edges){const ids=[e.unit+'::'+e.source,e.unit+'::'+e.target],add=ids.filter(id=>!local.has(id));if(local.size+new Set(add).size>state.semanticLimit)continue;for(const [id,gid] of [[ids[0],e.source],[ids[1],e.target]])if(!local.has(id)){const u=unitMap.get(e.unit);local.set(id,{...semanticNodes.get(gid),id,groupId:gid,scopeCaption:`${u.surah}:${u.start}–${u.end}`});}shown.push({...e,source:ids[0],target:ids[1]});}return {nodes:[...local.values()],edges:shown};}

// The same categorical color and dash encode a record in the scene, key and list.
const relationEncoding = {
  'إثبات': {token:'--rel-assertion', dash:'none'},
  'نفي': {token:'--rel-negation', dash:'8 4'},
  'نقل قول': {token:'--rel-quote', dash:'2 4'},
  'شرط': {token:'--rel-conditional', dash:'10 4 2 4'},
  'سؤال': {token:'--rel-question', dash:'5 3 2 3'},
  'تشبيه': {token:'--rel-simile', dash:'12 4 5 4'},
};
function relationStyle(polarity){
  const {token,dash}=relationEncoding[polarity]||{token:'--muted',dash:'none'};
  return {color:`var(${token}, var(--muted))`,dash};
}
function relationTypeLabel(polarity){
  const {color,dash}=relationStyle(polarity);
  return `<span class="semantic-type-label" data-relation-kind="${E(polarity)}"><svg viewBox="0 0 38 10" width="38" height="10" aria-hidden="true"><line x1="2" y1="5" x2="36" y2="5" stroke="${color}" stroke-width="3" stroke-dasharray="${dash}" stroke-linecap="round"/></svg>${E(polarity)}</span>`;
}
function authoredNetworkGraph(nodes,edges){
  const compact=window.matchMedia('(max-width: 640px)').matches;
  const width=compact?510:850;
  const height=compact?490:560;
  const positions=new Map(nodes.map((node,index)=>{
    const angle=index*2.399963;
    const radius=Math.sqrt((index+.5)/nodes.length);
    return [node.id,{x:width/2+width*.38*radius*Math.cos(angle),y:height/2+height*.39*radius*Math.sin(angle)}];
  }));
  const lines=edges.map(edge=>{
    const source=positions.get(edge.source),target=positions.get(edge.target);
    if(!source||!target)return '';
    const dx=target.x-source.x,dy=target.y-source.y,distance=Math.hypot(dx,dy)||1;
    const endpoints=`x1="${source.x+dx/distance*8}" y1="${source.y+dy/distance*8}" x2="${target.x-dx/distance*9}" y2="${target.y-dy/distance*9}"`;
    const {color,dash}=relationStyle(edge.polarity);
    const label=E([edge.sourceLabel,edge.predicate,edge.targetLabel,edge.polarity].join(' · '));
    return `<g class="semantic-edge" data-motion-source="${E(edge.source)}" data-motion-target="${E(edge.target)}" data-semantic-edge="${E(edge.id)}" data-relation-kind="${E(edge.polarity)}" tabindex="0" role="button" aria-label="${label}"><line class="semantic-edge-hit" ${endpoints} stroke="transparent" stroke-width="14"/><line class="semantic-edge-line" ${endpoints} stroke="${color}" stroke-width="2.5" stroke-dasharray="${dash}" stroke-linecap="round" marker-end="url(#semanticArrow)"/><title>${label}</title></g>`;
  }).join('');
  const points=nodes.map(node=>{
    const {x,y}=positions.get(node.id);
    const group=node.groupId||node.id;
    const selected=group===state.semanticNode;
    const label=E(node.label+(node.scopeCaption?' · '+node.scopeCaption:''));
    return `<g class="semantic-node" data-motion-node="${E(node.id)}" data-semantic-node="${E(group)}" tabindex="0" role="button" aria-pressed="${selected}" aria-label="${label}"><circle class="semantic-node-dot" cx="${x}" cy="${y}" r="${selected?9:7}"/><circle class="semantic-node-hit" cx="${x}" cy="${y}" r="18"/><text class="semantic-node-name" x="${x}" y="${y-17}" text-anchor="middle">${E(node.label.slice(0,38))}</text>${node.scopeCaption?`<text class="semantic-node-ref" x="${x}" y="${y+24}" text-anchor="middle">${E(node.scopeCaption)}</text>`:''}<title>${label}</title></g>`;
  }).join('');
  return `<div class="chart-shell semantic-chart"><div class="graph-view-actions semantic-scene-bar"><span><strong>مساحة الرسم</strong><small>${num(nodes.length)} عقدة · ${num(edges.length)} وصلة</small></span>${nodes.length?'<button data-expand-graph aria-pressed="false">توسيع الرسم</button>':''}</div><svg viewBox="0 0 ${width} ${height}" role="group" aria-label="شبكة علاقات دلالية موجّهة. تفاصيل كل وصلة في السجل النصي."><defs><marker id="semanticArrow" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="9" markerHeight="9" markerUnits="userSpaceOnUse" orient="auto"><path d="M0 0L10 5L0 10Z" fill="context-stroke"/></marker></defs>${lines}${points}${nodes.length?'':`<text class="semantic-empty-label" x="${width/2}" y="${height/2}" text-anchor="middle">لا وصلات ظاهرة ضمن النطاق</text>`}</svg></div>`;
}
function representativeEdges(edges,limit){const seen=new Set(),chosen=[],extra=[];for(const e of edges){const key=e.source+'::'+e.target+'::'+e.polarity;if(!seen.has(key)){seen.add(key);chosen.push(e);}else extra.push(e);}return [...chosen,...extra].slice(0,limit);}
function semanticLegend(edges){
  const counts=new Map();
  for(const edge of edges)counts.set(edge.polarity,(counts.get(edge.polarity)||0)+1);
  const rows=Object.keys(relationEncoding).map(polarity=>{
    const selected=state.semanticPolarity===polarity;
    const buttonId='semantic-type-'+relationEncoding[polarity].token.slice(6);
    return `<li><button type="button" id="${buttonId}" data-semantic-type-filter="${E(polarity)}" aria-pressed="${selected}" aria-label="ترشيح ${E(polarity)} · ${num(counts.get(polarity)||0)} وصلة في الرسم">${relationTypeLabel(polarity)}<span class="semantic-key-count">${num(counts.get(polarity)||0)}</span></button></li>`;
  }).join('');
  return `<section class="semantic-key"><div class="semantic-inspector-heading"><h3>مفتاح الإسناد</h3><p class="small muted">اللون ونمط الخط يحددان النوع. العدد للوصلات في الرسم.</p></div><ul class="semantic-key-list">${rows}</ul></section>`;
}
function semanticRecordList(edges){
  const page=state.semanticPage;
  const records=edges.slice(page*10,page*10+10).map(edge=>`<li><button class="semantic-record" type="button" data-semantic-record="${E(edge.id)}"><span class="semantic-record-meta">${relationTypeLabel(edge.polarity)}<bdi>${E(edge.evidence[0]||'')}</bdi></span><strong>${E(edge.sourceLabel)} <span aria-hidden="true">←</span> ${E(edge.targetLabel)}</strong><span class="semantic-record-predicate">${E(edge.predicate)}</span><span class="semantic-record-action">الشاهد والسياق <span aria-hidden="true">←</span></span></button></li>`).join('');
  return `<section class="semantic-records"><div class="semantic-inspector-heading"><h3>سجل العلاقات <bdi>${num(edges.length)}</bdi></h3><p class="small muted">اختر سجلًا لقراءة شاهده ومجاله.</p></div>${records?`<ol class="semantic-record-list">${records}</ol>`:'<p class="empty">لا علاقات بهذه المرشحات.</p>'}<div class="semantic-pagination"><button id="semanticPrevious" ${page===0?'disabled':''}>السابق</button><bdi class="small" aria-label="صفحة ${num(page+1)} من ${num(Math.max(1,Math.ceil(edges.length/10)))}">${num(page+1)} / ${num(Math.max(1,Math.ceil(edges.length/10)))}</bdi><button id="semanticNext" ${(page+1)*10>=edges.length?'disabled':''}>التالي</button></div></section>`;
}
function semanticSelection(node){
  if(!node)return '';
  return `<details class="semantic-selection"><summary>موقع «${E(node.label)}» وشواهده</summary><dl><div><dt>تسميات مجاورة مختلفة</dt><dd>${num(node.degree)}</dd></div><div><dt>سجل وارد</dt><dd>${num(node.incomingRecords)}</dd></div><div><dt>سجل صادر</dt><dd>${num(node.outgoingRecords)}</dd></div><div><dt>مقطع في الشبكة كلها</dt><dd>${num(node.units.length)}</dd></div></dl><p class="small muted">المقاييس بنيوية فوق التسميات المكتوبة، وتشمل القول والنفي والشرط. أثر التسمية يُقرأ من الأفعال والمجالات التالية.</p>${evidenceBlock(node.evidence)}</details>`;
}
function renderSemantic(){
  const edges=semanticEdges();
  const counts=new Map();
  for(const edge of edges)for(const id of [edge.source,edge.target])counts.set(id,(counts.get(id)||0)+1);
  let nodes=[...counts].sort((a,b)=>b[1]-a[1]).slice(0,state.semanticLimit).map(([id])=>semanticNodes.get(id));
  const selected=semanticNodes.get(state.semanticNode);
  if(selected&&!nodes.some(node=>node.id===selected.id))nodes=[selected,...nodes.slice(0,-1)];
  const ids=new Set(nodes.map(node=>node.id));
  const candidates=representativeEdges(edges.filter(edge=>ids.has(edge.source)&&ids.has(edge.target)),100);
  const view=localNetworkView(nodes,candidates);
  return heading('شبكة العلاقات الدلالية','استكشف علاقات القراءة وشواهدها. اضغط وصلة أو سجلًا لفتح الاقتباس ونطاقه.','مساحة الاستكشاف')+
    `<div class="controls semantic-controls">
      <div class="field"><label for="semanticLens">عدسة المنظومة</label><select id="semanticLens"><option value="">كل العدسات</option>${options(Object.entries(SM.systemTitles),state.semanticLens)}</select></div>
      <div class="field"><label for="semanticStudy">شواهد دراسة</label><select id="semanticStudy"><option value="">كل الدراسات</option>${options(studies.map(s=>[s.id,s.title]),state.semanticStudy)}</select></div>
      <div class="field"><label for="semanticPolarity">نوع الإسناد</label><select id="semanticPolarity"><option value="">كل الأنواع</option>${options([...new Set(SN.edges.map(e=>e.polarity))].map(p=>[p,p]),state.semanticPolarity)}</select></div>
      <div class="field"><label for="semanticNode">تسمية في الرسم</label><select id="semanticNode"><option value="">كل التسميات</option>${options(SN.nodes.slice().sort((a,b)=>a.label.localeCompare(b.label,'ar')).map(n=>[n.id,n.label]),state.semanticNode)}</select></div>
      <div class="field"><label for="semanticView">طبقة العقد</label><select id="semanticView">${options([['local','تسمية داخل مقطعها'],['labels','فهرس التسميات المتطابقة']],state.semanticView)}</select></div>
      <div class="field"><label for="semanticHops">امتداد الجوار</label><select id="semanticHops">${options([[1,'صلة مباشرة'],[2,'صلتان متتابعتان']],state.semanticHops)}</select></div>
      <div class="field"><label for="semanticLimit">حد العقد الظاهرة</label><select id="semanticLimit">${options([20,35,50].map(n=>[n,num(n)]),state.semanticLimit)}</select></div>
      <button id="exportSemantic">تصدير النطاق</button>
    </div>
    <div class="semantic-workspace">
      ${authoredNetworkGraph(view.nodes,view.edges)}
      <aside class="semantic-inspector" aria-label="مفتاح الرسم وسجل العلاقات">${semanticLegend(view.edges)}${semanticSelection(selected)}${semanticRecordList(edges)}</aside>
    </div>
    <details class="semantic-scope"><summary>نطاق الرسم وطريقة قراءته</summary><p class="small muted">السهم يتبع مصدر العلاقة إلى هدفها. كل وصلة سجل قراءة له شاهد واقتباس ونوع ومجال. وجود أمر أو دعاء في السجل لا يعني وقوع الفعل المطلوب، ويحدد مجال الكلام ذلك مع الشاهد. يعرض السجل والتصدير جميع العلاقات ضمن المرشحات.</p><p class="small muted">ترتيب النقاط بصري ولا يدل على قرب معنوي. نطاق الدراسة يرشح العلاقات بشواهد صور بحثها، ويشمل المقارنات المفصولة دون إثبات هوية كل تسمية. الامتداد إلى صلتين يبقى داخل كل مقطع. لا تصل ضمائر مقطعين لمجرد تطابق اسميهما. طبقة الفهرس تجمع الكتابة فقط، ولا تنشئ علاقة دلالية أو سببية جديدة. مقاييس التسميات تصف الجوار البنيوي ولا تقيس الأهمية القيمية.</p></details>`;
}
function renderModel(){const s=SM.systems.find(s=>s.id===state.modelSystem),m=SM.metrics[state.modelSystem]||{},bridges=SM.bridges.filter(b=>b.sourceSystem===state.modelSystem||b.targetSystem===state.modelSystem);return heading('المنظومات والجسور','توليفات مبنية على القراءة والمقارنة. حدود المنظومات عدسات تنظيمية متداخلة طلبها المستخدم؛ الجسر الدلالي يحمل دعواه وشاهده، والمصفوفة تحسب اشتراك التعليقات فقط.')+
 `<div class="controls"><div class="field grow"><label for="modelSystem">المنظومة</label><select id="modelSystem">${options(Object.entries(SM.systemTitles),state.modelSystem)}</select></div><div class="field"><label for="modelTab">وسيلة العرض</label><select id="modelTab">${options([['summary','التوليف وشجرة المكونات'],['flow','تدفق السجلات بحسب النوع'],['matrix','مصفوفة اشتراك العدسات'],['bridges','شبكة الجسور النصية']],state.modelTab)}</select></div><button id="modelToNetwork">استكشف علاقات المنظومة</button><button id="exportModel">تصدير النموذج</button></div>
 <div class="stats"><div class="stat"><span class="value">${num(m.units)}</span><span>مقطع ضمن نطاق العدسة</span></div><div class="stat"><span class="value">${num(m.ayahs)}</span><span>آية في نطاق المقاطع</span></div><div class="stat"><span class="value">${num(m.relations)}</span><span>سجل علاقة</span></div><div class="stat"><span class="value">${num(m.literalLabels)}</span><span>تسمية في طرف علاقة</span></div></div><p class="small muted">هذه أعداد التعليقات المقروءة في نطاق العدسة، وليست قياسًا لكثافة كل معنى في النص أو لأهمية المنظومة. عدسة العلاقات الجامعة تضم كل المقاطع بقاعدة معلنة.</p>
 ${state.modelTab==='matrix'?systemMatrix():state.modelTab==='flow'?systemFlow(m):state.modelTab==='bridges'?systemBridges(bridges):s?`<section class="panel section"><div class="row between"><h3>${E(s.title)}</h3>${badge(s.reviewStatus==='independently_reviewed_as_scoped'?'توليف مراجع ضمن نطاقه':'توليف تحت المراجعة','warn')}</div>${statementHtml(s.definition)}<div class="mind-tree"><div class="mind-root">${E(s.title)}</div><div class="mind-branches">${s.components.map(c=>`<section class="mind-leaf"><h4>${E(c.label)}</h4><p>${E(c.role)}</p>${confidenceHtml(c.confidence)}${evidenceBlock(c.evidence)}</section>`).join('')}</div></div></section>${findingsSection('دعاوى التوليف ومستوياتها',s.claims,true)}${findingsSection('الأسئلة والحدود',s.openQuestions,true)}${systemBridges(bridges)}`:'<div class="notice section">لم يكتمل تأليف توليف هذه المنظومة في نسخة العمل الحالية.</div>'}
 <details class="panel section"><summary>المقاطع التي بني عليها نطاق العدسة</summary><div class="reading-index">${(SM.unitIndex[state.modelSystem]||[]).map(id=>{const u=unitMap.get(id);return `<button data-reading="${E(id)}"><bdi>${u.surah}:${u.start}–${u.end}</bdi> ${E(u.summary.slice(0,180))}</button>`;}).join('')}</div></details>`;}
function systemMatrix(){
  const entries=Object.entries(SM.systemTitles);
  const max=Math.max(...entries.flatMap(([a])=>entries.filter(([b])=>a!==b).map(([b])=>SM.unitCoannotationMatrix[a][b])),1);
  const columns=entries.map(([,title])=>`<th scope="col">${E(title)}</th>`).join('');
  const rows=entries.map(([a,title])=>{
    const cells=entries.map(([b])=>{
      const count=SM.unitCoannotationMatrix[a][b];
      const diagonal=a===b;
      const label=diagonal?`${title} · المقاطع الموسومة`:`${title} مع ${systemTitle(b)}`;
      return `<td><button type="button" data-matrix-lenses="${E(a+':'+b)}" ${diagonal?'class="matrix-diagonal"':`style="${sequenceStyle(count/max)}"`} aria-label="${E(label)} · ${num(count)} مقطع">${num(count)}</button></td>`;
    }).join('');
    return `<tr><th scope="row">${E(title)}</th>${cells}</tr>`;
  }).join('');
  return `<section class="panel section"><h3>اشتراك تعليقات العدسات</h3><p class="small muted">كل خلية خارج القطر تعدّ المقاطع التي اختار قارئها العدستين مع تعليل. الخلايا المؤطّرة على القطر تعدّ المقاطع الموسومة بكل عدسة. الاشتراك يصف التعليقات، وتعرض عدسة العلاقات التعليقات الأصلية في هذه المصفوفة.</p><div class="matrix-key">${sequenceLegend('عدد المقاطع المشتركة خارج القطر',num(0),num(max))}<span class="matrix-diagonal-key"><i aria-hidden="true"></i> عدد المقاطع الموسومة</span></div><div class="matrix-scroll" tabindex="0" role="region" aria-label="جدول اشتراك العدسات قابل للتمرير"><table class="data-table annotation-matrix"><thead><tr><th scope="col">العدسة</th>${columns}</tr></thead><tbody>${rows}</tbody></table></div></section>`;
}
function systemFlow(metrics){
  const counts=Object.entries(metrics.polarity||{});
  const total=counts.reduce((sum,[,count])=>sum+count,0);
  const bars=counts.map(([polarity,count])=>{
    const percent=total?100*count/total:0;
    return `<button class="flow-branch" type="button" data-flow-polarity="${E(polarity)}" aria-label="${E(polarity)} · ${num(count)} سجلًا"><span class="flow-branch-label">${relationTypeLabel(polarity)}<bdi>${num(count)}</bdi></span><span class="flow-track" aria-hidden="true"><span class="stream" style="width:${percent}%;background:${relationStyle(polarity).color}"></span></span></button>`;
  }).join('');
  return `<section class="panel section"><h3>سجلات «${E(systemTitle(state.modelSystem))}» بحسب نوع الإسناد</h3><p class="small muted">طول كل شريط يمثل حصة نوع الإسناد من سجلات العدسة. قد يحمل المقطع عدة عدسات، لذلك تتداخل أعداد العدسات.</p><div class="flow-chart"><div class="flow-origin"><span>مجموع السجلات</span><strong><bdi>${num(total)}</bdi></strong></div><div class="flow-streams">${bars||'<p class="empty">لا سجلات في هذه العدسة.</p>'}<div class="flow-axis" aria-hidden="true"><bdi>0%</bdi><bdi>50%</bdi><bdi>100%</bdi></div></div></div></section>`;
}
function systemBridges(bridges){return `<section class="panel section"><h3>الجسور الدلالية المعللة · ${num(bridges.length)}</h3><p class="small muted">كل جسر دعوى عابرة للمنظومات، لا نتيجة مستخرجة من اشتراك الكلمات وحده.</p><div class="bridge-list">${bridges.map(b=>`<article class="claim"><div class="bridge-path"><button data-model="${E(b.sourceSystem)}">${E(systemTitle(b.sourceSystem))}</button><span aria-label="متصل بـ">←</span><button data-model="${E(b.targetSystem)}">${E(systemTitle(b.targetSystem))}</button></div><p>${E(b.predicate)}</p>${confidenceHtml(b.confidence)}<p class="small">${E(b.limits||'')}</p>${evidenceBlock(b.evidence)}</article>`).join('')||'<p>لا جسر مؤلف في هذا النطاق.</p>'}</div></section>`;}
function goReading(id){const u=unitMap.get(id);if(!u)return;closeDialog();state.readingUnit=id;state.readingSurah=u.surah;navigate('reading');}
function openSemanticRecord(id){
  const record=SN.edges.find(edge=>edge.id===id);
  if(!record)return;
  $('evidenceTitle').textContent='علاقة وشاهدها ومجالها';
  $('evidenceBody').innerHTML=relationCard(record)+record.evidence.map(ref=>ayahHtml(ref)).join('');
  $('evidenceBody').querySelectorAll('[data-ref]').forEach(button=>button.onclick=()=>showEvidence(button.dataset.ref));
  bindFullCommon();
  openDialog();
}
function bindFullCommon(){document.querySelectorAll('[data-reading]').forEach(b=>b.onclick=()=>goReading(b.dataset.reading));document.querySelectorAll('[data-study]').forEach(b=>b.onclick=()=>{state.study=b.dataset.study;state.studyPage=0;navigate('studies');});document.querySelectorAll('[data-model]').forEach(b=>b.onclick=()=>{state.modelSystem=b.dataset.model;navigate('model');});document.querySelectorAll('[data-all-evidence]').forEach(b=>b.onclick=()=>showRefList('جميع شواهد هذه الدعوى',JSON.parse(b.dataset.allEvidence)));}
function bindFullPage(){bindFullCommon();
 if(state.page==='reading'){
  $('readingSurah').onchange=e=>{state.readingSurah=+e.target.value;render();};$('readingUnit').onchange=e=>goReading(e.target.value);
  $('readingGo').onsubmit=e=>{e.preventDefault();const ref=latinDigits($('readingRef').value).replace(/\s/g,'');if(FR.verseToUnit[ref])goReading(FR.verseToUnit[ref]);else announce('مرجع الآية غير موجود.');};
  const i=FR.units.findIndex(u=>u.id===state.readingUnit);$('previousUnit').onclick=()=>goReading(FR.units[i-1]?.id);$('nextUnit').onclick=()=>goReading(FR.units[i+1]?.id);$('exportUnit').onclick=()=>download('authored-reading.json',{sourceSha256:DATA.build.sourceSha256,unit:unitMap.get(state.readingUnit),review:FR.independentReviews[state.readingUnit],rights:DATA.sourceDerivation.copyrightNotice});
 }
 if(state.page==='studies'){
  const s=studyMap.get(state.study)||studies[0];$('studySelect').onchange=e=>{state.study=e.target.value;state.studyPage=0;render();};$('studyPrevious').onclick=()=>{state.studyPage--;render();};$('studyNext').onclick=()=>{state.studyPage++;render();};$('allStudyRefs').onclick=()=>showRefList(s.title,studyRefs(s),studyKeys(s));$('exportStudy').onclick=()=>download(s.id+'.json',{...s,rights:DATA.sourceDerivation.copyrightNotice});
  $('studySearch').onsubmit=e=>{e.preventDefault();const q=norm($('studyQuery').value);$('studyMatches').innerHTML=studies.filter(s=>norm(s.title).includes(q)).map(s=>`<button class="chip" data-study="${E(s.id)}">${E(s.title)}</button>`).join('')||'<p>لا دراسة بهذا الاسم.</p>';bindFullCommon();};
  $('studyNetwork').onclick=()=>{state.semanticStudy=s.id;state.semanticNode='';state.semanticLens='';state.semanticPolarity='';state.semanticPage=0;navigate('semantic');};
 }
 if(state.page==='semantic'){
  for(const key of ['semanticLens','semanticStudy','semanticPolarity','semanticNode','semanticLimit','semanticHops','semanticView'])$(key).onchange=e=>{state[key]=['semanticLimit','semanticHops'].includes(key)?+e.target.value:e.target.value;state.semanticPage=0;render();};
  $('semanticPrevious').onclick=()=>{state.semanticPage--;render();};$('semanticNext').onclick=()=>{state.semanticPage++;render();};$('exportSemantic').onclick=()=>download('scoped-semantic-network.json',{sourceSha256:DATA.build.sourceSha256,policy:SN.metricsPolicy,nodes:SN.nodes.filter(n=>semanticEdges().some(e=>e.source===n.id||e.target===n.id)),edges:semanticEdges(),rights:DATA.sourceDerivation.copyrightNotice});
  document.querySelectorAll('[data-semantic-node]').forEach(b=>{b.onclick=()=>{state.semanticNode=b.dataset.semanticNode;state.semanticPage=0;render();};b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();b.onclick();}};});
  document.querySelectorAll('[data-semantic-edge]').forEach(b=>{b.onclick=()=>openSemanticRecord(b.dataset.semanticEdge);b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();b.onclick();}};});
  document.querySelectorAll('[data-semantic-record]').forEach(button=>button.onclick=()=>openSemanticRecord(button.dataset.semanticRecord));
  document.querySelectorAll('[data-semantic-type-filter]').forEach(button=>button.onclick=()=>{
    const select=$('semanticPolarity');
    select.value=select.value===button.dataset.semanticTypeFilter?'':button.dataset.semanticTypeFilter;
    select.dispatchEvent(new Event('change'));
  });
 }
 if(state.page==='model'){
  $('modelSystem').onchange=e=>{state.modelSystem=e.target.value;render();};$('modelTab').onchange=e=>{state.modelTab=e.target.value;render();};$('modelToNetwork').onclick=()=>{state.semanticLens=state.modelSystem;state.semanticStudy='';state.semanticNode='';state.semanticPolarity='';state.semanticPage=0;navigate('semantic');};$('exportModel').onclick=()=>download('system-model.json',{...SM,rights:DATA.sourceDerivation.copyrightNotice});
  document.querySelectorAll('[data-flow-polarity]').forEach(b=>b.onclick=()=>{state.semanticLens=state.modelSystem;state.semanticStudy='';state.semanticPolarity=b.dataset.flowPolarity;state.semanticNode='';state.semanticPage=0;navigate('semantic');});
  document.querySelectorAll('[data-matrix-lenses]').forEach(b=>b.onclick=()=>{const[a,c]=b.dataset.matrixLenses.split(':');const us=FR.units.filter(u=>u.lenses.some(l=>l.id===a)&&u.lenses.some(l=>l.id===c));$('evidenceTitle').textContent=systemTitle(a)+' مع '+systemTitle(c);$('evidenceBody').innerHTML=us.map(u=>`<article class="claim"><p>${E(u.summary)}</p>${readButton(u.id)}</article>`).join('')||'<p>لا تعليقات مشتركة.</p>';bindFullCommon();openDialog();});
 }
 if(state.page==='word'&&state.word){const related=studies.filter(s=>studyKeys(s).includes(state.word));if(related.length){$('view').insertAdjacentHTML('beforeend',`<section class="panel section"><h3>هذا المفتاح في الدراسات المقارنة</h3><p class="small muted">الدراسة تفصل الوظائف والتصادمات؛ المفتاح وحده ليس معنى.</p><div class="chips">${related.map(s=>`<button class="chip" data-study="${E(s.id)}">${E(s.title)}</button>`).join('')}</div></section>`);bindFullCommon();}}
 if(['systems','relations','claims'].includes(state.page))$('view').insertAdjacentHTML('afterbegin','<div class="notice">هذه طبقة الإصدار الأول محفوظة للمقارنة. الاستقراء الأحدث في «قراءة النص كله» و«الدراسات المقارنة» و«شبكة العلاقات الدلالية».</div>');
}
// Preserve the original source/context dialog and add the corresponding authored unit.
const originalShowEvidence=showEvidence;
showEvidence=function(ref,range=2){originalShowEvidence(ref,range);const id=FR.verseToUnit[ref];if(id){$('evidenceBody').insertAdjacentHTML('afterbegin',`<div class="row section">${readButton(id)}</div>`);bindFullCommon();}};
const firstEditionMethod=renderMethod;
renderMethod=function(){return firstEditionMethod().replace(/<h3>ما يبقى مفتوحًا<\/h3><ul class="method-list">[\s\S]*?<\/ul>/,`<h3>نطاق الإصدار الدلالي وحدوده</h3><ul class="method-list"><li>القراءة المكتوبة تغطي كل آيات المرفق في مقاطع متصلة؛ مراجعتها المستقلة محفوظة ببصمة المحتوى.</li><li>الدراسات المقارنة توسع صور البحث وتفصل اختلاف المعنى والقول والنفي والشرط؛ البوابات88 لا تحصر مفاهيم النص.</li><li>عائلات الاشتقاق فرضيات من الصور والقرائن؛ لا قاموس جذور خارجي ولا أصل تاريخي معتمد.</li><li>المراجعة تقبل دعاوى بحد شواهدها؛ لا تعني استنفاد كل احتمال دلالي أو اعتماد المستخدم.</li><li>شبكة الدلالة مستقلة عن التلازم؛ تجميع الاسم الحرفي فهرس لا إثبات هوية، والجوار ذو الصلتين لا يثبت سببية.</li><li>ترتيب المقاطع ترتيب نصي؛ لا تُستورد تواريخ للأحداث أو ترتيب نزول.</li></ul>`);};
window.QuranTwin.showEvidence=showEvidence;
window.QuranTwin.fullReading={FR,SN,SM,unitMap,studyMap,semanticEdges,goReading};
render();
