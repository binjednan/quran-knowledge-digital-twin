#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent source/position and set-intersection checks for name co-occurrence."""
from pathlib import Path
from collections import Counter
from itertools import combinations
import datetime, hashlib, json, re, unicodedata
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return ''.join(c for c in s if not unicodedata.category(c).startswith('M') and c!='ـ').replace('ٱ','ا')
def main():
    graph=json.loads((ROOT/'data/names/network.json').read_text())
    source=json.loads((ROOT/'quran-uthmani-numbered-ayahs.json').read_text())
    ayahs={f"{s['number']}:{a['number']}":a['text'] for s in source['surahs'] for a in s['ayahs']}
    assert len(ayahs)==6236
    checks=[]
    def check(name,ok):
        checks.append({'name':name,'passed':bool(ok)});assert ok,name
    check('exact_unmodified_source',sha(ROOT/'quran-uthmani-numbered-ayahs.json')==graph['metadata']['sourceSha256']=='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589')
    for p,h in graph['metadata']['inputSha256'].items():check('current_input_'+p,sha(ROOT/p)==h)
    expected_refs={}
    for n in graph['nodes']:
        patterns=[[k] for k in n.get('keys',[])]+n.get('patterns',[])
        # Independent whole-verse token-boundary search, rather than the builder's sliding window.
        regex=re.compile(r'(?<!\S)(?:'+'|'.join(' +'.join(re.escape(k) for k in p) for p in patterns)+r')(?!\S)')
        allowed=set(n['includeRefs']) if 'includeRefs' in n else set(ayahs)
        allowed-=set(n.get('excludeRefs',[]))
        refs={ref for ref,text in ayahs.items() if ref in allowed and regex.search(' '.join(filter(None,(norm(w) for w in text.split()))))}
        spans=set()
        for ref in refs:
            words=[(i+1,norm(w)) for i,w in enumerate(ayahs[ref].split()) if norm(w)]
            flat=' '.join(k for _,k in words)
            for pattern in patterns:
                exact=re.compile(r'(?<!\S)'+' +'.join(re.escape(k) for k in pattern)+r'(?!\S)')
                for match in exact.finditer(flat):
                    start=len(flat[:match.start()].split());end=start+len(pattern)-1
                    spans.add((ref,words[start][0],words[end][0]))
        expected_refs[n['id']]=refs
        check('all_source_matches_'+n['id'],refs==set(n['refs']) and len(refs)==n['ayahCount'])
        check('mention_count_'+n['id'],n['mentionCount']==len(n['occurrences'])==len(spans) and spans=={(o['ref'],o['start'],o['end']) for o in n['occurrences']})
        check('original_positions_'+n['id'],all(' '.join(ayahs[o['ref']].split()[o['start']-1:o['end']])==o['surface'] and o['ref'] in refs for o in n['occurrences']))
    actual={(e['source'],e['target']):e for e in graph['edges']}
    check('unique_edges_no_self_loops',len(actual)==len(graph['edges']) and all(a!=b for a,b in actual))
    check('all_edge_endpoints_exist',all(a in expected_refs and b in expected_refs for a,b in actual))
    expected_pairs={(a,b) for a,b in combinations(sorted(expected_refs),2) if expected_refs[a]&expected_refs[b]}
    check('exactly_all_and_only_intersecting_pairs',set(actual)==expected_pairs)
    pair_instances=0
    for a,b in combinations(sorted(expected_refs),2):
        refs=expected_refs[a]&expected_refs[b];e=actual.get((a,b))
        assert bool(refs)==bool(e),(a,b)
        if refs:
            assert refs==set(e['refs']) and len(e['refs'])==len(refs)==e['weight'],(a,b)
            pair_instances+=len(refs)
    check('all_registered_pairs_exact_source_intersections',True)
    check('aggregate_pair_count',pair_instances==graph['counts']['pairAyahInstances'])
    # Explicit witness: repeating the same label within one verse must not multiply the pair's weight.
    nodes={n['label']:n for n in graph['nodes']}
    check('distinct_name_labels_kept',all(x in nodes for x in ['عيسى','المسيح','محمد','أحمد','إسرائيل','يعقوب']))
    check('jesus_christ_literal_pair_3_45','3:45' in set(nodes['عيسى']['refs'])&set(nodes['المسيح']['refs']))
    check('no_historical_name_alias',nodes['إسرائيل']['id']!=nodes['يعقوب']['id'] and nodes['محمد']['id']!=nodes['أحمد']['id'])
    check('aad_verb_excluded','2:178' not in next(n['refs'] for n in graph['nodes'] if n['label']=='عاد'))
    degrees=Counter();strengths=Counter()
    for e in graph['edges']:
        for x in [e['source'],e['target']]:degrees[x]+=1;strengths[x]+=e['weight']
    check('all_centralities_recomputed',all(n['degree']==degrees[n['id']] and n['strength']==strengths[n['id']] for n in graph['nodes']))
    report={'status':'passed','verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'networkSha256':sha(ROOT/'data/names/network.json'),'inputSha256':{**graph['metadata']['inputSha256'],'data/names/network.json':sha(ROOT/'data/names/network.json')},'counts':graph['counts'],'checks':checks,'limits':'Mechanical verification of all registered labels and all pair counts; name classification is reviewed separately from source contexts. No external named-entity list or identity assumptions.'}
    (ROOT/'reports/names-network-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'passed','checks':len(checks),**graph['counts']}))
if __name__=='__main__':main()
