#!/usr/bin/env python3
"""Independent full checks of the generated corpus, index and lexical graph."""
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path
import sqlite3
import unicodedata
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def normalize(token):
    # Independent copy of the declared rule, rather than importing build outputs.
    return "".join(c for c in token if not unicodedata.category(c).startswith("M") and c != "ـ").replace("ٱ", "ا")


def load(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def main():
    checks = []
    def check(name, condition, detail=None):
        if not condition:
            raise AssertionError(name + (": " + str(detail) if detail else ""))
        checks.append({"check": name, "result": "passed", **({"detail": detail} if detail else {})})

    source = load("quran-uthmani-numbered-ayahs.json")
    corpus = load("data/corpus.json")
    lexicon = load("data/lexicon.json")
    overview = load("data/overview.json")
    manifest = load("data/manifest.json")
    source_hash = hashlib.sha256((ROOT / "quran-uthmani-numbered-ayahs.json").read_bytes()).hexdigest()
    check("source matches attachment checksum", source_hash == "25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589")
    check("source metadata and warnings preserved", corpus["metadata"]["sourceMetadata"] == source["metadata"] and corpus["metadata"]["derivation"] == source["derivation"])
    check("surah count and order preserved", [s["number"] for s in corpus["surahs"]] == [s["number"] for s in source["surahs"]])
    refs, raw_units, nonlexical = {}, [], []
    expected_occurrences = collections.defaultdict(list)
    expected_forms = collections.defaultdict(collections.Counter)
    expected_documents = collections.defaultdict(set)
    pairs = collections.defaultdict(list)
    for original, saved in zip(source["surahs"], corpus["surahs"]):
        assert original["name"] == saved["name"]
        assert [{"number": a["number"], "text": a["text"]} for a in original["ayahs"]] == saved["ayahs"]
        for a in saved["ayahs"]:
            ref = f'{saved["number"]}:{a["number"]}'
            refs[ref] = a["text"]
            unique_terms = set()
            for pos, surface in enumerate(a["text"].split(), 1):
                token = normalize(surface)
                is_lexical = any(unicodedata.category(c).startswith("L") for c in token)
                raw_units.append((ref, pos, surface, token, int(is_lexical)))
                if is_lexical:
                    expected_occurrences[token].append([saved["number"], a["number"], pos])
                    expected_forms[token][surface] += 1
                    expected_documents[token].add(ref)
                    unique_terms.add(token)
                else:
                    nonlexical.append({"ref": ref, "position": pos, "surface": surface, "normalized": token})
            for pair in itertools.combinations(sorted(unique_terms), 2):
                pairs[pair].append(ref)
    check("all 6236 numbered ayah texts exactly preserved", len(refs) == 6236)
    check("all exact lookup keys preserved", set(expected_occurrences) == {t["id"] for t in lexicon["terms"]})
    expected_degrees = collections.Counter()
    expected_strengths = collections.Counter()
    for (x, y), evidence in pairs.items():
        expected_degrees.update((x, y))
        expected_strengths[x] += len(evidence)
        expected_strengths[y] += len(evidence)
    for term in lexicon["terms"]:
        key = term["id"]
        assert term["occurrences"] == expected_occurrences[key], key
        assert term["count"] == len(expected_occurrences[key]), key
        assert term["df"] == len(expected_documents[key]), key
        assert term["surahs"] == len({row[0] for row in expected_occurrences[key]}), key
        assert {f["text"]: f["count"] for f in term["forms"]} == expected_forms[key], key
        assert term["surfaceFormCount"] == len(expected_forms[key]), key
        assert term["degree"] == expected_degrees[key], key
        assert term["strength"] == expected_strengths[key], key
    check("every occurrence, surface, frequency and complete-graph degree/strength verified", True, len(lexicon["terms"]))
    check("all standalone marks preserved", load("data/nonlexical-units.json")["units"] == nonlexical)
    collisions = load("data/normalization-collisions.json")
    check("normalization collisions fully recorded", {r["key"] for r in collisions["keys"]} == {t for t,f in expected_forms.items() if len(f)>1} and collisions["keyCount"] == sum(len(f)>1 for f in expected_forms.values()))
    check("PageRank probability mass and convergence", abs(sum(t["pagerank"] for t in lexicon["terms"]) - 1) < 1e-9 and lexicon["summary"]["pagerank"]["converged"])
    check("full graph statistics verified", overview["stats"]["distinctPairs"] == len(pairs) and overview["stats"]["pairAyahOccurrences"] == sum(map(len,pairs.values())) and overview["stats"]["whitespaceUnits"] == len(raw_units))
    for edge in overview["network"]["edges"]:
        pair = tuple(sorted([edge["source"], edge["target"]]))
        assert edge["evidence"] == pairs[pair]
        assert edge["weight"] == len(pairs[pair])
    check("every display edge and its full evidence verified", True, len(overview["network"]["edges"]))
    check("display layout coordinates valid", all(0 <= n[axis] <= 1 for n in overview["network"]["nodes"] for axis in ("x", "y")))
    similarities = overview["surahSimilarity"]
    matrix = overview["surahSimilarityMatrix"]
    check("all 6441 surah pairs represented exactly once", len(similarities) == 6441 and len({(s["source"],s["target"]) for s in similarities}) == 6441)
    check("similarity matrix symmetry, range and pair correspondence", all(0<=matrix[i][j]<=1 and matrix[i][j]==matrix[j][i] and (i != j or matrix[i][j] == 1) for i in range(114) for j in range(114)) and all(matrix[s["source"]-1][s["target"]-1] == s["value"] for s in similarities))
    excluded = set(overview["analysis"]["display"]["exclusions"])
    vectors = {}
    source_surah_terms = collections.defaultdict(collections.Counter)
    for term, occurrence_rows in expected_occurrences.items():
        if term not in excluded:
            for sn,an,pos in occurrence_rows:
                source_surah_terms[sn][term] += 1
    surah_df = collections.Counter(t for counter in source_surah_terms.values() for t in counter)
    for sn in range(1,115):
        vector = {t: (1+math.log(c))*(1+math.log(115/(1+surah_df[t]))) for t,c in source_surah_terms[sn].items()}
        length = math.sqrt(sum(v*v for v in vector.values()))
        vectors[sn] = {t:v/length for t,v in vector.items()} if length else {}
    for sn1,sn2 in itertools.combinations(range(1,115),2):
        shared = set(vectors[sn1]) & set(vectors[sn2])
        score = sum(vectors[sn1][t]*vectors[sn2][t] for t in shared)
        assert abs(score-matrix[sn1-1][sn2-1]) < 5.1e-9
    check("all 6441 TF-IDF cosine similarities independently recomputed", True)
    db = sqlite3.connect(ROOT / "exports/quran-lexical-network.sqlite")
    check("SQLite integrity", db.execute("PRAGMA integrity_check").fetchone()[0] == "ok")
    check("SQLite complete unit preservation", list(db.execute("SELECT a.ref,u.position,u.surface,u.normalized,u.is_lexical FROM units u JOIN ayahs a ON a.id=u.ayah_id ORDER BY a.id,u.position")) == raw_units)
    db_pairs = db.execute("SELECT x.normalized,y.normalized,e.weight FROM edges e JOIN terms x ON e.source=x.id JOIN terms y ON e.target=y.id ORDER BY x.normalized,y.normalized").fetchall()
    check("SQLite contains every pair and exact weight", db_pairs == [(x,y,len(pairs[x,y])) for x,y in sorted(pairs)])
    evidence = collections.defaultdict(list)
    for x,y,ref in db.execute("SELECT x.normalized,y.normalized,a.ref FROM edge_evidence ev JOIN edges e ON e.id=ev.edge_id JOIN terms x ON x.id=e.source JOIN terms y ON y.id=e.target JOIN ayahs a ON a.id=ev.ayah_id ORDER BY ev.edge_id,a.id"):
        evidence[x,y].append(ref)
    check("SQLite every pair/ayah evidence verified", evidence == pairs)
    db.close()
    nodes, edges = 0, 0
    terms_sorted = sorted(expected_occurrences)
    for event, elem in ET.iterparse(ROOT / "exports/quran-lexical-network.graphml", events=("end",)):
        if elem.tag.endswith("}node"):
            nodes += 1
            elem.clear()
        elif elem.tag.endswith("}edge"):
            x = terms_sorted[int(elem.attrib["source"][1:])]
            y = terms_sorted[int(elem.attrib["target"][1:])]
            values = {child.attrib["key"]: child.text for child in elem}
            assert int(values["weight"]) == len(pairs[x,y])
            assert values["evidence"] == ",".join(pairs[x,y])
            edges += 1
            elem.clear()
    check("GraphML is valid XML with every edge weight and evidence verified", nodes == len(expected_occurrences) and edges == len(pairs))
    for f in manifest["files"]:
        p = ROOT / f["path"]
        assert p.stat().st_size == f["bytes"] and hashlib.sha256(p.read_bytes()).hexdigest() == f["sha256"], f["path"]
    check("every manifest derivative hash verified", True, len(manifest["files"]))
    check("embedded opening caveats retained literally", refs["95:1"] == source["surahs"][94]["ayahs"][0]["text"] and refs["97:1"] == source["surahs"][96]["ayahs"][0]["text"])
    report = {"scope_ar": "فحص كامل لبقاء نص المصدر وبناء الفهرس والتلازم والتصدير. ليس فحصاً لمطابقة مصحف خارجي أو لقبول المعاني أو للواجهة.", "sourceSha256": source_hash, "result": "passed", "checks": checks, "statistics": overview["stats"]}
    (ROOT / "data/verification.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"result":"passed","checks":len(checks),"statistics":overview["stats"]},ensure_ascii=False))


if __name__ == "__main__":
    main()
