#!/usr/bin/env python3
"""Bundle the local corpus, evidence dossiers and offline UI without dependencies."""
from pathlib import Path
import json, hashlib, datetime

ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text())
def main():
    source=ROOT/'quran-uthmani-numbered-ayahs.json'
    raw=load(source.name)
    analysis={'domains':[]}
    for path in ['analysis/domains-a.json','analysis/domains-b.json']:
        analysis['domains'].extend(load(path)['domains'])
    payload={
        'corpus':load('data/corpus.json'), 'lexicon':load('data/lexicon.json'),
        'overview':load('data/overview.json'), 'analysis':analysis,
        'manifest':load('data/manifest.json'),
        'sourceMetadata':raw['metadata'], 'sourceDerivation':raw['derivation'],
        'build':{'builtAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                 'semanticStatus':'استقراء أولي؛ ليس إعادة بناء مكتملة للمعنى',
                 'networkPolicy':'لا اتصال ولا مصادر خارجية'}
    }
    # Avoid HTML script termination or JS line-separator surprises in user text.
    text=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    html=(ROOT/'ui/template.html').read_text().replace('/*__STYLE__*/',(ROOT/'ui/style.css').read_text()).replace('/*__DATA__*/',text).replace('/*__APP__*/',(ROOT/'ui/app.js').read_text())
    target=ROOT/'التوأم-المعرفي-للقرآن.html'
    target.write_text(html)
    (ROOT/'analysis/combined.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2))
    print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'domains':len(analysis['domains']),'concepts':sum(len(d['concepts']) for d in analysis['domains']),'claims':sum(len(d['claims']) for d in analysis['domains'])},ensure_ascii=False))
if __name__=='__main__': main()
