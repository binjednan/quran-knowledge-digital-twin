#!/usr/bin/env python3
"""Assemble source-scoped system syntheses and transparent annotation counts."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,datetime,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
def canonical(x):
    return hashlib.sha256(json.dumps({k:v for k,v in x.items() if k not in ['reviewStatus','independentReview']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--draft',action='store_true');args=p.parse_args()
    read=json.loads((ROOT/'data/full-reading/reading.json').read_text())
    net=json.loads((ROOT/'data/full-reading/network.json').read_text())
    domains=json.loads((ROOT/'analysis/combined.json').read_text())['domains']
    source=json.loads((ROOT/'quran-uthmani-numbered-ayahs.json').read_text())
    ayahs={f"{s['number']}:{a['number']}" for s in source['surahs'] for a in s['ayahs']}
    assert read['metadata']==net['metadata'],'Reading/network snapshots differ'
    if not args.draft:assert not read['metadata']['draft'] and not net['metadata']['draft'],'Reviewed reading required'
    for dataset in [read,net]:
        for name,digest in dataset['metadata']['inputSha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'Stale input: '+name
    assert hashlib.sha256((ROOT/'quran-uthmani-numbered-ayahs.json').read_bytes()).hexdigest()==read['metadata']['sourceSha256'],'Dataset source differs'
    dependencies=['data/full-reading/reading.json','data/full-reading/network.json','analysis/combined.json','quran-uthmani-numbered-ayahs.json','scripts/build_system_model.py']
    systems=[];input_hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in dependencies};errors=[]
    def allrefs(x):
        if isinstance(x,dict):
            for k,v in x.items():
                if k=='evidence' and isinstance(v,list):yield from v
                else:yield from allrefs(v)
        elif isinstance(x,list):
            for v in x:yield from allrefs(v)
    for d in domains:
        path=ROOT/f"analysis/full-reading/systems/{d['id']}.json"
        if not path.exists():
            if not args.draft:errors.append('Missing system '+d['id'])
            continue
        s=json.loads(path.read_text());input_hashes[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        if s['id']!=d['id']:errors.append('Wrong system id '+d['id'])
        if not set(allrefs(s))<=ayahs:errors.append('Invalid reference '+d['id'])
        if not args.draft and (s.get('reviewStatus')!='independently_reviewed_as_scoped' or s.get('independentReview',{}).get('contentSha256')!=canonical(s)):errors.append('Review missing/stale '+d['id'])
        systems.append(s)
    lids={d['id'] for d in domains};unit_map={u['id']:u for u in read['units']}
    indices={d['id']:[] for d in domains};matrix={a:{b:0 for b in lids} for a in lids}
    for u in read['units']:
        lenses={l['id'] for l in u['lenses']}
        for a in lenses:
            indices[a].append(u['id'])
            for b in lenses:matrix[a][b]+=1
    # The universal relations lens uses every record, with that rule explicit.
    indices['relations']=list(unit_map)
    edge_lenses={e['id']:sorted({l['id'] for l in unit_map[e['unit']]['lenses']}|{'relations'}) for e in net['edges']}
    metrics={}
    for d in domains:
        uid=set(indices[d['id']]);es=[e for e in net['edges'] if e['unit'] in uid]
        nodes=Counter(n for e in es for n in [e['source'],e['target']])
        metrics[d['id']]={'units':len(uid),'ayahs':len({f"{u['surah']}:{a}" for u in read['units'] if u['id'] in uid for a in range(u['start'],u['end']+1)}),'relations':len(es),'literalLabels':len(nodes),'polarity':dict(Counter(e['polarity'] for e in es)),'topLabels':[{'id':n,'incidentRecords':c} for n,c in nodes.most_common(20)]}
    bridges=[]
    for s in systems:
        for i,r in enumerate(s.get('crossSystemRelations',[])):
            if r.get('sourceSystem') not in lids or r.get('targetSystem') not in lids:errors.append('Invalid bridge in '+s['id']);continue
            bridges.append({'id':s['id']+'::bridge'+str(i),'authoredInSystem':s['id'],**r})
    if errors:raise SystemExit('\n'.join(errors))
    result={'metadata':{'builtAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'draft':args.draft,'sourceSha256':read['metadata']['sourceSha256'],'inputSha256':input_hashes,
      'policy':'Sixteen user-defined lenses, not discovered ontological partitions. Matrix counts shared authored unit annotations, not causal influence or importance. Universal relations lens uses all units; it is not substituted into the co-annotation matrix.'},
      'systems':systems,'systemTitles':{d['id']:d['title'] for d in domains},'unitIndex':indices,'unitCoannotationMatrix':matrix,'metrics':metrics,'edgeLenses':edge_lenses,'bridges':bridges}
    (ROOT/'data/full-reading/systems.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':')))
    print(json.dumps({'systems':len(systems),'bridges':len(bridges),'draft':args.draft},ensure_ascii=False))
if __name__=='__main__':main()
