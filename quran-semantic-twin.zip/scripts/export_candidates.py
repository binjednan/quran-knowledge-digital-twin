#!/usr/bin/env python3
"""Portable candidate interpretation graph. Does not infer or assert meanings."""
from __future__ import annotations
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"quran-uthmani-numbered-ayahs.json"
ANALYSIS=[ROOT/"analysis/domains-a.json",ROOT/"analysis/domains-b.json"]
SOURCE_SHA="25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589"
EXPECTED_ANALYSIS={"analysis/domains-a.json":"7a820ab614eee131585d6d9341fb44b8368bd5d61c4ec383d8a9df284e80502d","analysis/domains-b.json":"fad9db252c64d42e630bb654e6ce591f50e20aed4fe251d8c79d9fc7ad824b53"}
NS="http://graphml.graphdrawing.org/xmlns"
ET.register_namespace("",NS)


def encoded(value):
    return json.dumps(value,ensure_ascii=False,separators=(",",":"))


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    inputs=[SOURCE,*ANALYSIS,ROOT/"data/lexicon.json"]
    before={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    assert before[SOURCE.name]==SOURCE_SHA,"source attachment checksum mismatch"
    for path,expected in EXPECTED_ANALYSIS.items():
        assert before[path]==expected,"analysis snapshot differs; review and update the authorized fixed snapshot explicitly"
    source=read(SOURCE)
    analysis=[read(p) for p in ANALYSIS]
    domains=[d for doc in analysis for d in doc["domains"]]
    concepts=[(d,c) for d in domains for c in d["concepts"]]
    claims=[(d,c) for d in domains for c in d["claims"]]
    lexicon={t["id"]:t for t in read(ROOT/"data/lexicon.json")["terms"]}
    ayahs={f'{s["number"]}:{a["number"]}':(s["number"],a["number"],a["text"]) for s in source["surahs"] for a in s["ayahs"]}
    lookup_keys=sorted({f for _,c in concepts for f in c["forms"]})
    term_node={key:f"term:t{i:04d}" for i,key in enumerate(lookup_keys)}
    concept_ids={c["id"] for _,c in concepts}
    claim_ids={c["id"] for _,c in claims}
    warning="هذه طبقة استقراء مرشحة، وليست حقائق دلالية معتمدة. صحة المرجع أو مطابقة صيغة البحث لا تثبت استلزام الدعوى أو هوية المفهوم. عدسات المنظومات من طلب المستخدم. مرشحات البحث لا تعني denotes ولا ترادفاً. جميع المواضع الخام محفوظة بما فيها المستبعد دلالياً."
    metadata={
        "schema":1,"builtAt":dt.datetime.now(dt.timezone.utc).isoformat(),
        "sourceFile":SOURCE.name,"sourceSha256":SOURCE_SHA,
        "analysisSha256":{k:before[k] for k in EXPECTED_ANALYSIS},
        "sourceMetadata":source["metadata"],"sourceDerivation":source["derivation"],
        "copyrightNotice":source["derivation"]["copyrightNotice"],
        "licenseUrl":source["derivation"]["licenseUrl"],
        "warning_ar":warning,"assertedTruth":False,"externalSourcesConsulted":[],
        "candidateOccurrencesMeaning_ar":"اتحاد آيات جميع صور البحث المعلنة لكل مفهوم؛ raw_lexical_match فقط، وليس إثبات جميع استعمالات المفهوم أو انتماء كل مطابقة إليه.",
        "graphScope_ar":"يضم GraphML عقد الآيات المستشهد بها في التعريفات والاستعمالات والدعاوى وملاحظات الاستبعاد فقط؛ جميع6236 آية وكل مرشحات المواضع في SQLite. لا يستورد شبكة التلازم ولا يستنبط منها علاقات دلالية.",
        "identityPolicy_ar":"معرفات العدسات والمفاهيم والدعاوى الأصلية محفوظة في source_id. بادئات domain:/concept:/claim:/term:/ayah: تمنع تصادم أنواع العقد. مفتاح البحث المشترك عقدة ترشيح واحدة، وليس دمجاً لهوية المفاهيم.",
        "edgeTypes":{
            "lens_membership":"user-requested research lens membership; not a discovered semantic taxonomy",
            "search_form":"declared raw search candidate; does not assert denotes",
            "claim_involves":"authored claim references a candidate concept",
            "claim_evidence":"authored textual citation; reference existence does not establish entailment",
            "candidate_definition_evidence":"candidate central-meaning citation",
            "candidate_usage_evidence":"candidate usage citation",
            "raw_exclusion_note":"visible semantic exclusion note; original lexical match remains",
            "semantic_candidate_relation":"authored candidate relation with its claim identifier; asserted_truth=false",
        },
    }
    out=ROOT/"exports"
    out.mkdir(exist_ok=True)
    db_path=out/"quran-knowledge-candidates.sqlite"
    graph_path=out/"quran-knowledge-candidates.graphml"
    if db_path.exists():
        db_path.unlink()
    db=sqlite3.connect(db_path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
      CREATE TABLE metadata(key TEXT PRIMARY KEY,value_json TEXT NOT NULL);
      CREATE TABLE ayahs(ref TEXT PRIMARY KEY,surah INTEGER NOT NULL,number INTEGER NOT NULL,text TEXT NOT NULL,UNIQUE(surah,number));
      CREATE TABLE domains(id TEXT PRIMARY KEY,title TEXT NOT NULL,status TEXT,classification_source TEXT,record_json TEXT NOT NULL);
      CREATE TABLE concepts(id TEXT PRIMARY KEY,domain_id TEXT NOT NULL REFERENCES domains(id),label TEXT NOT NULL,central_statement TEXT NOT NULL,confidence TEXT,status TEXT,record_json TEXT NOT NULL);
      CREATE TABLE seed_terms(search_key TEXT PRIMARY KEY,count INTEGER NOT NULL,original_surfaces_json TEXT NOT NULL,identity_status TEXT NOT NULL CHECK(identity_status='raw_search_key_not_concept'));
      CREATE TABLE forms(concept_id TEXT NOT NULL REFERENCES concepts(id),position INTEGER NOT NULL,search_key TEXT NOT NULL REFERENCES seed_terms(search_key),relation_status TEXT NOT NULL CHECK(relation_status='candidate_not_denotes'),PRIMARY KEY(concept_id,search_key),UNIQUE(concept_id,position));
      CREATE TABLE candidate_occurrences(concept_id TEXT NOT NULL REFERENCES concepts(id),ref TEXT NOT NULL REFERENCES ayahs(ref),match_status TEXT NOT NULL CHECK(match_status='raw_lexical_match'),semantic_membership INTEGER CHECK(semantic_membership IS NULL),has_exclusion_note INTEGER NOT NULL,PRIMARY KEY(concept_id,ref));
      CREATE TABLE exclusions(concept_id TEXT NOT NULL,ref TEXT NOT NULL,reason TEXT NOT NULL,raw_match_preserved INTEGER NOT NULL CHECK(raw_match_preserved=1),record_json TEXT NOT NULL,PRIMARY KEY(concept_id,ref),FOREIGN KEY(concept_id,ref) REFERENCES candidate_occurrences(concept_id,ref));
      CREATE TABLE concept_evidence(concept_id TEXT NOT NULL REFERENCES concepts(id),evidence_kind TEXT NOT NULL,usage_index INTEGER NOT NULL,position INTEGER NOT NULL,ref TEXT NOT NULL REFERENCES ayahs(ref),PRIMARY KEY(concept_id,evidence_kind,usage_index,position));
      CREATE TABLE claims(id TEXT PRIMARY KEY,domain_id TEXT NOT NULL REFERENCES domains(id),type TEXT NOT NULL,statement TEXT NOT NULL,confidence TEXT NOT NULL,basis TEXT NOT NULL,limits TEXT NOT NULL,asserted_truth INTEGER NOT NULL CHECK(asserted_truth=0),record_json TEXT NOT NULL);
      CREATE TABLE claim_concepts(claim_id TEXT NOT NULL REFERENCES claims(id),concept_id TEXT NOT NULL REFERENCES concepts(id),PRIMARY KEY(claim_id,concept_id));
      CREATE TABLE claim_evidence(claim_id TEXT NOT NULL REFERENCES claims(id),position INTEGER NOT NULL,ref TEXT NOT NULL REFERENCES ayahs(ref),entailment_status TEXT NOT NULL CHECK(entailment_status='not_automatically_verified'),PRIMARY KEY(claim_id,position));
      CREATE TABLE relations(id TEXT PRIMARY KEY,source_concept_id TEXT NOT NULL REFERENCES concepts(id),target_concept_id TEXT NOT NULL REFERENCES concepts(id),label TEXT NOT NULL,confidence TEXT NOT NULL,claim_id TEXT NOT NULL REFERENCES claims(id),relation_status TEXT NOT NULL CHECK(relation_status='candidate_interpretation'),asserted_truth INTEGER NOT NULL CHECK(asserted_truth=0));
      CREATE INDEX occurrences_ref ON candidate_occurrences(ref);
      CREATE INDEX concept_evidence_ref ON concept_evidence(ref);
      CREATE INDEX claim_evidence_ref ON claim_evidence(ref);
    """)
    db.executemany("INSERT INTO metadata VALUES (?,?)",[(key,encoded(value)) for key,value in metadata.items()])
    db.executemany("INSERT INTO ayahs VALUES (?,?,?,?)",[(ref,*value) for ref,value in ayahs.items()])
    for d in domains:
        domain_record={k:v for k,v in d.items() if k not in ("concepts","claims")}
        db.execute("INSERT INTO domains VALUES (?,?,?,?,?)",(d["id"],d["title"],d.get("status"),encoded(d.get("classificationSource")),encoded(domain_record)))
    db.executemany("INSERT INTO seed_terms VALUES (?,?,?,?)",[(key,lexicon[key]["count"],encoded(lexicon[key]["forms"]),"raw_search_key_not_concept") for key in lookup_keys])
    for d,c in concepts:
        central=c["centralMeaning"]
        db.execute("INSERT INTO concepts VALUES (?,?,?,?,?,?,?)",(c["id"],d["id"],c["label"],central["statement"],central.get("confidence"),central.get("status"),encoded(c)))
        db.executemany("INSERT INTO forms VALUES (?,?,?,?)",[(c["id"],position,key,"candidate_not_denotes") for position,key in enumerate(c["forms"],1)])
        exclusions={e if isinstance(e,str) else e["ref"]:e for e in c.get("excludedOccurrences",[])}
        db.executemany("INSERT INTO candidate_occurrences VALUES (?,?,?,?,?)",[(c["id"],ref,"raw_lexical_match",None,int(ref in exclusions)) for ref in c["occurrences"]])
        db.executemany("INSERT INTO exclusions VALUES (?,?,?,?,?)",[(c["id"],ref,e.get("reason","") if isinstance(e,dict) else "reason not supplied",1,encoded(e)) for ref,e in exclusions.items()])
        db.executemany("INSERT INTO concept_evidence VALUES (?,?,?,?,?)",[(c["id"],"central_meaning",-1,position,ref) for position,ref in enumerate(central["evidence"],1)])
        for ui,usage in enumerate(c.get("usages",[])):
            db.executemany("INSERT INTO concept_evidence VALUES (?,?,?,?,?)",[(c["id"],"usage",ui,position,ref) for position,ref in enumerate(usage["evidence"],1)])
    for d,c in claims:
        db.execute("INSERT INTO claims VALUES (?,?,?,?,?,?,?,?,?)",(c["id"],d["id"],c["type"],c["statement"],c["confidence"],c["basis"],c["limits"],0,encoded(c)))
        db.executemany("INSERT INTO claim_concepts VALUES (?,?)",[(c["id"],cid) for cid in c.get("concepts",[])])
        db.executemany("INSERT INTO claim_evidence VALUES (?,?,?,?)",[(c["id"],position,ref,"not_automatically_verified") for position,ref in enumerate(c["evidence"],1)])
        if c.get("relation"):
            r=c["relation"]
            db.execute("INSERT INTO relations VALUES (?,?,?,?,?,?,?,?)",("relation:"+c["id"],r["source"],r["target"],r["label"],c["confidence"],c["id"],"candidate_interpretation",0))
    db.commit()

    # Typed, directed transport graph; direction is authored structure, not causality.
    graph_root=ET.Element(f"{{{NS}}}graphml")
    graph_keys=["metadata_json","warning_ar","scope_ar"]
    node_keys=["kind","source_id","label","record_json","confidence","status","text","search_key"]
    edge_keys=["edge_type","label","claim_id","confidence","status","asserted_truth","position","usage_index","reason"]
    for name in graph_keys:
        ET.SubElement(graph_root,f"{{{NS}}}key",id="g_"+name,attrib={"for":"graph","attr.name":name,"attr.type":"string"})
    for name in node_keys:
        ET.SubElement(graph_root,f"{{{NS}}}key",id="n_"+name,attrib={"for":"node","attr.name":name,"attr.type":"string"})
    for name in edge_keys:
        ET.SubElement(graph_root,f"{{{NS}}}key",id="e_"+name,attrib={"for":"edge","attr.name":name,"attr.type":"string"})
    graph=ET.SubElement(graph_root,f"{{{NS}}}graph",id="quran-candidate-interpretations",edgedefault="directed")

    def data(element,prefix,values):
        for key,value in values.items():
            if value is not None:
                ET.SubElement(element,f"{{{NS}}}data",key=prefix+key).text=str(value)

    data(graph,"g_",{"metadata_json":encoded(metadata),"warning_ar":warning,"scope_ar":metadata["graphScope_ar"]})
    node_expected={}
    edge_expected=[]

    def node(nid,kind,source_id,label,**values):
        assert nid not in node_expected,"duplicate graph identifier"
        values={"kind":kind,"source_id":source_id,"label":label,**values}
        element=ET.SubElement(graph,f"{{{NS}}}node",id=nid)
        data(element,"n_",values)
        node_expected[nid]={key:str(value) for key,value in values.items() if value is not None}

    def edge(source,target,typ,**values):
        values={"edge_type":typ,"asserted_truth":"false",**values}
        eid="edge:"+str(len(edge_expected))
        element=ET.SubElement(graph,f"{{{NS}}}edge",id=eid,source=source,target=target)
        data(element,"e_",values)
        edge_expected.append((eid,source,target,{key:str(value) for key,value in values.items() if value is not None}))

    for d in domains:
        node("domain:"+d["id"],"user_research_lens",d["id"],d["title"],status="requested_lens_not_discovered_taxonomy",record_json=encoded({k:v for k,v in d.items() if k not in ("concepts","claims")}))
    for d,c in concepts:
        node("concept:"+c["id"],"candidate_concept",c["id"],c["label"],status="candidate_not_asserted",confidence=c["centralMeaning"].get("confidence"),record_json=encoded(c))
        edge("domain:"+d["id"],"concept:"+c["id"],"lens_membership",status="user_requested_lens")
    for d,c in claims:
        node("claim:"+c["id"],"authored_candidate_claim",c["id"],c["statement"],status="candidate_not_asserted",confidence=c["confidence"],record_json=encoded(c))
        edge("domain:"+d["id"],"claim:"+c["id"],"lens_membership",status="user_requested_lens")
    for key in lookup_keys:
        node(term_node[key],"raw_search_key",key,key,search_key=key,status="not_a_semantic_identity",record_json=encoded({"key":key,"count":lexicon[key]["count"],"originalSurfaces":lexicon[key]["forms"]}))
    cited_refs={ref for _,c in concepts for ref in c["centralMeaning"]["evidence"]}
    cited_refs.update(ref for _,c in concepts for usage in c.get("usages",[]) for ref in usage["evidence"])
    cited_refs.update(ref for _,c in claims for ref in c["evidence"])
    cited_refs.update(e if isinstance(e,str) else e["ref"] for _,c in concepts for e in c.get("excludedOccurrences",[]))
    for ref in sorted(cited_refs,key=lambda ref:tuple(map(int,ref.split(":")))):
        node("ayah:"+ref,"raw_ayah_evidence",ref,ref,text=ayahs[ref][2],status="verbatim_supplied_text")
    for d,c in concepts:
        cid="concept:"+c["id"]
        for position,key in enumerate(c["forms"],1):
            edge(cid,term_node[key],"search_form",position=position,status="candidate_not_denotes")
        for position,ref in enumerate(c["centralMeaning"]["evidence"],1):
            edge(cid,"ayah:"+ref,"candidate_definition_evidence",position=position,status="entailment_not_automatically_verified")
        for ui,usage in enumerate(c.get("usages",[])):
            for position,ref in enumerate(usage["evidence"],1):
                edge(cid,"ayah:"+ref,"candidate_usage_evidence",position=position,usage_index=ui,label=usage["label"],status="entailment_not_automatically_verified")
        for ex in c.get("excludedOccurrences",[]):
            ref=ex if isinstance(ex,str) else ex["ref"]
            edge(cid,"ayah:"+ref,"raw_exclusion_note",reason=ex.get("reason","") if isinstance(ex,dict) else "reason not supplied",status="raw_match_retained_in_candidate_occurrences")
    for d,c in claims:
        clid="claim:"+c["id"]
        for cid in c.get("concepts",[]):
            edge(clid,"concept:"+cid,"claim_involves",claim_id=c["id"],status="authored_reference")
        for position,ref in enumerate(c["evidence"],1):
            edge(clid,"ayah:"+ref,"claim_evidence",position=position,claim_id=c["id"],status="entailment_not_automatically_verified")
        if c.get("relation"):
            r=c["relation"]
            edge("concept:"+r["source"],"concept:"+r["target"],"semantic_candidate_relation",claim_id=c["id"],confidence=c["confidence"],label=r["label"],status="candidate_interpretation")
    ET.ElementTree(graph_root).write(graph_path,encoding="utf-8",xml_declaration=True)

    checks=[]
    def check(name,condition,detail=None):
        if not condition:
            raise AssertionError(name+": "+str(detail))
        checks.append({"check":name,"result":"passed",**({"detail":detail} if detail is not None else {})})
    check("SQLite integrity",db.execute("PRAGMA integrity_check").fetchone()[0]=="ok")
    check("all foreign keys resolve",not db.execute("PRAGMA foreign_key_check").fetchall())
    check("all 6236 original ayah strings preserved",dict((r,(s,a,t)) for r,s,a,t in db.execute("SELECT ref,surah,number,text FROM ayahs"))==ayahs and len(ayahs)==6236)
    expected_counts={"metadata":len(metadata),"ayahs":len(ayahs),"domains":len(domains),"concepts":len(concepts),"seed_terms":len(lookup_keys),"forms":sum(len(c["forms"]) for _,c in concepts),"candidate_occurrences":sum(len(c["occurrences"]) for _,c in concepts),"exclusions":sum(len(c.get("excludedOccurrences",[])) for _,c in concepts),"concept_evidence":sum(len(c["centralMeaning"]["evidence"])+sum(len(u["evidence"]) for u in c.get("usages",[])) for _,c in concepts),"claims":len(claims),"claim_concepts":sum(len(c.get("concepts",[])) for _,c in claims),"claim_evidence":sum(len(c["evidence"]) for _,c in claims),"relations":sum(bool(c.get("relation")) for _,c in claims)}
    actual_counts={name:db.execute("SELECT COUNT(*) FROM "+name).fetchone()[0] for name in expected_counts}
    check("all requested table counts match fixed analysis snapshots",actual_counts==expected_counts,actual_counts)
    check("all thirteen export tables present",len(db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall())==13)
    check("declared analysis cardinalities preserved",actual_counts["domains"]==16 and actual_counts["concepts"]==88 and actual_counts["claims"]==64 and actual_counts["relations"]==57)
    for d,c in concepts:
        expected_raw={f"{s}:{a}" for key in c["forms"] for s,a,_ in lexicon[key]["occurrences"]}
        actual_raw={row[0] for row in db.execute("SELECT ref FROM candidate_occurrences WHERE concept_id=?",(c["id"],))}
        check("complete raw candidate occurrence union retained",expected_raw==actual_raw,c["id"])
        stored=read_record=db.execute("SELECT record_json FROM concepts WHERE id=?",(c["id"],)).fetchone()[0]
        check("complete candidate record preserved without interpretation changes",json.loads(stored)==c,c["id"])
    check("all exclusion notes remain in raw occurrences",db.execute("SELECT COUNT(*) FROM exclusions e JOIN candidate_occurrences o ON o.concept_id=e.concept_id AND o.ref=e.ref WHERE o.has_exclusion_note=1 AND e.raw_match_preserved=1").fetchone()[0]==expected_counts["exclusions"])
    check("raw candidate matches have no asserted semantic membership",db.execute("SELECT COUNT(*) FROM candidate_occurrences WHERE match_status<>'raw_lexical_match' OR semantic_membership IS NOT NULL").fetchone()[0]==0)
    for d,c in claims:
        stored=db.execute("SELECT record_json FROM claims WHERE id=?",(c["id"],)).fetchone()[0]
        check("full authored claim and all textual evidence preserved",json.loads(stored)==c and [r[0] for r in db.execute("SELECT ref FROM claim_evidence WHERE claim_id=? ORDER BY position",(c["id"],))]==c["evidence"],c["id"])
    check("semantic relations never asserted as verified truth",db.execute("SELECT COUNT(*) FROM relations WHERE asserted_truth<>0 OR relation_status<>'candidate_interpretation'").fetchone()[0]==0)
    check("all claims explicitly marked unasserted",db.execute("SELECT COUNT(*) FROM claims WHERE asserted_truth<>0").fetchone()[0]==0)
    expected_relations=sorted(("relation:"+c["id"],c["relation"]["source"],c["relation"]["target"],c["relation"]["label"],c["confidence"],c["id"],"candidate_interpretation",0) for _,c in claims if c.get("relation"))
    check("every relation preserves its exact authored endpoints, label, confidence and claim",db.execute("SELECT * FROM relations ORDER BY id").fetchall()==expected_relations)
    check("every declared search form preserved in order without denotes assertions",db.execute("SELECT * FROM forms ORDER BY concept_id,position").fetchall()==sorted((c["id"],position,key,"candidate_not_denotes") for _,c in concepts for position,key in enumerate(c["forms"],1)))
    check("all claim-to-concept references preserved",db.execute("SELECT * FROM claim_concepts ORDER BY claim_id,concept_id").fetchall()==sorted((c["id"],cid) for _,c in claims for cid in c.get("concepts",[])))
    check("all central-meaning and usage evidence references preserved in order",db.execute("SELECT * FROM concept_evidence ORDER BY concept_id,evidence_kind,usage_index,position").fetchall()==sorted([(c["id"],"central_meaning",-1,position,ref) for _,c in concepts for position,ref in enumerate(c["centralMeaning"]["evidence"],1)]+[(c["id"],"usage",ui,position,ref) for _,c in concepts for ui,u in enumerate(c.get("usages",[])) for position,ref in enumerate(u["evidence"],1)]))
    parsed=ET.parse(graph_path)
    parsed_nodes={}
    parsed_edges=[]
    for element in parsed.findall(f".//{{{NS}}}node"):
        parsed_nodes[element.attrib["id"]]={child.attrib["key"][2:]:child.text or "" for child in element}
    for element in parsed.findall(f".//{{{NS}}}edge"):
        parsed_edges.append((element.attrib["id"],element.attrib["source"],element.attrib["target"],{child.attrib["key"][2:]:child.text or "" for child in element}))
    check("GraphML every typed node and its data round-trip exactly",parsed_nodes==node_expected,len(parsed_nodes))
    check("GraphML every typed edge and its data round-trip exactly",parsed_edges==edge_expected,len(parsed_edges))
    check("every GraphML endpoint resolves without identifier merging",all(source in parsed_nodes and target in parsed_nodes for _,source,target,_ in parsed_edges))
    check("GraphML ayah evidence strings match original source",all(parsed_nodes["ayah:"+ref]["text"]==ayahs[ref][2] for ref in cited_refs),len(cited_refs))
    check("GraphML references preserve every original domain/concept/claim identifier",all(parsed_nodes["domain:"+d["id"]]["source_id"]==d["id"] for d in domains) and all(parsed_nodes["concept:"+c["id"]]["source_id"]==c["id"] for _,c in concepts) and all(parsed_nodes["claim:"+c["id"]]["source_id"]==c["id"] for _,c in claims))
    check("every semantic graph relation preserves an existing claim identifier",all(v.get("claim_id") in claim_ids for _,_,_,v in parsed_edges if v["edge_type"]=="semantic_candidate_relation"))
    check("no imported cooccurrence edges",all(v["edge_type"] in metadata["edgeTypes"] for _,_,_,v in parsed_edges))
    check("source and both analysis inputs unchanged",all(sha(p)==before[str(p.relative_to(ROOT))] for p in inputs),before)
    db.close()
    type_counts=dict(collections.Counter(n["kind"] for n in parsed_nodes.values()))
    edge_type_counts=dict(collections.Counter(v["edge_type"] for _,_,_,v in parsed_edges))
    report={"result":"passed","checkedAt":dt.datetime.now(dt.timezone.utc).isoformat(),"warning_ar":warning,"scope_ar":"تحقق حفظ وبنية ونقل ومراجع ونصوص وحصر مرشحات خام. لا يراجع الاستلزام الدلالي أو صحة التعريفات أو اعتمادها.","inputSha256":before,"tableCount":13,"tableCounts":actual_counts,"graph":{"nodes":len(parsed_nodes),"edges":len(parsed_edges),"nodeTypes":type_counts,"edgeTypes":edge_type_counts,"ayahScope":"cited evidence and visible exclusions only; all 6236 raw ayahs are in SQLite"},"checks":checks,"files":[{"path":str(p.relative_to(ROOT)),"bytes":p.stat().st_size,"sha256":sha(p)} for p in (db_path,graph_path)]}
    (ROOT/"reports").mkdir(exist_ok=True)
    (ROOT/"reports/candidate-export-verification.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(encoded({"result":"passed","checks":len(checks),"tableCounts":actual_counts,"graph":report["graph"],"files":report["files"]}))


if __name__=="__main__":
    main()
