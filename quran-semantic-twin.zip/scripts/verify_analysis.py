#!/usr/bin/env python3
"""Check evidence references/index coverage; deliberately does not judge meanings."""
from __future__ import annotations
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
INPUTS = [ROOT / "analysis/domains-a.json", ROOT / "analysis/domains-b.json"]
REF_RE = re.compile(r"^[0-9]+:[0-9]+$")
SHA = "25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589"


def normalize(value):
    return "".join(c for c in value if not unicodedata.category(c).startswith("M") and c != "ـ").replace("ٱ", "ا")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    checks, errors, warnings = [], [], []
    counts = collections.Counter()

    def check(name, condition, path="", detail=None):
        row = {"check": name, "result": "passed" if condition else "failed"}
        if path:
            row["path"] = path
        if detail is not None:
            row["detail"] = detail
        checks.append(row)
        if not condition:
            errors.append(row)

    source_path = ROOT / "quran-uthmani-numbered-ayahs.json"
    source = read(source_path)
    lexicon = read(ROOT / "data/lexicon.json")
    terms = {t["id"]: t for t in lexicon["terms"]}
    refs = {f'{s["number"]}:{a["number"]}' for s in source["surahs"] for a in s["ayahs"]}
    source_units = {f'{s["number"]}:{a["number"]}':[normalize(t) for t in a["text"].split()] for s in source["surahs"] for a in s["ayahs"]}
    check("source checksum matches supplied attachment", sha(source_path) == SHA)
    # Recheck the normalization at every indexed original surface, independent of UI.
    check("every lexicon original surface obeys the declared normalization", all(normalize(f["text"]) == t["id"] for t in terms.values() for f in t["forms"]))
    ui_path=ROOT / "ui/app.js"
    if ui_path.exists():
        ui_source=ui_path.read_text(encoding="utf-8")
        norm_match=re.search(r"const norm=s=>([^;]+);",ui_source)
        expected_js=r"s.replace(/\p{M}/gu,'').replace(/ـ/g,'').replace(/ٱ/g,'ا')"
        check("UI normalization expression statically matches the declared operations",bool(norm_match) and norm_match.group(1)==expected_js,"ui/app.js:norm")
    missing = [str(p.relative_to(ROOT)) for p in INPUTS if not p.exists()]
    if missing:
        print(json.dumps({"result": "inputs_missing", "files": missing}, ensure_ascii=False))
        return 2
    snapshots = {str(p.relative_to(ROOT)): sha(p) for p in INPUTS}
    documents = []
    for path in INPUTS:
        try:
            data = read(path)
        except (ValueError, OSError) as exc:
            print(json.dumps({"result": "input_not_complete", "file": str(path), "error": str(exc)}, ensure_ascii=False))
            return 2
        domains = data.get("domains") if isinstance(data, dict) else data
        check("file contains a domains list", isinstance(domains, list), str(path.relative_to(ROOT)))
        if not isinstance(domains, list):
            domains = []
        documents.append((path, data, domains))
    domains = [d for _,_,ds in documents for d in ds]
    concepts = [c for d in domains for c in d.get("concepts", [])]
    claims = [c for d in domains for c in d.get("claims", [])]
    domain_ids = [d.get("id") for d in domains]
    concept_ids = [c.get("id") for c in concepts]
    claim_ids = [c.get("id") for c in claims]
    check("16 requested research lenses represented", len(domains) == 16, detail=len(domains))
    for label, identifiers in [("domain",domain_ids),("concept",concept_ids),("claim",claim_ids)]:
        check(label + " identifiers are nonempty strings and globally unique within type", all(isinstance(i,str) and i for i in identifiers) and len(set(identifiers)) == len(identifiers), detail=len(identifiers))
    all_ids = domain_ids + concept_ids + claim_ids
    check("identifiers do not collide across domain/concept/claim types", len(all_ids) == len(set(all_ids)))
    concept_map = {c.get("id"): c for c in concepts}

    def evidence(value, path, required=True):
        check("evidence is a reference list", isinstance(value,list), path)
        if not isinstance(value,list):
            return
        check("evidence is nonempty" if required else "reference list may be empty", bool(value) if required else True, path)
        check("every evidence reference exists in the source", all(isinstance(r,str) and r in refs for r in value), path, [r for r in value if not isinstance(r,str) or r not in refs])
        check("evidence does not duplicate a reference", len(value)==len(set(r for r in value if isinstance(r,str))), path)
        counts["evidenceReferences"] += len(value)

    def walk_refs(value, path):
        # Catch valid-looking references in other fields, not only standard evidence.
        if isinstance(value, dict):
            for key, child in value.items():
                walk_refs(child, path+"."+key)
        elif isinstance(value,list):
            for i, child in enumerate(value):
                walk_refs(child,path+f"[{i}]")
        elif isinstance(value,str) and REF_RE.match(value):
            check("all standalone verse references resolve", value in refs, path, value if value not in refs else None)

    def numeric_field(audit, name, expected, path):
        if name in audit:
            check("declared "+name+" equals the full lexical selection", audit[name] == expected, path+"."+name, {"declared":audit[name],"expected":expected})

    for path, data, file_domains in documents:
        filename = str(path.relative_to(ROOT))
        check("eight lenses in each declared half",len(file_domains)==8,filename, len(file_domains))
        file_claims = sum(len(d.get("claims",[])) for d in file_domains)
        minimum = 24 if path.name == "domains-a.json" else 32
        check("claim coverage meets the declared delivery count",file_claims>=minimum,filename,{"actual":file_claims,"declaredMinimum":minimum})
        walk_refs(data,filename)
        summary=data.get("summary",{}) if isinstance(data,dict) else {}
        if isinstance(summary,dict):
            expected_summary={"domains":len(file_domains),"concepts":sum(len(d.get("concepts",[])) for d in file_domains),"claims":file_claims,"uniqueMatchedAyahs":len({ref for d in file_domains for c in d.get("concepts",[]) for ref in c.get("occurrences",[])})}
            for key,value in expected_summary.items():
                if key in summary:
                    check("summary "+key+" matches declared records",summary[key]==value,filename+".summary."+key,{"declared":summary[key],"expected":value})
        for di,d in enumerate(file_domains):
            dp = filename+f".domains[{di}]"
            check("lens includes candidate concepts and claims",bool(d.get("concepts")) and bool(d.get("claims")),dp)
            local_concepts = {c.get("id") for c in d.get("concepts",[])}
            for ci,c in enumerate(d.get("concepts",[])):
                cp=dp+f".concepts[{ci}]"
                forms = c.get("forms")
                check("concept forms are a nonempty list of normalized lookup keys",isinstance(forms,list) and bool(forms) and all(isinstance(f,str) and normalize(f)==f for f in forms),cp+".forms")
                if not isinstance(forms,list):
                    forms=[]
                check("concept lookup keys all exist in complete lexicon",all(f in terms for f in forms),cp+".forms",[f for f in forms if f not in terms])
                check("concept lookup keys are not duplicated",len(set(forms))==len(forms),cp+".forms")
                valid_forms=[f for f in forms if f in terms]
                expected_occurrences = [o for f in valid_forms for o in terms[f]["occurrences"]]
                expected_refs = {f"{o[0]}:{o[1]}" for o in expected_occurrences}
                expected_surahs = {o[0] for o in expected_occurrences}
                if "occurrences" in c:
                    listed = c["occurrences"]
                    check("declared occurrence references contain the complete raw union",isinstance(listed,list) and all(isinstance(r,str) for r in listed) and set(listed)==expected_refs and len(listed)==len(expected_refs),cp+".occurrences",{"expectedAyahs":len(expected_refs),"declaredItems":len(listed) if isinstance(listed,list) else None})
                    counts["declaredOccurrenceLists"] += 1
                excluded=c.get("excludedOccurrences",[])
                check("excludedOccurrences is an explicit list",isinstance(excluded,list),cp+".excludedOccurrences")
                excluded_refs=[]
                if isinstance(excluded,list):
                    for ei,item in enumerate(excluded):
                        ref=item if isinstance(item,str) else item.get("ref") if isinstance(item,dict) else None
                        excluded_refs.append(ref)
                        ep=cp+f".excludedOccurrences[{ei}]"
                        check("excluded reference exists in raw selected occurrences",ref in expected_refs,ep,{"ref":ref})
                        check("semantic exclusion has an explicit reason",isinstance(item,dict) and bool(item.get("reason")),ep)
                        if "occurrences" in c and isinstance(c["occurrences"],list):
                            check("semantic exclusion remains visible in the raw occurrence list",ref in c["occurrences"],ep)
                audit=c.get("audit",{})
                if audit:
                    check("concept audit is a mapping",isinstance(audit,dict),cp+".audit")
                    if isinstance(audit,dict):
                        numeric_field(audit,"occurrenceCount",len(expected_occurrences),cp+".audit")
                        numeric_field(audit,"ayahCount",len(expected_refs),cp+".audit")
                        numeric_field(audit,"surahCount",len(expected_surahs),cp+".audit")
                        numeric_field(audit,"matchedOccurrences",len(expected_occurrences),cp+".audit")
                        numeric_field(audit,"matchedAyahs",len(expected_refs),cp+".audit")
                        if "forms" in audit:
                            rows=audit["forms"]
                            check("audit includes every declared lookup key",isinstance(rows,list) and {r.get("key") for r in rows if isinstance(r,dict)}==set(forms),cp+".audit.forms")
                            if isinstance(rows,list):
                                for fi,row in enumerate(rows):
                                    fp=cp+f".audit.forms[{fi}]"
                                    if not isinstance(row,dict) or row.get("key") not in terms:
                                        check("audit form key exists",False,fp)
                                        continue
                                    t=terms[row["key"]]
                                    if "count" in row:
                                        check("audit form count equals complete lexicon",row["count"]==t["count"],fp)
                                    if "surfaces" in row:
                                        surfaces=row["surfaces"]
                                        check("audit retains all original surfaces and their counts",isinstance(surfaces,list) and {s.get("text"):s.get("count") for s in surfaces if isinstance(s,dict)}=={s["text"]:s["count"] for s in t["forms"]},fp+".surfaces")
                        if "formsCoverage" in audit:
                            rows=audit["formsCoverage"]
                            check("audit formsCoverage includes every declared lookup key",isinstance(rows,list) and {r.get("form") for r in rows if isinstance(r,dict)}==set(forms),cp+".audit.formsCoverage")
                            if isinstance(rows,list):
                                for fi,row in enumerate(rows):
                                    fp=cp+f".audit.formsCoverage[{fi}]"
                                    if not isinstance(row,dict) or row.get("form") not in terms:
                                        check("audit form key exists",False,fp)
                                        continue
                                    t=terms[row["form"]]
                                    check("audit formsCoverage count equals complete lexicon",row.get("count")==t["count"],fp)
                                    check("audit formsCoverage retains all original surfaces and their counts",row.get("surfaces")=={s["text"]:s["count"] for s in t["forms"]},fp+".surfaces")
                        if "nearbyTerms" in audit:
                            adjacent=collections.Counter()
                            for form in valid_forms:
                                for sn,an,position in terms[form]["occurrences"]:
                                    pos=position-1
                                    units=source_units[f"{sn}:{an}"]
                                    adjacent.update(value for index,value in enumerate(units[max(0,pos-4):pos+5],max(0,pos-4)) if value and index!=pos)
                            expected_nearby=[{"term":term,"count":count} for term,count in adjacent.most_common(15)]
                            check("nearbyTerms independently matches the declared plus/minus-four-unit repeated windows and top15",audit["nearbyTerms"]==expected_nearby,cp+".audit.nearbyTerms")
                central=c.get("centralMeaning",{})
                check("candidate central meaning includes a statement and explicit status",isinstance(central,dict) and bool(central.get("statement")) and bool(central.get("status")),cp+".centralMeaning")
                if isinstance(central,dict):
                    evidence(central.get("evidence"),cp+".centralMeaning.evidence")
                    check("candidate central meaning includes qualitative confidence and basis",isinstance(central.get("confidence"),str) and bool(central.get("confidence")) and bool(central.get("basis")),cp+".centralMeaning")
                for ui,u in enumerate(c.get("usages",[])):
                    up=cp+f".usages[{ui}]"
                    evidence(u.get("evidence"),up+".evidence")
                    check("usage includes a statement and qualitative confidence",bool(u.get("statement")) and isinstance(u.get("confidence"),str) and bool(u.get("confidence")),up)
            for cli,claim in enumerate(d.get("claims",[])):
                clp=dp+f".claims[{cli}]"
                evidence(claim.get("evidence"),clp+".evidence")
                check("claim includes type, statement, basis, limits and qualitative confidence",all(bool(claim.get(k)) for k in ("type","statement","basis","limits")) and isinstance(claim.get("confidence"),str) and bool(claim.get("confidence")),clp)
                used=claim.get("concepts",[])
                check("claim concept identifiers all resolve",isinstance(used,list) and all(i in concept_map for i in used),clp+".concepts",[i for i in used if i not in concept_map] if isinstance(used,list) else used)
                relation=claim.get("relation")
                if relation:
                    check("relation endpoints resolve to candidate concept identifiers",isinstance(relation,dict) and relation.get("source") in concept_map and relation.get("target") in concept_map,clp+".relation")
                    if isinstance(relation,dict):
                        check("relation endpoints are declared in the claim concept list",all(relation.get(k) in used for k in ("source","target")),clp+".relation")
                        counts["relations"] += 1
    for path in INPUTS:
        check("analysis input unchanged during verification",sha(path)==snapshots[str(path.relative_to(ROOT))],str(path.relative_to(ROOT)))
    report={
        "result":"passed" if not errors else "failed",
        "checkedAt":dt.datetime.now(dt.timezone.utc).isoformat(),
        "scope_ar":"فحص بنية السجل، وجود المراجع في المرفق، صحة مفاتيح البحث، واكتمال حصر مطابقاتها والسطوح والأعداد المعلنة. لا يحكم على صحة المعنى أو استلزام الشواهد للدعوى أو اكتمال الاستقراء الدلالي.",
        "notVerified_ar":["الاستلزام الدلالي: وجود مرجع صحيح لا يثبت أن الدعوى مستنبطة منه.","تعريفات المفاهيم وحدودها ومعانيها المركزية والفرعية.","درجات اليقين الموضوعية أو استقلال الشواهد أو نفي المعاني البديلة.","اكتمال النموذج المعرفي أو قبول المستخدم أو جودة العرض البصري."],
        "nearbyTermsRule_ar":"حيث يعلن audit.nearbyTerms: أربع وحدات بياض قبل المطابقة وأربع بعدها داخل الآية؛ يستبعد مركز المطابقة والمفاتيح الفارغة، ويعاد العد لكل مطابقة ولو تداخلت النوافذ. أعلى15 حسب العدد ثم ترتيب الإدراج: المرور على forms بترتيب قائمتها ثم occurrences كل مفتاح بترتيب الفهرس. هذه نافذة بحث تحليلية لا علاقة معنوية مثبتة.",
        "sourceSha256":sha(source_path),"inputSha256":snapshots,
        "counts":{"domains":len(domains),"concepts":len(concepts),"claims":len(claims),**dict(counts),"checks":len(checks),"failures":len(errors),"warnings":len(warnings)},
        "errors":errors,"warnings":warnings,"checks":checks,
    }
    (ROOT / "reports").mkdir(exist_ok=True)
    output=ROOT / "reports/analysis-verification.json"
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"result":report["result"],"counts":report["counts"],"errors":errors[:30],"report":str(output.relative_to(ROOT))},ensure_ascii=False))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
