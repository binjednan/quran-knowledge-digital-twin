#!/usr/bin/env python3
"""Audit review provenance and currency; the reader's entailment judgment stays distinct."""
from pathlib import Path
import argparse,datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--require-complete',action='store_true');args=p.parse_args()
    source_hash=hashlib.sha256((ROOT/'quran-uthmani-numbered-ayahs.json').read_bytes()).hexdigest()
    unit_reviews={};review_candidates=[];errors=[];missing=[];counts={}
    for f in sorted((ROOT/'analysis/full-reading/reviews').glob('*.jsonl')):
        for line in f.read_text().splitlines():
            if not line.strip():continue
            r=json.loads(line);uid=r.get('unitId',r.get('id'))
            if not uid:errors.append({'kind':'malformed_review','file':str(f.relative_to(ROOT))});continue
            r['unitId']=uid;r['unitSha256']=r.get('unitSha256',r.get('contentSha256'));review_candidates.append(r)
    units=[];authors={}
    for part,author in [('a','semantic_a'),('b','semantic_b'),('c','corpus_pipeline')]:
        for line in (ROOT/f'analysis/full-reading/part-{part}.jsonl').read_text().splitlines():
            if line.strip():
                u=json.loads(line);units.append(u);authors[u['id']]=author
    hashes={u['id']:digest(u) for u in units}
    for r in review_candidates:
        prev=unit_reviews.get(r['unitId']);current=r['unitSha256']==hashes.get(r['unitId']);prev_current=prev and prev['unitSha256']==hashes.get(r['unitId'])
        followup=bool(r.get('supersedes'));prev_followup=bool(prev and prev.get('supersedes'))
        if current and prev_current and r.get('status')!=prev.get('status') and not (followup or prev_followup):errors.append({'kind':'unit','id':r['unitId'],'reasons':['conflicting_current_reviews_without_resolution']})
        if current and (not prev_current or followup or not prev_followup):unit_reviews[r['unitId']]=r
        elif not current and not prev_current:unit_reviews[r['unitId']]=r
    valid=0
    for u in units:
        r=unit_reviews.get(u['id'])
        if not r:missing.append({'kind':'unit','id':u['id']});continue
        reasons=[]
        if r.get('status')!='accepted_as_scoped':reasons.append('unresolved_findings')
        if r['unitSha256']!=digest(u):reasons.append('stale_content_hash')
        if r.get('sourceSha256')!=source_hash:reasons.append('source_hash')
        if r.get('reviewer','').removeprefix('/root/')==authors[u['id']]:reasons.append('not_independent')
        expected={f"{u['surah']}:{a}" for a in range(u['start'],u['end']+1)}
        if not expected<=set(r.get('reviewedEvidence',[])):reasons.append('incomplete_reviewed_evidence')
        if not (r.get('specificChecks') or r.get('reviewMethod') or r.get('assessment')):reasons.append('missing_reading_assessment')
        if reasons:errors.append({'kind':'unit','id':u['id'],'reasons':reasons,'findings':r.get('findings',[])})
        else:valid+=1
    counts.update(units=len(units),acceptedCurrentUnitReviews=valid,missingUnitReviews=len(units)-len({u['id'] for u in units}&set(unit_reviews)))
    assignment_data=json.loads((ROOT/'analysis/full-reading/STUDY-ASSIGNMENTS.json').read_text());assignments=assignment_data['assignments'];owners={id:author for author,ids in assignments.items() for id in ids};owners.update(assignment_data['systemAuthors'])
    for kind,folder,expected_count in [('study','studies',88),('system','systems',16)]:
        files=list((ROOT/f'analysis/full-reading/{folder}').glob('*.json'));accepted=0
        for f in files:
            s=json.loads(f.read_text());rev=s.get('independentReview',{})
            if s.get('reviewStatus')!='independently_reviewed_as_scoped':missing.append({'kind':kind,'id':s['id'],'state':s.get('reviewStatus')});continue
            canonical={k:v for k,v in s.items() if k not in ['reviewStatus','independentReview']}
            if rev.get('contentSha256')!=digest(canonical):errors.append({'kind':kind,'id':s['id'],'reasons':['stale_content_hash']});continue
            owner=owners.get(s['id'])
            if not owner:errors.append({'kind':kind,'id':s['id'],'reasons':['missing_declared_author']});continue
            if owner==rev.get('reviewer','').removeprefix('/root/'):errors.append({'kind':kind,'id':s['id'],'reasons':['not_independent']});continue
            if not (ROOT/rev.get('report','missing')).is_file():errors.append({'kind':kind,'id':s['id'],'reasons':['missing_review_record']});continue
            accepted+=1
        prefix='studies' if kind=='study' else 'systems';counts[prefix+'Authored']=len(files);counts[prefix+'AcceptedCurrent']=accepted;counts[prefix+'Required']=expected_count
    complete=not missing and not errors and counts['studiesAuthored']==88 and counts['systemsAuthored']==16
    result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':source_hash,'status':'current_scoped_reviews_complete' if complete else 'in_progress','counts':counts,'missing':missing,'errors':errors,'acceptanceLimit':'Review records assess scoped semantic claims. Hash and evidence checks establish currency and coverage, not semantic entailment or user acceptance.'}
    (ROOT/'reports/independent-review-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'status':result['status'],'counts':counts,'errorCount':len(errors)},ensure_ascii=False))
    if args.require_complete and not complete:raise SystemExit(1)
if __name__=='__main__':main()
