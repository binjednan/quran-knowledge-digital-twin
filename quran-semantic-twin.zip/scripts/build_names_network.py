#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build literal, reviewed name-label co-occurrence from the unmodified corpus."""
from pathlib import Path
from collections import defaultdict, Counter
from itertools import combinations
import datetime, hashlib, json, unicodedata

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'quran-uthmani-numbered-ayahs.json'
REGISTRIES = ['data/names/people-registry.json', 'data/names/entities-registry.json']
SOURCE_SHA = '25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s): return ''.join(c for c in s if not unicodedata.category(c).startswith('M') and c != 'ـ').replace('ٱ', 'ا')
def refsort(r): return tuple(map(int, r.split(':')))
def load(p): return json.loads((ROOT / p).read_text())

def main():
    assert sha(SOURCE) == SOURCE_SHA
    source = load(SOURCE.name)
    entries = [e for p in REGISTRIES for e in load(p)['entries']]
    ids = [e['id'] for e in entries]
    assert len(ids) == len(set(ids)), 'Duplicate name identifiers'
    assert len({e['label'] for e in entries}) == len(entries), 'Duplicate name labels'
    ayahs = {f"{s['number']}:{a['number']}": a['text'] for s in source['surahs'] for a in s['ayahs']}
    tokenized = {ref: [(i+1, raw, norm(raw)) for i, raw in enumerate(text.split())] for ref, text in ayahs.items()}
    nodes, by_verse = [], defaultdict(set)
    for entry in entries:
        patterns = [[key] for key in entry.get('keys', [])] + entry.get('patterns', [])
        assert patterns and all(p and all(norm(k) == k for k in p) for p in patterns), entry['id']
        refs, occurrences = set(), []
        include = set(entry['includeRefs']) if 'includeRefs' in entry else None
        exclude = set(entry.get('excludeRefs', []))
        assert (include or set()) <= ayahs.keys() and exclude <= ayahs.keys()
        assert entry.get('evidenceRefs') and set(entry['evidenceRefs']) <= ayahs.keys()
        for ref, tokens in tokenized.items():
            if (include is not None and ref not in include) or ref in exclude: continue
            found = set()
            # Empty search tokens are standalone source marks. Their source positions stay intact.
            words = [(pos, raw, key) for pos, raw, key in tokens if key]
            keys = [t[2] for t in words]
            for pattern in patterns:
                for start in range(len(words)-len(pattern)+1):
                    if keys[start:start+len(pattern)] != pattern: continue
                    chunk = words[start:start+len(pattern)]
                    span = (chunk[0][0], chunk[-1][0])
                    if span in found: continue
                    found.add(span)
                    occurrences.append({'ref': ref, 'start': span[0], 'end': span[1], 'surface': ' '.join(raw for _, raw, _ in tokens[span[0]-1:span[1]])})
            if found: refs.add(ref); by_verse[ref].add(entry['id'])
        assert refs, 'No source matches: ' + entry['id']
        if include is not None: assert include <= refs, 'Unmatched included references: ' + entry['id'] + str(include-refs)
        nodes.append({**entry, 'includedByDefault': entry.get('includedByDefault', True), 'refs': sorted(refs, key=refsort), 'ayahCount': len(refs), 'mentionCount': len(occurrences), 'occurrences': occurrences})
    pairs = defaultdict(list)
    for ref, names in by_verse.items():
        for pair in combinations(sorted(names), 2): pairs[pair].append(ref)
    edges = [{'id': a+'--'+b, 'source': a, 'target': b, 'weight': len(refs), 'refs': sorted(refs, key=refsort)} for (a,b), refs in sorted(pairs.items())]
    adjacent, strengths = defaultdict(set), Counter()
    for e in edges:
        adjacent[e['source']].add(e['target']); adjacent[e['target']].add(e['source'])
        strengths[e['source']] += e['weight']; strengths[e['target']] += e['weight']
    for n in nodes: n.update(degree=len(adjacent[n['id']]), strength=strengths[n['id']])
    inputs = REGISTRIES + [SOURCE.name, 'scripts/build_names_network.py']
    result = {
        'metadata': {'builtAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceSha256': SOURCE_SHA, 'inputSha256': {p:sha(ROOT/p) for p in inputs}},
        'policy': {
            'unit': 'الآية المرقمة كما وردت في المرفق، دون نقل الأسماء من سياقها إلى آية أخرى.',
            'edgeWeight': 'عدد الآيات المختلفة التي اجتمعت فيها تسميتا العلم؛ لكل زوج زيادة واحدة في الآية، بصرف النظر عن عدد تكرار الاسم فيها. لا وصلات ذاتية ولا اتجاه للخط.',
            'identity': 'العقد تسميات الأعلام الظاهرة، وليست إثباتًا لاتحاد الذوات في كل المواضع. عيسى والمسيح وأحمد ومحمد تسميات مستقلة؛ لا تُضم الضمائر ولا الأوصاف العامة إلى أسمائها.',
            'classification': 'تمييز العلمية قرار قراءة معلل بشواهده، ويظل المحتمل ظاهرًا في طبقة اختيارية. لا تستند المطابقة إلى قاموس أعلام أو معرفة تاريخية خارج النص.',
            'scope': 'فُحصت مفاتيح النص كله وصور الأعلام المسجلة مع سياقاتها. يبقى تعيين ما يعد علمًا أو لقبًا أو وصفًا قابلاً للمراجعة من الأدلة؛ اكتمال حساب الأزواج داخل السجل لا يثبت استنفاد كل احتمال تصنيفي.',
            'normalization': 'إزالة علامات UnicodeM والتطويل وتبديل ٱ إلى ا للبحث فقط. تبقى صور المصدر وإحداثيات كلمات البياض محفوظة؛ لا جذور ولا تسوية همزات ولا نقل أسماء ضمنية.',
            'position': 'حجم العقدة بحسب عدد آيات الاسم. سمك الخط يتزايد مع عدد الآيات المشتركة. مكان العقدة وحركة الرسم وطول الخط ترتيب بصري، لا دلالة معنوية أو سببية.'
        },
        'nodes': sorted(nodes, key=lambda n: (-n['ayahCount'], n['id'])), 'edges': edges,
        'counts': {'registeredLabels': len(nodes), 'defaultLabels': sum(n['includedByDefault'] for n in nodes), 'optionalLabels': sum(not n['includedByDefault'] for n in nodes), 'cooccurrencePairs': len(edges), 'pairAyahInstances': sum(e['weight'] for e in edges), 'ayahsWithNames': len(by_verse), 'sourceAyahs':len(ayahs)}
    }
    path = ROOT / 'data/names/network.json'; path.write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':'))+'\n')
    print(json.dumps({'path':str(path.relative_to(ROOT)), **result['counts']}, ensure_ascii=False))

if __name__ == '__main__': main()
