#!/usr/bin/env python3
"""Reject a network from a different reading snapshot before writing outputs."""
from pathlib import Path
import copy,datetime,json,runpy,sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
for script in ['build_semantic_report.py','export_semantic.py']:
    ns=runpy.run_path(str(ROOT/'scripts'/script))['main'].__globals__
    original=ns['load']
    def mismatched_load(name):
        value=original(name)
        if name=='data/full-reading/network.json':
            value=copy.deepcopy(value)
            value['metadata']['builtAt']='intentionally-different-snapshot'
        return value
    ns['load']=mismatched_load
    previous=sys.argv;sys.argv=[script,'--draft']
    try:
        ns['main']()
    except AssertionError as error:
        assert str(error)=='Reading/network snapshots differ',(script,str(error))
        checks.append({'script':script,'mixedSnapshotRejected':True,'outputsWritten':False})
    else:
        raise AssertionError('Mixed snapshot was accepted: '+script)
    finally:sys.argv=previous
report={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','checks':checks}
(ROOT/'reports/network-snapshot-guard-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
