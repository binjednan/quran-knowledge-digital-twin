#!/usr/bin/env python3
"""Bundle the reviewed semantic edition, retaining edition 1 and the source."""
from pathlib import Path
import argparse,datetime,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--draft',action='store_true');args=p.parse_args()
    reading=load('data/full-reading/reading.json');network=load('data/full-reading/network.json');systems=load('data/full-reading/systems.json')
    source=ROOT/'quran-uthmani-numbered-ayahs.json';raw=load(source.name)
    assert sha(source)=='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'
    if not args.draft:
        assert not reading['metadata']['draft'] and not network['metadata']['draft'] and not systems['metadata']['draft'],'Reviewed build required'
        assert len(reading['authoredStudies'])==88 and len(systems['systems'])==16
    assert reading['metadata']==network['metadata'],'Reading/network snapshots differ'
    for dataset in [reading,network,systems]:
        assert dataset['metadata']['sourceSha256']==sha(source),'Dataset source differs'
        for path,expected in dataset['metadata']['inputSha256'].items():assert sha(ROOT/path)==expected,'Stale input: '+path
    names=load('data/names/network.json')
    assert names['metadata']['sourceSha256']==sha(source)
    for path,expected in names['metadata']['inputSha256'].items():assert sha(ROOT/path)==expected,'Stale name registry: '+path
    payload={'corpus':load('data/corpus.json'),'lexicon':load('data/lexicon.json'),'overview':load('data/overview.json'),'analysis':load('analysis/combined.json'),'manifest':load('data/manifest.json'),'namesNetwork':names,
      'sourceMetadata':raw['metadata'],'sourceDerivation':raw['derivation'],'fullReading':reading,'semanticNetwork':network,'systemModel':systems,
      'build':{'builtAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha(source),'edition':2,'draft':args.draft,'semanticStatus':'نسخة عمل قيد المراجعة' if args.draft else 'قراءة مكتوبة ومراجعة ضمن نطاق معلن؛ لا دعوى استنفاد كل معنى','networkPolicy':'لا اتصال ولا مصادر خارجية'}}
    text=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    app=(ROOT/'ui/app.js').read_text()
    assert 'render();\nwindow.QuranTwin=' in app
    app=app.replace('render();\nwindow.QuranTwin=','window.QuranTwin=')+'\n'+ '\n'.join((ROOT/p).read_text() for p in ['ui/network-motion.js','ui/names-network.js','ui/full-reading.js'])
    style='\n'.join((ROOT/p).read_text() for p in ['ui/style.css','ui/full-reading.css','ui/network-motion.css','ui/names-network.css'])
    html=(ROOT/'ui/template.html').read_text().replace('النسخة المحلية ١','الإصدار الدلالي ٢'+(' · نسخة عمل' if args.draft else '')).replace('/*__STYLE__*/',style).replace('/*__DATA__*/',text).replace('/*__APP__*/',app)
    for private in ['/Users/','/private/','/tmp/','github_pat_','ghp_']:assert private not in html,'Private path/token pattern found: '+private
    target=ROOT/'التوأم-المعرفي-للقرآن-الدلالي.html';target.write_text(html)
    inputs=['ui/app.js','ui/full-reading.js','ui/style.css','ui/full-reading.css','ui/template.html','ui/network-motion.js','ui/network-motion.css','ui/names-network.js','ui/names-network.css','data/names/network.json','data/full-reading/reading.json','data/full-reading/network.json','data/full-reading/systems.json','scripts/build_semantic_report.py']+list(names['metadata']['inputSha256'])
    result={'builtAt':payload['build']['builtAt'],'artifact':target.name,'sha256':sha(target),'bytes':target.stat().st_size,'draft':args.draft,'units':len(reading['units']),'studies':len(reading['authoredStudies']),'systems':len(systems['systems']),'relations':len(network['edges']),'names':names['counts'],'inputSha256':{p:sha(ROOT/p) for p in inputs}}
    (ROOT/'reports/semantic-artifact-build.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
