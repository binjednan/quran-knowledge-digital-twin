#!/usr/bin/env python3
"""Check authored study provenance and declared lexical scope. No meaning approval."""
from pathlib import Path
import datetime,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'quran-uthmani-numbered-ayahs.json'
raw=json.loads(source.read_text());sha=hashlib.sha256(source.read_bytes()).hexdigest()
ayahs={f"{s['number']}:{a['number']}":a['text'] for s in raw['surahs'] for a in s['ayahs']}
terms={t['id']:t for t in json.loads((ROOT/'data/lexicon.json').read_text())['terms']}
concepts={c['id']:c for d in json.loads((ROOT/'analysis/combined.json').read_text())['domains'] for c in d['concepts']}
def references(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if key in ['refs','evidence','allReferences','references','nearContext','coreVerbReferences','comparisonOnlyVerbReferences'] and isinstance(item,list):
                yield from (x for x in item if isinstance(x,str) and ':' in x)
            else:yield from references(item)
    elif isinstance(value,list):
        for item in value:yield from references(item)
def termrefs(keys):return {f'{o[0]}:{o[1]}' for key in keys for o in terms[key]['occurrences']}
def grouprefs(group):
    value=group.get('refs',group.get('references',group.get('evidence',[])))
    return [value] if isinstance(value,str) else value
def check_scope(study):
    checks=[]
    def check(name,value):
        checks.append({'name':name,'passed':bool(value)})
    check('source_hash',study['sourceSha256']==sha)
    refs=list(references(study));check('all_references_exist',all(r in ayahs for r in refs))
    if 'searchScope' in study:
        scope=study['searchScope'];check('all_keys_exist',all(k in terms for k in scope['keys']))
        check('complete_declared_key_reference_list',termrefs(scope['keys'])==set(scope['allReferences']))
        if 'unitCount' in scope:check('declared_scope_unit_count',scope['unitCount']==sum(terms[k]['count'] for k in scope['keys']))
        if 'usageGroups' in study:
            compared={r for group in study['usageGroups'] for r in grouprefs(group)}
            for case in study.get('comparisonCases',[]):compared.update(case.get('refs',[case['ref']] if 'ref' in case else []))
            check('all_scope_references_compared',set(scope['allReferences']).issubset(compared))
        if 'usageComparison' in study:check('all_scope_references_compared',set(scope['allReferences'])=={entry['ref'] for entry in study['usageComparison']})
    if 'reusesStudy' in study:
        other=study['reusesStudy'];check('reused_study_exists',(ROOT/f'analysis/full-reading/studies/{other}.json').is_file())
        check('same_initial_form_set',set(concepts[study['id']]['forms'])==set(concepts[other]['forms']))
        check('same_initial_reference_set',set(concepts[study['id']]['occurrences'])==set(concepts[other]['occurrences']))
    if 'expandedSearchScope' in study:
        scope=study['expandedSearchScope']
        if 'surfaceSeparatedKey' not in scope:
            keys=list(dict.fromkeys(scope['coreKeys']+scope.get('comparisonOnlyKeys',[])));core=termrefs(keys)
            check('expanded_keys_exist',all(k in terms for k in keys))
            check('expanded_reference_list',core==set(scope.get('references',scope.get('allReferences',[]))))
            check('expanded_unit_count',sum(terms[k]['count'] for k in keys)==scope['candidateUnits'])
            check('expanded_ayah_count',len(core)==scope['candidateAyahs'])
            compared={r for group in study.get('usageGroups',[]) for r in grouprefs(group)}
            for case in study.get('comparisonCases',[]):compared.update(grouprefs(case))
            check('expanded_references_compared',core.issubset(compared))
        else:
            check_hawa_scope(study,check)
    raw_units=study.get('rawUnits',study.get('rawData',{}).get('occurrences',[]))
    if raw_units:
        valid=True
        for unit in raw_units:
            ref=unit.get('ref',unit.get('reference'));position=unit.get('position');surface=unit.get('surface');key=unit.get('key')
            words=ayahs.get(ref,'').split()
            if not isinstance(position,int) or not 1<=position<=len(words) or words[position-1]!=surface or key not in terms:valid=False;break
            if not any(o[0]==int(ref.split(':')[0]) and o[1]==int(ref.split(':')[1]) and o[2]==position for o in terms[key]['occurrences']):valid=False;break
        check('all_raw_units_match_source_surface_and_position',valid)
    if study.get('reviewStatus')=='independently_reviewed_as_scoped':
        canonical={k:v for k,v in study.items() if k not in ['reviewStatus','independentReview']}
        content_sha=hashlib.sha256(json.dumps(canonical,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        check('independent_review_matches_current_content',study.get('independentReview',{}).get('contentSha256')==content_sha)
    return {'id':study['id'],'checks':checks,'referenceEntries':len(refs),'mechanicalPass':all(c['passed'] for c in checks),'semanticStatus':study['reviewStatus']}

def check_hawa_scope(study,check):
        scope=study['expandedSearchScope'];core=termrefs(scope['coreKeys'])|set(scope['coreVerbReferences'])
        comparison=termrefs(scope['comparisonOnlyKeys'])|set(scope['comparisonOnlyVerbReferences'])
        check('all_expanded_keys_exist',all(k in terms for k in scope['coreKeys']+scope['comparisonOnlyKeys']+[scope['surfaceSeparatedKey']]))
        core_count=sum(terms[k]['count'] for k in scope['coreKeys'])+sum(1 for o in terms[scope['surfaceSeparatedKey']]['occurrences'] if f'{o[0]}:{o[1]}' in scope['coreVerbReferences'])
        comparison_count=sum(terms[k]['count'] for k in scope['comparisonOnlyKeys'])+sum(1 for o in terms[scope['surfaceSeparatedKey']]['occurrences'] if f'{o[0]}:{o[1]}' in scope['comparisonOnlyVerbReferences'])
        check('declared_core_units',core_count==scope['coreUnits']);check('declared_core_ayahs',len(core)==scope['coreAyahs'])
        check('declared_candidate_units',core_count+comparison_count==scope['candidateUnits']);check('declared_candidate_ayahs',len(core|comparison)==scope['candidateAyahs'])
        check('each_core_reference_has_authored_usage',core=={r for group in study['usageGroups'] for r in group['refs']})
        check('each_comparison_reference_has_authored_case',comparison=={r for group in study['comparisonCases'] for r in group['refs']})
        check('same_normalized_verb_key_separated',set(scope['coreVerbReferences']).isdisjoint(scope['comparisonOnlyVerbReferences']) and set(scope['coreVerbReferences']+scope['comparisonOnlyVerbReferences'])==termrefs([scope['surfaceSeparatedKey']]))

results=[];files={}
for path in sorted((ROOT/'analysis/full-reading/studies').glob('*.json')):
    study=json.loads(path.read_text());results.append(check_scope(study));files[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
report={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha,'inputSha256':files,'authoredStudies':len(results),'initialStudyCandidates':88,'notYetAuthoredStudyCount':88-len(results),'checks':[c for r in results for c in r['checks']],'results':results,'scope':'provenance and declared scope only; not semantic entailment or full epistemic completion'}
(ROOT/'reports/concept-study-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'authoredStudies':len(results),'mechanicalPass':all(r['mechanicalPass'] for r in results),'checks':len(report['checks'])},ensure_ascii=False))
if not all(r['mechanicalPass'] for r in results):raise SystemExit(1)
