#!/usr/bin/env python3
"""Package only reviewable deliverables, never browser profiles or duplicate source copies."""
from pathlib import Path
import hashlib, json, zipfile, datetime

ROOT=Path(__file__).resolve().parents[1]
FILES=['التوأم-المعرفي-للقرآن.html','README-AR.md','quran-uthmani-numbered-ayahs.json']
DIRS=['ui','scripts','data','analysis','exports']
REPORTS=['STATUS-AR.md','analysis-verification.json','ui-verification.json','semantic-review.json','candidate-export-verification.json','desktop-home.png','desktop-network.png','desktop-systems.png','desktop-relations.png','iphone-home.png','iphone-network.png','iphone-systems.png','desktop-dark.png','detail-knowledge.png','detail-flow.png','detail-evidence.png','detail-hierarchy-iphone.png']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    paths=[ROOT/p for p in FILES]
    paths += [p for d in DIRS for p in (ROOT/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [ROOT/'reports'/p for p in REPORTS]
    for p in paths:
        if not p.is_file():raise SystemExit('Missing delivery file: '+str(p))
    ui=json.loads((ROOT/'reports/ui-verification.json').read_text())
    assert ui['status']=='passed','UI verification must pass before packaging'
    assert sha(ROOT/FILES[0])==ui['artifactSha256'],'HTML changed after UI verification'
    assert sha(ROOT/FILES[2])=='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589','Source changed'
    analysis=json.loads((ROOT/'reports/analysis-verification.json').read_text())
    assert analysis['result']=='passed','Analysis link verification must pass'
    for rel,expected in analysis['inputSha256'].items():assert sha(ROOT/rel)==expected,rel+' changed after verification'
    data=json.loads((ROOT/'data/manifest.json').read_text())
    for item in data['files']:assert sha(ROOT/item['path'])==item['sha256'],item['path']+' changed after data verification'
    candidate=json.loads((ROOT/'reports/candidate-export-verification.json').read_text())
    assert candidate['result']=='passed','Candidate export verification must pass'
    for rel,expected in candidate['inputSha256'].items():assert sha(ROOT/rel)==expected,rel+' changed after candidate export'
    manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha(ROOT/FILES[2]),'meaningStatus':'استقراء أولي غير مكتمل دلالياً؛ لا اعتماد نهائي','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(paths))]}
    m=ROOT/'reports/delivery-manifest.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));paths.append(m)
    target=ROOT/'حزمة-التوأم-المعرفي-للقرآن.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(paths)):z.write(p,p.relative_to(ROOT))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for entry in manifest['files']:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256'],entry['path']
    (ROOT/'reports/package-checksum.txt').write_text(sha(target)+'  '+target.name+'\n')
    print(json.dumps({'package':str(target),'bytes':target.stat().st_size,'sha256':sha(target),'verifiedFiles':len(manifest['files'])},ensure_ascii=False))
if __name__=='__main__':main()
