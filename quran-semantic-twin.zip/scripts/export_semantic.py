#!/usr/bin/env python3
"""Portable semantic database and GraphML, preserving local scope and source text."""
from pathlib import Path
import argparse,datetime,hashlib,json,sqlite3,tempfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text())
def j(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--draft',action='store_true');args=p.parse_args()
    read=load('data/full-reading/reading.json');net=load('data/full-reading/network.json');model=load('data/full-reading/systems.json');raw=load('quran-uthmani-numbered-ayahs.json')
    if not args.draft:assert not read['metadata']['draft'] and not net['metadata']['draft'] and not model['metadata']['draft']
    assert read['metadata']==net['metadata'],'Reading/network snapshots differ'
    for dataset in [read,net,model]:
        assert dataset['metadata']['sourceSha256']==sha(ROOT/'quran-uthmani-numbered-ayahs.json'),'Dataset source differs'
        for name,digest in dataset['metadata']['inputSha256'].items():assert sha(ROOT/name)==digest,'Stale input: '+name
    assert sha(ROOT/'quran-uthmani-numbered-ayahs.json')==read['metadata']['sourceSha256']
    dest=ROOT/'exports';dest.mkdir(exist_ok=True)
    work=ROOT/'.work';work.mkdir(exist_ok=True)
    handle=tempfile.NamedTemporaryFile(prefix='semantic-',suffix='.sqlite',dir=work,delete=False);tmp=Path(handle.name);handle.close()
    db=sqlite3.connect(tmp);db.executescript('''
      PRAGMA foreign_keys=ON;
      CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
      CREATE TABLE ayahs(ref TEXT PRIMARY KEY,surah INTEGER,ayah INTEGER,text TEXT NOT NULL);
      CREATE TABLE units(id TEXT PRIMARY KEY,surah INTEGER,start INTEGER,end INTEGER,summary TEXT,record_json TEXT NOT NULL,review_json TEXT);
      CREATE TABLE verse_units(ref TEXT PRIMARY KEY REFERENCES ayahs(ref),unit_id TEXT REFERENCES units(id));
      CREATE TABLE label_groups(id TEXT PRIMARY KEY,label TEXT NOT NULL,degree INTEGER,incoming INTEGER,outgoing INTEGER,policy TEXT);
      CREATE TABLE local_labels(id TEXT PRIMARY KEY,unit_id TEXT REFERENCES units(id),group_id TEXT REFERENCES label_groups(id));
      CREATE TABLE mentions(id INTEGER PRIMARY KEY,local_label TEXT REFERENCES local_labels(id),role TEXT,evidence_json TEXT);
      CREATE TABLE relations(id TEXT PRIMARY KEY,unit_id TEXT REFERENCES units(id),source_local TEXT REFERENCES local_labels(id),target_local TEXT REFERENCES local_labels(id),predicate TEXT,polarity TEXT,scope TEXT,quote TEXT,confidence TEXT,record_json TEXT);
      CREATE TABLE relation_evidence(relation_id TEXT REFERENCES relations(id),ref TEXT REFERENCES ayahs(ref),PRIMARY KEY(relation_id,ref));
      CREATE TABLE lenses(unit_id TEXT REFERENCES units(id),lens_id TEXT,basis TEXT,evidence_json TEXT,PRIMARY KEY(unit_id,lens_id));
      CREATE TABLE candidate_usages(id INTEGER PRIMARY KEY,unit_id TEXT REFERENCES units(id),concept_id TEXT,usage TEXT,confidence TEXT,limits TEXT,refs_json TEXT);
      CREATE TABLE studies(id TEXT PRIMARY KEY,title TEXT,review_status TEXT,record_json TEXT NOT NULL);
      CREATE TABLE study_occurrences(study_id TEXT REFERENCES studies(id),ref TEXT REFERENCES ayahs(ref),position INTEGER,surface TEXT,search_key TEXT);
      CREATE TABLE systems(id TEXT PRIMARY KEY,title TEXT,record_json TEXT NOT NULL);
      CREATE TABLE bridges(id TEXT PRIMARY KEY,authored_in TEXT REFERENCES systems(id),source_system TEXT,target_system TEXT,predicate TEXT,evidence_json TEXT,record_json TEXT);
      CREATE INDEX relations_source_idx ON relations(source_local);
      CREATE INDEX relations_target_idx ON relations(target_local);
      CREATE INDEX relations_polarity_idx ON relations(polarity);
      CREATE INDEX evidence_ref_idx ON relation_evidence(ref);
      CREATE INDEX label_group_idx ON local_labels(group_id);
      CREATE INDEX study_ref_idx ON study_occurrences(ref);
    ''')
    meta={'sourceSha256':read['metadata']['sourceSha256'],'builtAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'draft':args.draft,'sourceNotice':raw['derivation'],'graphPolicy':net['metricsPolicy'],'scopePolicy':'Every local label belongs to one authored unit. Equal label groups index literal spellings only; they do not merge meanings or identities. Typed relation records preserve voice, condition, negation and evidence.'}
    db.executemany('INSERT INTO metadata VALUES (?,?)',[(k,j(v)) for k,v in meta.items()])
    source_rows=[(f"{s['number']}:{a['number']}",s['number'],a['number'],a['text']) for s in raw['surahs'] for a in s['ayahs']]
    db.executemany('INSERT INTO ayahs VALUES (?,?,?,?)',source_rows)
    db.executemany('INSERT INTO units VALUES (?,?,?,?,?,?,?)',[(u['id'],u['surah'],u['start'],u['end'],u['summary'],j(u),j(read['independentReviews'].get(u['id']))) for u in read['units']])
    db.executemany('INSERT INTO verse_units VALUES (?,?)',read['verseToUnit'].items())
    db.executemany('INSERT INTO label_groups VALUES (?,?,?,?,?,?)',[(n['id'],n['label'],n['degree'],n['incomingRecords'],n['outgoingRecords'],net['metricsPolicy']) for n in net['nodes']])
    local={(e['unit'],e[k]) for e in net['edges'] for k in ['source','target']}|{(m['unit'],m['labelId']) for m in net['mentions']}
    localid=lambda unit,label:unit+'::label::'+label
    db.executemany('INSERT INTO local_labels VALUES (?,?,?)',[(localid(u,n),u,n) for u,n in sorted(local)])
    db.executemany('INSERT INTO mentions(local_label,role,evidence_json) VALUES (?,?,?)',[(localid(m['unit'],m['labelId']),m['localRole'],j(m['evidence'])) for m in net['mentions']])
    db.executemany('INSERT INTO relations VALUES (?,?,?,?,?,?,?,?,?,?)',[(e['id'],e['unit'],localid(e['unit'],e['source']),localid(e['unit'],e['target']),e['predicate'],e['polarity'],e['scope'],e['quote'],e['confidence'],j(e)) for e in net['edges']])
    db.executemany('INSERT INTO relation_evidence VALUES (?,?)',[(e['id'],ref) for e in net['edges'] for ref in dict.fromkeys(e['evidence'])])
    db.executemany('INSERT INTO lenses VALUES (?,?,?,?)',[(u['id'],l['id'],l['basis'],j(l['evidence'])) for u in read['units'] for l in u['lenses']])
    db.executemany('INSERT INTO candidate_usages(unit_id,concept_id,usage,confidence,limits,refs_json) VALUES (?,?,?,?,?,?)',[(u['id'],g['conceptId'],g['usage'],g['confidence'],g['limits'],j(g['refs'])) for u in read['units'] for g in u['seedUsages']])
    for s in read['authoredStudies'].values():
        db.execute('INSERT INTO studies VALUES (?,?,?,?)',(s['id'],s['title'],s['reviewStatus'],j(s)))
        units=s.get('rawUnits',s.get('rawData',{}).get('occurrences',[]))
        db.executemany('INSERT INTO study_occurrences VALUES (?,?,?,?,?)',[(s['id'],u.get('ref',u.get('reference')),u['position'],u['surface'],u['key']) for u in units])
    syntheses={s['id']:s for s in model['systems']}
    db.executemany('INSERT INTO systems VALUES (?,?,?)',[(id,title,j(syntheses.get(id,{'id':id,'title':title,'status':'user_lens_synthesis_not_yet_authored'}))) for id,title in model['systemTitles'].items()])
    db.executemany('INSERT INTO bridges VALUES (?,?,?,?,?,?,?)',[(b['id'],b['authoredInSystem'],b['sourceSystem'],b['targetSystem'],b['predicate'],j(b['evidence']),j(b)) for b in model['bridges']])
    db.commit();assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not db.execute('PRAGMA foreign_key_check').fetchall()
    assert db.execute('SELECT COUNT(*) FROM ayahs').fetchone()[0]==6236
    assert db.execute('SELECT COUNT(*) FROM relations').fetchone()[0]==len(net['edges'])
    stored={r:t for r,t in db.execute('SELECT ref,text FROM ayahs')};assert all(stored[r]==t for r,_,_,t in source_rows)
    for rid,quote in db.execute('SELECT id,quote FROM relations'):
        refs=[r[0] for r in db.execute('SELECT ref FROM relation_evidence WHERE relation_id=?',(rid,))]
        assert any(quote in stored[r] for r in refs),rid
    db.close();dbtarget=dest/'quran-semantic-twin.sqlite';tmp.replace(dbtarget)
    ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
    root=ET.Element('{'+ns+'}graphml')
    keys=['kind','label','text','unit','group','predicate','polarity','scope','quote','confidence','evidence','policy','record','rights']
    for k in keys:ET.SubElement(root,'{'+ns+'}key',{'id':k,'for':'all','attr.name':k,'attr.type':'string'})
    graph=ET.SubElement(root,'{'+ns+'}graph',{'id':'QuranScopedSemanticTwin','edgedefault':'directed'})
    def data(el,key,value):ET.SubElement(el,'{'+ns+'}data',{'key':key}).text=value if isinstance(value,str) else j(value)
    data(graph,'policy',meta['scopePolicy']);data(graph,'rights',raw['derivation']['copyrightNotice'])
    nodeids=set();edgecount=0
    def node(id,kind,label,**fields):
        assert id not in nodeids;nodeids.add(id);el=ET.SubElement(graph,'{'+ns+'}node',{'id':id});data(el,'kind',kind);data(el,'label',label)
        for k,v in fields.items():data(el,k,v)
    def edge(a,b,kind,**fields):
        nonlocal edgecount
        assert a in nodeids and b in nodeids,(a,b);el=ET.SubElement(graph,'{'+ns+'}edge',{'id':'e'+str(edgecount),'source':a,'target':b});edgecount+=1;data(el,'kind',kind)
        for k,v in fields.items():data(el,k,v)
    groups={n['id']:n['label'] for n in net['nodes']}
    for n in net['nodes']:node('group:'+n['id'],'literal_label_index',n['label'])
    for u in read['units']:node('unit:'+u['id'],'authored_reading_unit',u['summary'],unit=u['id'],record=u)
    for ref,_,_,text in source_rows:node('ayah:'+ref,'source_ayah',ref,text=text)
    for unit,label in sorted(local):node(localid(unit,label),'local_authored_label',groups[label],unit=unit,group=label)
    for unit,label in sorted(local):edge(localid(unit,label),'group:'+label,'literal_index_membership');edge('unit:'+unit,localid(unit,label),'local_label_membership')
    for ref,uid in read['verseToUnit'].items():edge('unit:'+uid,'ayah:'+ref,'source_range_membership')
    for e in net['edges']:edge(localid(e['unit'],e['source']),localid(e['unit'],e['target']),'authored_relation',predicate=e['predicate'],polarity=e['polarity'],scope=e['scope'],quote=e['quote'],confidence=e['confidence'],evidence=e['evidence'],record=e)
    for id,title in model['systemTitles'].items():node('system:'+id,'authored_system_lens' if id in syntheses else 'user_lens_synthesis_not_yet_authored',title,record=syntheses.get(id,{}))
    for b in model['bridges']:edge('system:'+b['sourceSystem'],'system:'+b['targetSystem'],'authored_cross_system_relation',predicate=b['predicate'],evidence=b['evidence'],confidence=b['confidence'],scope=b.get('limits',''),record=b)
    target=dest/'quran-semantic-twin.graphml';ET.ElementTree(root).write(target,encoding='utf-8',xml_declaration=True)
    parsed=ET.parse(target);assert len(parsed.findall('.//{'+ns+'}node'))==len(nodeids);assert len(parsed.findall('.//{'+ns+'}edge'))==edgecount
    report={'result':'passed','builtAt':meta['builtAt'],'draft':args.draft,'sourceSha256':read['metadata']['sourceSha256'],'inputSha256':{p:sha(ROOT/p) for p in ['data/full-reading/reading.json','data/full-reading/network.json','data/full-reading/systems.json']},'counts':{'ayahs':6236,'units':len(read['units']),'literalLabels':len(net['nodes']),'localLabels':len(local),'relations':len(net['edges']),'graphNodes':len(nodeids),'graphEdges':edgecount},'outputs':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [dbtarget,target]],'verification':['SQLite integrity and foreign keys','all source ayahs byte-exact in text values','every relation quote in cited source','GraphML node/edge counts and no dangling edges'],'semanticAcceptance':'not_granted_by_export_checker'}
    (ROOT/'reports/semantic-export-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(j(report))
if __name__=='__main__':main()
