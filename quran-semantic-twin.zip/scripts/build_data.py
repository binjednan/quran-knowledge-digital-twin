#!/usr/bin/env python3
"""Build an auditable, text-only lexical network. No external corpus or lexicon."""
from __future__ import annotations

import collections
import datetime as dt
import hashlib
import html
import itertools
import json
import math
from pathlib import Path
import sqlite3
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "quran-uthmani-numbered-ayahs.json"
DATA = ROOT / "data"
EXPORT = ROOT / "exports"
EXPECTED_SOURCE_SHA256 = "25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589"

# An explicitly declared display/TF-IDF selection, never a claim about meaning.
DISPLAY_EXCLUSIONS = set("""من فى ما إن لا الذين على إلا ولا وما أن إلى لهم ومن ثم لكم كان بهۦ بما ذلك أو الذى هو هم وإن كل لهۥ فيها كانوا عن إذا عليهم هذا كنتم لم وهو فإن إذ والذين عليكم إنا فلا منهم بعد عليه إنهۥ يأيها حتى وهم وإذا أولئك إنى أم ولقد بل فيه قد عند قبل إنما ولكن ولو مما منكم فلما ألا لمن دون فمن منه فإذا فما منها كذلك وكان لنا بين للذين لو بها ألم إليك شيا إليه أنتم عنهم لما لك وإذ غير وأن هل أنا نحن التى إنهم لى كنا كيف بعض كما لعلكم لن مع بينهم فقد عليك به لها بها فيهما فيهۦ إليهم له لي بك بكم بكما بأيديهم إياك إياهم إياى إيانا ولهم ولكم وفيها وفيه وفي ومنهم وعليهم وعليه وأنتم وأنهۥ إنه وإنهۥ أولئك۠ ءأنت ءأنتم أفلا أولا أى أية هذاۤ هذه هذان هتين هؤلا هؤلاۤء أولاء ذات ذو ذى ذوا ذواتا كأن كأنما لولا هلا فهل فهلۡ لقد لقدۡ أيضا""".split())
NORMALIZATION = {
    "name": "whitespace-units-unicode-M-tatweel-wasla-v1",
    "operations": ["split on Unicode whitespace; positions are 1-based within all units", "remove codepoints whose Unicode general category begins with M", "remove U+0640 TATWEEL", "replace U+0671 ALEF WASLA with U+0627 ALEF only"],
    "notPerformed": ["no Unicode normalization such as NFKD", "no conversion of other alifs, hamza, ya, alif maqsura or ta marbuta", "no prefix or suffix splitting", "no stemming or root assignment", "no synonym merging"],
    "lexicalEligibility": "a normalized unit must contain at least one Unicode category L character; all units remain in SQLite",
    "warning_ar": "هذه مفاتيح بحث مطبعة لوحدات يفصلها البياض، وليست مفاهيم أو جذوراً أو هويات لفظية ثابتة. حذف علامات الضبط قد يجمع سطوحاً ذات معانٍ مختلفة؛ يجب العودة إلى السطح الأصلي والسياق، ولا يثبت اتحاد المفتاح اتحاد المعنى.",
}


def normalize(token: str) -> str:
    return "".join(c for c in token if not unicodedata.category(c).startswith("M") and c != "ـ").replace("ٱ", "ا")


def eligible(token: str) -> bool:
    return any(unicodedata.category(c).startswith("L") for c in token)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def pagerank(adj, tolerance=1e-10, max_iterations=150):
    n = len(adj)
    strengths = [sum(w for _, w in neighbors) for neighbors in adj]
    ranks = [1.0 / n] * n
    error = 1.0
    for iteration in range(1, max_iterations + 1):
        dangling = sum(ranks[i] for i in range(n) if strengths[i] == 0)
        base = (1.0 - .85) / n + .85 * dangling / n
        updated = [base] * n
        for i, neighbors in enumerate(adj):
            if strengths[i]:
                factor = .85 * ranks[i] / strengths[i]
                for j, weight in neighbors:
                    updated[j] += factor * weight
        error = sum(abs(a - b) for a, b in zip(updated, ranks))
        ranks = updated
        if error < tolerance:
            break
    return ranks, {"algorithm": "weighted PageRank on complete undirected lexical cooccurrence graph", "alpha": .85, "iterations": iteration, "l1Difference": error, "tolerance": tolerance, "converged": error < tolerance, "scope": "all eligible normalized units; no display exclusions"}


def main():
    DATA.mkdir(exist_ok=True)
    EXPORT.mkdir(exist_ok=True)
    source_hash = digest(SOURCE)
    if source_hash != EXPECTED_SOURCE_SHA256:
        raise ValueError("Source checksum differs from the user attachment; review before proceeding")
    original = json.loads(SOURCE.read_text(encoding="utf-8"))
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    notice = original["derivation"]["copyrightNotice"]
    provenance = {
        "sourceFile": SOURCE.name, "sourceSha256": source_hash,
        "sourceMetadata": original["metadata"], "derivation": original["derivation"],
        "copyrightNotice": notice, "licenseUrl": original["derivation"]["licenseUrl"],
        "externalSourcesConsulted": [],
        "evidenceScope_ar": "النص المرفق فقط. بيانات النشر وتصنيف مكان السورة ليست أدلة معرفية. أسماء السور وأرقامها مفاتيح تنقل فقط.",
        "sourceLimits_ar": "التحليل لا يتحقق من سلامة النص بمقارنته بمصحف خارجي. يعيد حفظ تنبيهات المصدر عن 95:1 و97:1، ولا يصححها ولا يحذفها.",
    }
    corpus = {"metadata": provenance, "surahs": [{"number": s["number"], "name": s["name"], "ayahs": [{"number": a["number"], "text": a["text"]} for a in s["ayahs"]]} for s in original["surahs"]]}
    dump(DATA / "corpus.json", corpus)
    counts = collections.Counter()
    forms = collections.defaultdict(collections.Counter)
    occurrences = collections.defaultdict(list)
    documents = collections.defaultdict(set)
    surah_sets = collections.defaultdict(set)
    ayah_rows = []
    all_units = []
    nonlexical_units = []
    surah_counts = collections.defaultdict(collections.Counter)
    surah_stats = []
    for s in original["surahs"]:
        total, letters = 0, 0
        for a in s["ayahs"]:
            aid = len(ayah_rows)
            tokens = a["text"].split()
            terms_here = set()
            ayah_rows.append({"id": aid, "surah": s["number"], "ayah": a["number"], "ref": f'{s["number"]}:{a["number"]}', "text": a["text"], "units": len(tokens)})
            for pos, surface in enumerate(tokens, 1):
                token = normalize(surface)
                is_lexical = eligible(token)
                all_units.append((aid, pos, surface, token, int(is_lexical)))
                total += 1
                if not is_lexical:
                    nonlexical_units.append({"ref": f'{s["number"]}:{a["number"]}', "position": pos, "surface": surface, "normalized": token})
                    continue
                letters += 1
                counts[token] += 1
                forms[token][surface] += 1
                occurrences[token].append([s["number"], a["number"], pos])
                documents[token].add(aid)
                surah_sets[token].add(s["number"])
                surah_counts[s["number"]][token] += 1
                terms_here.add(token)
            ayah_rows[-1]["terms"] = terms_here
        surah_stats.append({"number": s["number"], "name": s["name"], "ayahs": len(s["ayahs"]), "units": total, "lexicalTokens": letters, "types": len(surah_counts[s["number"]])})
    term_ids = sorted(counts)
    ids = {term: i for i, term in enumerate(term_ids)}
    pair_evidence = collections.defaultdict(list)
    for a in ayah_rows:
        for x, y in itertools.combinations(sorted(ids[t] for t in a["terms"]), 2):
            pair_evidence[x, y].append(a["id"])
    adjacency = [[] for _ in term_ids]
    for (x, y), evidence in pair_evidence.items():
        adjacency[x].append((y, len(evidence)))
        adjacency[y].append((x, len(evidence)))
    ranks, rank_meta = pagerank(adjacency)
    display_ids = sorted((t for t in term_ids if t not in DISPLAY_EXCLUSIONS), key=lambda t: (-counts[t], t))[:140]

    # Only the display graph uses NetworkX. It does not supply linguistic knowledge.
    import networkx as nx
    graph = nx.Graph()
    graph.add_nodes_from(display_ids)
    selected = set(display_ids)
    display_edges = []
    for (x, y), evidence in pair_evidence.items():
        tx, ty = term_ids[x], term_ids[y]
        if tx in selected and ty in selected:
            graph.add_edge(tx, ty, weight=len(evidence))
            display_edges.append({"source": tx, "target": ty, "weight": len(evidence), "evidence": [ayah_rows[a]["ref"] for a in evidence]})
    communities = sorted(nx.community.louvain_communities(graph, seed=1729, resolution=1, weight="weight"), key=lambda c: (-len(c), min(c)))
    community_id = {t: i for i, group in enumerate(communities) for t in group}
    positions = nx.spring_layout(graph, seed=1729, iterations=100, weight="weight", k=.32)
    min_x, max_x = min(float(p[0]) for p in positions.values()), max(float(p[0]) for p in positions.values())
    min_y, max_y = min(float(p[1]) for p in positions.values()), max(float(p[1]) for p in positions.values())
    terms = []
    for i, t in enumerate(term_ids):
        terms.append({"id": t, "count": counts[t], "df": len(documents[t]), "surahs": len(surah_sets[t]), "forms": [{"text": f, "count": c} for f, c in sorted(forms[t].items(), key=lambda p: (-p[1], p[0]))], "surfaceFormCount": len(forms[t]), "occurrences": occurrences[t], "degree": len(adjacency[i]), "strength": sum(w for _, w in adjacency[i]), "pagerank": ranks[i], "community": community_id.get(t)})
    stats = {"surahs": len(original["surahs"]), "ayahs": len(ayah_rows), "whitespaceUnits": len(all_units), "lexicalTokens": sum(counts.values()), "nonlexicalUnits": len(nonlexical_units), "types": len(term_ids), "distinctSurfaceForms": sum(len(f) for f in forms.values()), "multiSurfaceKeys": sum(len(f)>1 for f in forms.values()), "distinctPairs": len(pair_evidence), "pairAyahOccurrences": sum(len(e) for e in pair_evidence.values()), "displayNodes": len(display_ids), "displayEdges": len(display_edges), "displayCommunities": len(communities)}
    summary = {**stats, "pagerank": rank_meta, "centralityScope_ar": "الدرجة: عدد الجيران المختلفين؛ القوة: مجموع عدد آيات التلازم مع الجيران؛ PageRank موزون على جميع الصيغ من دون استبعاد. هذه مركزية تلازم لفظي، لا حكم بالأهمية الدلالية أو الأثر السببي."}
    dump(DATA / "lexicon.json", {"metadata": provenance, "normalization": NORMALIZATION, "terms": terms, "summary": summary})
    dump(DATA / "normalization-collisions.json", {"metadata": provenance, "warning_ar": "تعدد السطوح تحت مفتاح بحث واحد علامة تستدعي التفريق بالسياق والسطح الأصلي. قد يعكس اختلاف الضبط أو الإعراب أو اختلافاً دلالياً؛ ليس كل تعدد سطوح اختلاف معنى، ولا يثبت توحد المفتاح وحدة المعنى.", "keyCount": stats["multiSurfaceKeys"], "keys": [{"key": t["id"], "surfaceFormCount": t["surfaceFormCount"], "forms": t["forms"]} for t in terms if t["surfaceFormCount"]>1]})
    dump(DATA / "nonlexical-units.json", {"metadata": provenance, "normalization": NORMALIZATION, "units": nonlexical_units})
    term_lookup = {t["id"]: t for t in terms}
    nodes = []
    for t in display_ids:
        n = {k: term_lookup[t][k] for k in ("id", "count", "df", "surahs", "degree", "strength", "pagerank", "community")}
        n.update(label=t, x=round((float(positions[t][0]) - min_x) / (max_x-min_x), 6), y=round((float(positions[t][1]) - min_y) / (max_y-min_y), 6))
        nodes.append(n)

    # Cosine of exact normalized-unit TF-IDF. All 114*113/2 values are retained.
    vectors = {}
    for s in original["surahs"]:
        v = {}
        for t, count in surah_counts[s["number"]].items():
            if t not in DISPLAY_EXCLUSIONS:
                v[t] = (1 + math.log(count)) * (1 + math.log(115 / (1 + len(surah_sets[t]))))
        norm = math.sqrt(sum(w*w for w in v.values()))
        vectors[s["number"]] = {t: w / norm for t, w in v.items()} if norm else {}
    similarity = []
    matrix = [[1.0 if i==j else 0.0 for j in range(114)] for i in range(114)]
    for s1, s2 in itertools.combinations(range(1, 115), 2):
        v1, v2 = vectors[s1], vectors[s2]
        shared = sorted(set(v1) & set(v2), key=lambda t: (-(v1[t] * v2[t]), t))
        score = sum(v1[t] * v2[t] for t in shared)
        similarity.append({"source": s1, "target": s2, "value": round(score, 8), "shared": shared[:12], "sharedCount": len(shared)})
        matrix[s1-1][s2-1] = matrix[s2-1][s1-1] = round(score, 8)
    similarity.sort(key=lambda d: (-d["value"], d["source"], d["target"]))
    overview = {"metadata": provenance, "stats": stats, "network": {"nodes": nodes, "edges": sorted(display_edges, key=lambda e: (-e["weight"], e["source"], e["target"]))}, "surahs": surah_stats, "surahSimilarity": similarity, "surahSimilarityMatrix": matrix, "surahFrequency": {t: [surah_counts[s].get(t, 0) for s in range(1, 115)] for t in display_ids}, "analysis": {"normalization": NORMALIZATION, "cooccurrence": {"window": "one complete numbered ayah", "edgeWeight": "number of distinct ayahs containing both distinct units", "direction": "undirected", "selfLoops": False, "semanticMeaning_ar": "التلازم في آية واحدة مشاهدة آلية؛ لا يثبت ترادفاً أو سبباً أو إسناد فعل أو نفيه، ولا يمثّل كل علاقة معنوية."}, "display": {"selection": "140 most frequent eligible normalized units after the declared exclusions", "exclusions": sorted(DISPLAY_EXCLUSIONS), "exclusionPurpose_ar": "تقليل غلبة الأدوات والضمائر في العرض وفي تشابه السور؛ اختيار تحليلي معلن، لا إثبات دلالي. جميعها محفوظ في الفهرس والشبكة الكاملة.", "layout": {"algorithm": "NetworkX spring_layout", "seed": 1729, "iterations": 100, "coordinateRange": [0, 1]}, "community": {"algorithm": "Louvain", "seed": 1729, "resolution": 1, "scope": "140-node display graph", "meaning_ar": "مجموعات تلازم حسابية وليست موضوعات أو منظومات مثبتة."}}, "pagerank": rank_meta, "surahSimilarity": {"algorithm": "cosine similarity of L2-normalized log-TF / smoothed-IDF vectors", "tf": "1 + ln(token_count_in_surah)", "idf": "1 + ln(115 / (1 + number_of_surahs_containing_token))", "scope": "all 6441 distinct surah pairs; exact eligible normalized units minus declared display exclusions", "warning_ar": "تشابه لفظي موزون لا يثبت وحدة الموضوع ولا ترتيباً تاريخياً. أسماء السور لا تدخل الحساب."}}}
    dump(DATA / "overview.json", overview)
    dump(DATA / "analysis-config.json", {"metadata": provenance, "normalization": NORMALIZATION, "displayExclusions": sorted(DISPLAY_EXCLUSIONS), "analysis": overview["analysis"]})
    print(json.dumps(stats, ensure_ascii=False), flush=True)

    db_path = EXPORT / "quran-lexical-network.sqlite"
    if db_path.exists():
        db_path.unlink()
    db = sqlite3.connect(db_path)
    db.executescript("""
      PRAGMA journal_mode=OFF;
      CREATE TABLE metadata(key TEXT PRIMARY KEY,value_json TEXT NOT NULL);
      CREATE TABLE surahs(number INTEGER PRIMARY KEY,name TEXT NOT NULL);
      CREATE TABLE ayahs(id INTEGER PRIMARY KEY,surah INTEGER NOT NULL,number INTEGER NOT NULL,ref TEXT UNIQUE NOT NULL,text TEXT NOT NULL,UNIQUE(surah,number));
      CREATE TABLE terms(id INTEGER PRIMARY KEY,normalized TEXT UNIQUE NOT NULL,count INTEGER NOT NULL,df INTEGER NOT NULL,surah_count INTEGER NOT NULL,degree INTEGER NOT NULL,strength INTEGER NOT NULL,pagerank REAL NOT NULL,display_community INTEGER);
      CREATE TABLE units(ayah_id INTEGER NOT NULL,position INTEGER NOT NULL,surface TEXT NOT NULL,normalized TEXT NOT NULL,is_lexical INTEGER NOT NULL,term_id INTEGER,PRIMARY KEY(ayah_id,position));
      CREATE TABLE edges(id INTEGER PRIMARY KEY,source INTEGER NOT NULL,target INTEGER NOT NULL,weight INTEGER NOT NULL,UNIQUE(source,target),CHECK(source<target));
      CREATE TABLE edge_evidence(edge_id INTEGER NOT NULL,ayah_id INTEGER NOT NULL,PRIMARY KEY(edge_id,ayah_id));
    """)
    db.executemany("INSERT INTO metadata VALUES (?,?)", [("provenance", json.dumps(provenance, ensure_ascii=False)), ("normalization", json.dumps(NORMALIZATION, ensure_ascii=False)), ("analysis", json.dumps(overview["analysis"], ensure_ascii=False)), ("stats", json.dumps(stats, ensure_ascii=False))])
    db.executemany("INSERT INTO surahs VALUES (?,?)", [(s["number"], s["name"]) for s in original["surahs"]])
    db.executemany("INSERT INTO ayahs VALUES (?,?,?,?,?)", [(a["id"], a["surah"], a["ayah"], a["ref"], a["text"]) for a in ayah_rows])
    db.executemany("INSERT INTO terms VALUES (?,?,?,?,?,?,?,?,?)", [(i, t["id"], t["count"], t["df"], t["surahs"], t["degree"], t["strength"], t["pagerank"], t["community"]) for i, t in enumerate(terms)])
    db.executemany("INSERT INTO units VALUES (?,?,?,?,?,?)", [(aid, pos, surface, normalized, is_lexical, ids.get(normalized) if is_lexical else None) for aid, pos, surface, normalized, is_lexical in all_units])
    pairs_sorted = sorted(pair_evidence)
    db.executemany("INSERT INTO edges VALUES (?,?,?,?)", [(eid, x, y, len(pair_evidence[x, y])) for eid, (x, y) in enumerate(pairs_sorted)])
    db.executemany("INSERT INTO edge_evidence VALUES (?,?)", ((eid, aid) for eid, pair in enumerate(pairs_sorted) for aid in pair_evidence[pair]))
    db.executescript("CREATE INDEX units_term ON units(term_id); CREATE INDEX ayahs_surah ON ayahs(surah); CREATE INDEX edges_target ON edges(target); CREATE INDEX evidence_ayah ON edge_evidence(ayah_id);")
    db.commit()
    db.execute("VACUUM")
    db.close()

    with (EXPORT / "quran-lexical-network.graphml").open("w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n<graphml xmlns="http://graphml.graphdrawing.org/xmlns">\n')
        for name, scope, typ in [("provenance", "graph", "string"), ("label", "node", "string"), ("count", "node", "int"), ("degree", "node", "int"), ("strength", "node", "int"), ("pagerank", "node", "double"), ("weight", "edge", "int"), ("evidence", "edge", "string")]:
            f.write(f'<key id="{name}" for="{scope}" attr.name="{name}" attr.type="{typ}"/>\n')
        f.write('<graph id="lexical-cooccurrence" edgedefault="undirected">\n<data key="provenance">' + html.escape(json.dumps(provenance, ensure_ascii=False)) + '</data>\n')
        for i, t in enumerate(terms):
            f.write(f'<node id="n{i}"><data key="label">{html.escape(t["id"])}</data><data key="count">{t["count"]}</data><data key="degree">{t["degree"]}</data><data key="strength">{t["strength"]}</data><data key="pagerank">{t["pagerank"]:.14g}</data></node>\n')
        for eid, (x, y) in enumerate(pairs_sorted):
            refs = ",".join(ayah_rows[a]["ref"] for a in pair_evidence[x, y])
            f.write(f'<edge id="e{eid}" source="n{x}" target="n{y}"><data key="weight">{len(pair_evidence[x,y])}</data><data key="evidence">{refs}</data></edge>\n')
        f.write('</graph>\n</graphml>\n')
    (EXPORT / "queries.sql").write_text("""-- Evidence-only queries. Source notice and method: SELECT * FROM metadata;
-- Every occurrence of an exact normalized unit, original surface and verse:
SELECT a.ref,u.position,u.surface,a.text FROM units u JOIN ayahs a ON a.id=u.ayah_id JOIN terms t ON t.id=u.term_id WHERE t.normalized='الله' ORDER BY a.id,u.position;
-- Neighbors of an exact normalized unit (undirected graph):
SELECT neighbor.normalized,e.weight FROM terms t JOIN edges e ON t.id=e.source OR t.id=e.target JOIN terms neighbor ON neighbor.id=CASE WHEN e.source=t.id THEN e.target ELSE e.source END WHERE t.normalized='الله' ORDER BY e.weight DESC;
-- Full textual evidence for a selected pair:
SELECT a.ref,a.text FROM edges e JOIN terms x ON x.id=e.source JOIN terms y ON y.id=e.target JOIN edge_evidence ev ON ev.edge_id=e.id JOIN ayahs a ON a.id=ev.ayah_id WHERE (x.normalized='الله' AND y.normalized='الأرض') OR (x.normalized='الأرض' AND y.normalized='الله') ORDER BY a.id;
""", encoding="utf-8")
    files = []
    owned_data_names = ["corpus.json", "lexicon.json", "nonlexical-units.json", "normalization-collisions.json", "overview.json", "analysis-config.json"]
    for p in sorted([DATA / name for name in owned_data_names] + list(EXPORT.glob("*"))):
        if not p.is_file():
            continue
        files.append({"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": digest(p)})
    manifest = {"schema": 1, "builtAt": now, "sourceFile": SOURCE.name, "sourceSha256": source_hash, "stats": stats, "files": files, "method": "scripts/build_data.py", "methodSha256": digest(Path(__file__)), "verification": "scripts/verify_data.py", "sourcePreserved": digest(SOURCE) == source_hash, "sourceVerificationScope": "byte checksum preservation against supplied attachment only; no external canonical comparison", "externalSourcesConsulted": [], "knownLimits": original["derivation"]["validationWarnings"]}
    dump(DATA / "manifest.json", manifest)
    print("Build complete; original source unchanged; " + str(len(files)) + " derivative files", flush=True)


if __name__ == "__main__":
    main()
