#!/usr/bin/env python3
"""Audit coverage and provenance of authored reading records, never their entailment."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,datetime,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'quran-uthmani-numbered-ayahs.json'
EXPECTED_SOURCE='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'
PARTS={'a':(1,12),'b':(13,37),'c':(38,114)}

def read_records(path):
    records=[]
    for number,line in enumerate(path.read_text().splitlines(),1):
        if line.strip():
            try:records.append(json.loads(line))
            except json.JSONDecodeError as error:raise ValueError(f'{path.name}:{number}: {error}')
    return records

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--require-complete',action='store_true');args=parser.parse_args()
    raw=json.loads(SOURCE.read_text());source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    ayahs={f"{s['number']}:{a['number']}":a['text'] for s in raw['surahs'] for a in s['ayahs']}
    concepts={c['id']:c for d in json.loads((ROOT/'analysis/combined.json').read_text())['domains'] for c in d['concepts']}
    lens_ids={d['id'] for d in json.loads((ROOT/'analysis/combined.json').read_text())['domains']}
    expected_pairs={(cid,ref) for cid,c in concepts.items() for ref in c['occurrences']}
    errors=[];warnings=[];records=[];files={};ranges=defaultdict(list);semantic_refs=set();actual_pairs=set();authored_pairs=set();pending_pairs=set();relations=[];counts=Counter();questions=[]
    if source_hash!=EXPECTED_SOURCE:errors.append({'code':'SOURCE_CHANGED'})
    def error(code,unit,detail):errors.append({'code':code,'unit':unit,'detail':detail})
    def refs_of(value):
        if not isinstance(value,dict):return []
        refs=value.get('evidence',[])
        if isinstance(refs,str):return [refs]
        return refs if isinstance(refs,list) else []
    for part,(low,high) in PARTS.items():
        path=ROOT/f'analysis/full-reading/part-{part}.jsonl'
        if not path.exists():continue
        files[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        try:items=read_records(path)
        except ValueError as exc:errors.append({'code':'INVALID_JSONL','detail':str(exc)});continue
        for unit in items:
            uid=unit.get('id','');sn=unit.get('surah');start=unit.get('start');end=unit.get('end')
            if not isinstance(sn,int) or not low<=sn<=high:error('PART_RANGE',uid,part);continue
            if not isinstance(start,int) or not isinstance(end,int) or start>end:error('INVALID_INTERVAL',uid,[start,end]);continue
            expected_unit_refs={f'{sn}:{a}' for a in range(start,end+1)}
            if not expected_unit_refs.issubset(ayahs):error('UNKNOWN_AYAH_INTERVAL',uid,sorted(expected_unit_refs-set(ayahs)));continue
            for field in ['id','kind','summary']:
                if not isinstance(unit.get(field),str) or not unit[field].strip():error('MISSING_TEXT',uid,field)
            ranges[sn].append((start,end,uid));records.append(unit)
            observed=set()
            for field in ['concepts','relations','contrasts','openQuestions','observations']:
                if not isinstance(unit.get(field,[]),list):error('INVALID_RECORD_LIST',uid,field);continue
                for item in unit.get(field,[]):
                    refs=refs_of(item)
                    for ref in refs:
                        if ref not in ayahs:error('MISSING_REFERENCE',uid,ref)
                        elif ref in expected_unit_refs:observed.add(ref)
                    if field=='relations':
                        counts['relations']+=1;relations.append(item)
                        for required in ['source','predicate','target','polarity','scope','confidence','quote']:
                            if not isinstance(item.get(required),str) or not item[required].strip():error('MISSING_RELATION_FIELD',uid,required)
                        quote=item.get('quote','')
                        if not quote or not any(quote in ayahs.get(ref,'') for ref in refs):error('QUOTE_NOT_VERBATIM',uid,{'quote':quote,'evidence':refs})
                        if not set(refs)&expected_unit_refs:error('RELATION_WITHOUT_LOCAL_EVIDENCE',uid,refs)
                        counts['polarity:'+str(item.get('polarity'))]+=1
                    elif field=='openQuestions':
                        questions.append({'unit':uid,**item})
                    elif field=='observations':
                        if not isinstance(item.get('statement'),str) or not item['statement'].strip():error('EMPTY_OBSERVATION',uid,item)
                        counts['observations']+=1
            missing=expected_unit_refs-observed
            if missing:error('VERSE_WITHOUT_SEMANTIC_RECORD',uid,sorted(missing,key=lambda r:tuple(map(int,r.split(':')))))
            semantic_refs.update(observed)
            lenses=unit.get('lenses',[])
            if not lenses:error('MISSING_LENS_ANNOTATION',uid,'lenses')
            for lens in lenses:
                if not isinstance(lens,dict) or lens.get('id') not in lens_ids:
                    error('INVALID_LENS',uid,lens);continue
                lr=refs_of(lens)
                if not isinstance(lens.get('basis'),str) or not lens['basis'].strip():error('MISSING_LENS_BASIS',uid,lens['id'])
                if not lr or any(r not in ayahs for r in lr) or not set(lr)&expected_unit_refs:error('INVALID_LENS_EVIDENCE',uid,lens)
                counts['lensAnnotations']+=1
            for usage in unit.get('seedUsages',[]):
                cid=usage.get('conceptId')
                if cid not in concepts:error('UNKNOWN_CONCEPT',uid,cid);continue
                for field in ['usage','confidence','limits']:
                    if not isinstance(usage.get(field),str) or not usage[field].strip():error('MISSING_USAGE_FIELD',uid,{'concept':cid,'field':field})
                # A negative account of a verb (e.g. alif/ta'lif in8:63) is
                # not an authorship status. Only legacy gap-specific markers
                # supplement a missing explicit status; semantic acceptance
                # remains a separate current-content independent review.
                pending=usage.get('authoringStatus')=='proposal_pending_reader_review' or (not usage.get('authoringStatus') and any(text in usage.get('usage','')+' '+usage.get('limits','') for text in ['لم يفرد لهذه المطابقة','على مستوى تعريف البوابة','غياب علاقة مؤلفة']))
                for ref in usage.get('refs',[]):
                    if ref not in expected_unit_refs:error('USAGE_OUTSIDE_UNIT',uid,{'concept':cid,'ref':ref})
                    if (cid,ref) not in expected_pairs:error('USAGE_WITHOUT_RAW_MATCH',uid,{'concept':cid,'ref':ref})
                    actual_pairs.add((cid,ref))
                    if pending:
                        pending_pairs.add((cid,ref));error('PENDING_USAGE_AUTHORSHIP',uid,{'concept':cid,'ref':ref})
                    else:authored_pairs.add((cid,ref))
                counts['usageGroups']+=1
                if any(x in usage.get('usage','') for x in ['غير محسوم','غيرمحسوم','تصادم']):counts['explicitUnresolvedUsageGroups']+=1
    ids=Counter(u['id'] for u in records)
    for uid,n in ids.items():
        if n>1:error('DUPLICATE_UNIT_ID',uid,n)
    covered=set()
    for sn,intervals in ranges.items():
        for start,end,uid in sorted(intervals):
            refs={f'{sn}:{a}' for a in range(start,end+1)}
            if refs&covered:error('OVERLAPPING_UNITS',uid,sorted(refs&covered))
            covered.update(refs)
    missing_refs=set(ayahs)-covered
    reviewed_expected={pair for pair in expected_pairs if pair[1] in covered}
    missing_within_written=reviewed_expected-actual_pairs
    for cid,ref in sorted(missing_within_written):error('UNCLASSIFIED_CANDIDATE_IN_WRITTEN_UNIT',cid,ref)
    if args.require_complete and missing_refs:errors.append({'code':'CORPUS_COVERAGE_INCOMPLETE','count':len(missing_refs)})
    if args.require_complete and expected_pairs-actual_pairs:errors.append({'code':'CANDIDATE_COVERAGE_INCOMPLETE','count':len(expected_pairs-actual_pairs)})
    all_complete=not missing_refs and not (expected_pairs-actual_pairs) and not errors
    report={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':source_hash,'inputSha256':files,
        'status':'structurally_complete' if all_complete else 'in_progress' if not errors else 'needs_correction',
        'scope':'Coverage, references, verbatim quotation, interval integrity and declared candidate usage; not semantic entailment or epistemic finality.',
        'semanticAcceptance':'not_granted_by_structure_checker',
        'counts':{'sourceAyahs':len(ayahs),'writtenUnits':len(records),'ayahsInWrittenRanges':len(covered),'ayahsWithSemanticEvidence':len(semantic_refs),'unwrittenAyahs':len(missing_refs),'expectedCandidatePairs':len(expected_pairs),'classifiedCandidatePairs':len(actual_pairs&expected_pairs),'pairsWithAuthoredLocalUsage':len(authored_pairs&expected_pairs),'pendingAuthorshipPairs':len(pending_pairs),'unclassifiedCandidatePairs':len(expected_pairs-actual_pairs),'openQuestions':len(questions),**counts},
        'partCoverage':{p:sum(1 for ref in covered if lo<=int(ref.split(':')[0])<=hi) for p,(lo,hi) in PARTS.items()},
        'errors':errors,'warnings':warnings,'unwrittenReferences':sorted(missing_refs,key=lambda r:tuple(map(int,r.split(':')))),
        'perConcept':[{'id':cid,'label':c['label'],'expectedPairs':len(c['occurrences']),'classifiedPairs':sum((cid,r) in actual_pairs for r in c['occurrences']),'missingRefs':[r for r in c['occurrences'] if (cid,r) not in actual_pairs]} for cid,c in concepts.items()]}
    dest=ROOT/'reports/full-reading-verification.json';dest.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({k:report[k] for k in ['status','counts','partCoverage']},ensure_ascii=False))
    if errors or (args.require_complete and not all_complete):raise SystemExit(1)
if __name__=='__main__':main()
