/* Source-scoped semantic edition, isolated offline Chrome profile. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const playwrightModule=process.env.PLAYWRIGHT_MODULE_PATH||path.join(require('node:os').homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','node','node_modules','playwright');
const {chromium}=require(playwrightModule);
const ROOT=path.resolve(__dirname,'..'),artifact=path.join(ROOT,'التوأم-المعرفي-للقرآن-الدلالي.html'),out=path.join(ROOT,'reports');
const checks=[],errors=[],requests=[];let context;
function check(name,value,detail){checks.push({name,passed:!!value,detail});assert.ok(value,name+': '+(detail||''));}
(async()=>{
 context=await chromium.launchPersistentContext(path.join(ROOT,'.work','semantic-ui-profile'),{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,viewport:{width:1440,height:1050},locale:'ar-AE',colorScheme:'light',acceptDownloads:true,downloadsPath:path.join(ROOT,'.work','semantic-downloads')});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
 await page.goto(pathToFileURL(artifact).href);await page.waitForFunction(()=>window.QuranTwin?.fullReading);
 check('source_ayahs',await page.evaluate(()=>QuranTwin.ayahMap.size===6236));
 check('all_verses_link_to_authored_unit',await page.evaluate(()=>[...QuranTwin.ayahMap.keys()].every(r=>QuranTwin.fullReading.unitMap.has(QuranTwin.fullReading.FR.verseToUnit[r]))));
 check('relation_scope_and_quote_preserved',await page.evaluate(()=>QuranTwin.fullReading.SN.edges.every(e=>e.scope&&e.polarity&&e.evidence.some(r=>QuranTwin.ayahMap.get(r).text.includes(e.quote)))));
 check('pending_authorship_visible',await page.evaluate(()=>!QuranTwin.fullReading.FR.coverage.pendingAuthorshipPairs||!!document.querySelector('[data-pending-authorship]')));
 check('final_edition_has_all_reviews',await page.evaluate(()=>{const{FR,SM}=QuranTwin.fullReading;return FR.metadata.draft||(FR.coverage.pendingAuthorshipPairs===0&&Object.keys(FR.authoredStudies).length===88&&SM.systems.length===16&&SM.systems.every(s=>s.reviewStatus==='independently_reviewed_as_scoped')&&FR.units.every(u=>FR.independentReviews[u.id]?.status==='accepted_as_scoped'));}));
 await page.screenshot({path:path.join(out,'semantic-desktop-home.png'),fullPage:true});
 for(const view of ['reading','studies','semantic','model','word','network','surahs','journal','method','systems','relations','claims']){
  await page.evaluate(v=>QuranTwin.navigate(v),view);check('route_'+view,(await page.locator('#view').innerText()).length>100);
 }
 await page.evaluate(()=>QuranTwin.navigate('reading'));await page.fill('#readingRef','٤٩:٦');await page.locator('#readingGo button').click();
 check('arabic_verse_navigation',await page.evaluate(()=>QuranTwin.fullReading.unitMap.get(QuranTwin.state.readingUnit).surah===49));
 await page.locator('.ayah-card [data-ref="49:6"]').first().click();check('evidence_context_and_authored_link',await page.locator('#evidenceDialog [data-reading]').count()>0);await page.click('#closeEvidence');
 const studyIds=await page.evaluate(()=>[...QuranTwin.fullReading.studyMap.keys()]);
 for(const id of studyIds){await page.evaluate(id=>{QuranTwin.state.study=id;QuranTwin.state.studyPage=0;QuranTwin.navigate('studies');},id);const text=await page.locator('#view').innerText();check('study_readable_'+id,!/\[object Object\]|undefined|NaN/.test(text),text.match(/\[object Object\]|undefined|NaN/)?.[0]);}
 await page.selectOption('#studySelect','a-qayyum');await page.locator('#view details').evaluateAll(ds=>ds.forEach(d=>{d.open=true;}));
 const qayyumScope=await page.evaluate(()=>QuranTwin.fullReading.studyMap.get('a-qayyum').patterns.find(p=>p.scope).scope);
 check('study_pattern_scope_is_visible',(await page.locator('#view').innerText()).includes(qayyumScope),qayyumScope);
 await page.selectOption('#studySelect','b-justice');
 const originalForm=await page.evaluate(()=>{const g=QuranTwin.fullReading.studyMap.get('b-justice').usageComparison[0];return {ref:g.ref,form:g.form,key:g.key};});
 check('study_original_form_and_search_key_are_visible',await page.locator('#view bdi').evaluateAll((bs,w)=>bs.some(b=>b.innerText===w.form)&&bs.some(b=>b.innerText===w.key),originalForm),JSON.stringify(originalForm));
 await page.selectOption('#studySelect','b-consult');
 const consultMatter=await page.evaluate(()=>QuranTwin.fullReading.studyMap.get('b-consult').usageComparison.find(g=>g.ref==='2:233').matter);
 check('consultation_matter_is_visible',(await page.locator('#view').innerText()).includes(consultMatter),consultMatter);
 await page.selectOption('#studySelect','a-hawa');await page.click('#allStudyRefs');check('expanded_hawa_scope_36_ayahs',(await page.locator('#evidenceBody').innerText()).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).includes('36 آية'));await page.click('#closeEvidence');
 await page.selectOption('#studySelect','b-balance');check('reused_study_is_explorable',await page.locator('#studyNext').count()===1&&(await page.locator('#view').innerText()).includes('الميزان'));
 await page.selectOption('#studySelect','a-afw');await page.click('#studyNetwork');check('study_opens_its_evidence_network',await page.evaluate(()=>QuranTwin.state.page==='semantic'&&QuranTwin.state.semanticStudy==='a-afw'&&QuranTwin.fullReading.semanticEdges().length>0));
 check('study_network_preserves_scope',await page.evaluate(()=>{const s=QuranTwin.fullReading.studyMap.get('a-afw'),refs=new Set(s.searchScope.allReferences);return QuranTwin.fullReading.semanticEdges().every(e=>e.evidence.some(r=>refs.has(r)));}));
 await page.selectOption('#semanticStudy','');
 const hopCheck=await page.evaluate(()=>{const{SN,semanticEdges}=QuranTwin.fullReading;const st=QuranTwin.state;st.semanticLens='';st.semanticStudy='';st.semanticPolarity='';st.semanticHops=2;
  for(const n of SN.nodes){const direct=SN.edges.filter(e=>e.source===n.id||e.target===n.id),neighbors=new Set(direct.flatMap(e=>[e.source,e.target]));const global=SN.edges.filter(e=>neighbors.has(e.source)||neighbors.has(e.target));st.semanticNode=n.id;const local=semanticEdges(),kept=new Set(local.map(e=>e.id)),excluded=global.filter(e=>!kept.has(e.id));if(excluded.length&&local.length>direct.length){st.semanticNode='';st.semanticHops=1;return {passed:local.length>direct.length&&local.length<global.length,witness:n.label,local:local.length,global:global.length,excludedUnit:excluded[0].unit};}}st.semanticNode='';st.semanticHops=1;return {passed:false};});
 check('two_hops_keep_each_textual_unit_separate',hopCheck.passed,JSON.stringify(hopCheck));
 await page.evaluate(()=>QuranTwin.navigate('semantic'));check('default_graph_keeps_local_scopes',(await page.locator('.semantic-chart g[data-semantic-node]').first().getAttribute('aria-label')).includes(' · '));
 await page.selectOption('#semanticView','labels');check('literal_index_layer_available',await page.locator('.semantic-chart g[data-semantic-node]').count()>0);await page.selectOption('#semanticView','local');
 await page.evaluate(()=>QuranTwin.navigate('semantic'));await page.selectOption('#semanticPolarity','نقل قول');check('quoted_voice_filter',await page.evaluate(()=>QuranTwin.fullReading.semanticEdges().every(e=>e.polarity==='نقل قول')));
 await page.locator('[data-semantic-edge]').first().focus();await page.keyboard.press('Enter');check('keyboard_edge_opens_scoped_evidence',await page.locator('#evidenceDialog').evaluate(d=>d.open));await page.click('#closeEvidence');
 await page.screenshot({path:path.join(out,'semantic-desktop-network.png'),fullPage:true});
 const systemIds=await page.evaluate(()=>Object.keys(QuranTwin.fullReading.SM.systemTitles));
 for(const id of systemIds){await page.evaluate(id=>{QuranTwin.state.modelSystem=id;QuranTwin.state.modelTab='summary';QuranTwin.navigate('model');},id);const t=await page.locator('#view').innerText();check('system_readable_'+id,!/\[object Object\]|undefined|NaN/.test(t),t.match(/\[object Object\]|undefined|NaN/)?.[0]);}
 await page.evaluate(()=>{QuranTwin.state.modelSystem='relations';QuranTwin.navigate('model');});await page.selectOption('#modelTab','flow');await page.locator('[data-flow-polarity]').first().click();check('flow_navigates_to_exact_record_scope',await page.evaluate(()=>QuranTwin.state.page==='semantic'&&QuranTwin.state.semanticLens==='relations'&&!!QuranTwin.state.semanticPolarity));
 await page.evaluate(()=>QuranTwin.navigate('model'));await page.selectOption('#modelTab','matrix');await page.locator('[data-matrix-lenses="knowledge:knowledge"]').click();check('matrix_cells_show_readings',await page.locator('#evidenceDialog [data-reading]').count()>0);await page.click('#closeEvidence');
 const downloaded=page.waitForEvent('download');await page.click('#exportModel');const file=await(await downloaded).path();check('portable_export_valid_json',JSON.parse(fs.readFileSync(file,'utf8')).systems.length>=1);
 const layout=[];
 for(const width of [390,320]){await page.setViewportSize({width,height:844});for(const view of ['home','reading','studies','semantic','model','method']){await page.evaluate(v=>QuranTwin.navigate(v),view);const box=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth}));layout.push({width,view,...box});check('responsive_'+width+'_'+view,box.scroll<=box.client+1,JSON.stringify(box));if(width===390&&['home','reading','studies','model'].includes(view))await page.screenshot({path:path.join(out,'semantic-mobile-'+view+'.png'),fullPage:true});}}
 await page.setViewportSize({width:1440,height:1050});await page.emulateMedia({colorScheme:'dark'});await page.evaluate(()=>{QuranTwin.state.modelSystem='relations';QuranTwin.state.modelTab='summary';QuranTwin.navigate('model');});await page.screenshot({path:path.join(out,'semantic-desktop-model-dark.png'),fullPage:true});
 check('no_javascript_errors',errors.length===0,errors.join('\n'));check('no_external_requests',requests.length===0,requests.join('\n'));
 const report={status:'passed',testedAt:new Date().toISOString(),artifactSha256:crypto.createHash('sha256').update(fs.readFileSync(artifact)).digest('hex'),browser:'isolated headless Chrome; desktop 1440 and responsive 390/320 CSS px; no physical iPhone or Safari acceptance',checks,layout,errors,networkRequests:requests};
 fs.writeFileSync(path.join(out,'semantic-ui-verification.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({status:report.status,checks:checks.length,errors,requests}));
})().catch(e=>{fs.writeFileSync(path.join(out,'semantic-ui-verification.json'),JSON.stringify({status:'failed',checks,errors,exception:String(e)},null,2));console.error(e);process.exitCode=1;}).finally(async()=>{if(context)await context.close();});
