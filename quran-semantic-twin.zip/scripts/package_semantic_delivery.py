#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Package only final, current, reviewed files; preserve all earlier deliveries."""
from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def current_inputs(report):
    for name,digest in report.get('inputSha256',{}).items():assert sha(ROOT/name)==digest,'Stale evidence: '+name
def selected_files(base,extensions):
    selected=[]
    for p in base.rglob('*'):
        assert not p.is_symlink(),'Symbolic link outside curated delivery: '+str(p.relative_to(ROOT))
        relative=p.relative_to(base)
        if any(x.startswith('.') or x=='__pycache__' for x in relative.parts):continue
        if not p.is_file():continue
        assert p.suffix in extensions,'Unexpected delivery file type: '+str(p.relative_to(ROOT))
        assert not any(x.casefold() in {'cookies','credentials','keychain','browser-profile','preview-profile','semantic-ui-profile'} for x in relative.parts),'Private runtime file'
        selected.append(p)
    return selected
def main():
    subprocess.run(['python3',str(ROOT/'scripts/verify_independent_reviews.py'),'--require-complete'],check=True)
    source=ROOT/'quran-uthmani-numbered-ayahs.json';artifact=ROOT/'التوأم-المعرفي-للقرآن-الدلالي.html'
    assert sha(source)=='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'
    read=load('data/full-reading/reading.json');network=load('data/full-reading/network.json');model=load('data/full-reading/systems.json')
    assert not read['metadata']['draft'] and not network['metadata']['draft'] and not model['metadata']['draft']
    assert read['metadata']==network['metadata'],'Reading/network snapshots differ'
    current_inputs(read['metadata']);current_inputs(network['metadata']);current_inputs(model['metadata'])
    build=load('reports/semantic-artifact-build.json');assert not build['draft'];current_inputs(build)
    assert sha(artifact)==build['sha256']
    ui=load('reports/semantic-ui-verification.json');assert ui['status']=='passed' and ui['artifactSha256']==sha(artifact)
    export=load('reports/semantic-export-verification.json');assert export['result']=='passed' and not export['draft'];current_inputs(export)
    for item in export['outputs']:assert sha(ROOT/item['path'])==item['sha256']
    counts=load('reports/independent-review-verification.json')['counts']
    studies=load('reports/concept-study-verification.json');current_inputs(studies)
    assert studies['authoredStudies']==88 and all(c['passed'] for c in studies['checks'])
    assert all(c['passed'] for result in studies['results'] for c in result['checks'])
    body=f'''# التوأم المعرفي الرقمي للقرآن الكريم — الإصدار الدلالي

المصدر الوحيد هو ملف المستخدم، محفوظ دون تغيير. بُنيت قراءة مكتوبة لجميع آياته، ومقارنات لبوابات البحث وتوليفات للمنظومات المطلوبة. هذا نموذج بحثي محدد النطاق، لا دعوى باستنفاد كل معنى أو كل علاقة ممكنة.

## ما أنجز في هذا الإصدار

- النص: 114 سورة و6236 آية مرقمة وفق المرفق.
- القراءة: {len(read['units'])} مقطعاً، وكل مقطع له سجل مراجعة مستقلة مطابق لبصمة محتواه.
- الدراسات: {len(read['authoredStudies'])} بوابة مقارنة موسعة الصور، مع فصل التصادمات والمعنى المركزي والفروع والأسئلة.
- المنظومات: {len(model['systems'])} توليفاً عبر عدسات طلبها المستخدم، مع جسور نصية معللة.
- الشبكة: {len(network['edges'])} سجل علاقة و{len(network['nodes'])} تسمية حرفية مفهرسة. هذه أعداد سجلات القراءة، وليست ادعاء بعدّ جميع علاقات النص.
- المراجعة الحالية: {counts['acceptedCurrentUnitReviews']} مقطعاً و{counts['studiesAcceptedCurrent']} دراسة و{counts['systemsAcceptedCurrent']} توليفاً مقبولة ضمن نطاقها البحثي. اعتماد المستخدم حالة مستقلة ولم يُفترض.

## الاستخدام

افتح `التوأم-المعرفي-للقرآن-الدلالي.html` في متصفح حديث؛ يعمل مستقلاً دون اتصال أو خادم. انتقل بين قراءة المقطع والدراسة والشبكة والمنظومة، واضغط مراجع الآيات لعرض النص والسياق. تعرض الشبكة الإثبات والنفي والقول والشرط والسؤال والتشبيه، وتتيح الجوار المباشر وذا الصلتين دون استنتاج سببية جديدة.

في المنظومات تتاح شجرة المكونات والجسور ومصفوفة اشتراك تعليقات العدسات وتدفق سجلات الإسناد بحسب نوعها. المصفوفة لا تقيس تأثيراً سببياً أو قيمة معنوية. ترتيب المقاطع ترتيب النص، لا خط زمني تاريخي مستورد.

## الحدود الظاهرة

تُفصل البيانات الخام والملاحظات والأنماط والاستنتاجات والفرضيات والنتائج المقيدة. درجات اليقين وصفية معللة وليست نسباً احتمالية. مفاتيح البحث ليست جذوراً أو تعريفات؛ حذف العلامات قد يجمع صيغاً مختلفة، فحفظت الأسطح والمواضع. وتسميات العقد المتطابقة مفاتيح فهرسة، لا دليل هوية معانيها أو ذواتها.

الأسئلة التي لا تحسمها القرائن محفوظة مع أسبابها. لا تملأ الأسماء القليلة القرائن أو الضمائر أو تواريخ الأحداث بمعارف خارج النص. بيانات الناشر والمكان والتاريخ في المرفق محفوظة للإسناد ولا تدخل الاستدلال. يبقى تنبيه المرفق عن افتتاح95:1 و97:1 ظاهراً دون تعديل النص.

## المواد القابلة للمراجعة

- `analysis/full-reading/`: المقاطع والدراسات والتوليفات وسجلات المراجعة، بما فيها الاعتراضات المعالجة.
- `data/full-reading/`: فهارس القراءة والشبكة والمنظومات والجسور.
- `exports/quran-semantic-twin.sqlite`: النص والقراءات والعلاقات والشواهد في جداول مترابطة؛ نطاق كل تسمية محلية محفوظ.
- `exports/quran-semantic-twin.graphml`: تسميات محلية ومجموعات فهرسة وعضوية مصدر وعلاقات دلالية مميزة النوع. وصلة العضوية ليست علاقة سببية.
- `reports/`: فحوص الحفظ والحصر والمراجعة والواجهة والتصدير وبصمات الملفات.

## إعادة البناء

بعد تعديل قراءة أو دراسة يلزم تجديد مراجعتها؛ البصمة تمنع اعتماد مراجعة محتوى قديم. تعمل أدوات البناء محلياً ولا تطلب مصدراً خارجياً:

```sh
python3 scripts/verify_full_reading.py --require-complete
python3 scripts/verify_concept_studies.py
python3 scripts/bind_independent_reviews.py
python3 scripts/verify_independent_reviews.py --require-complete
python3 scripts/build_full_reading.py
python3 scripts/build_system_model.py
python3 scripts/export_semantic.py
python3 scripts/build_semantic_report.py
```

فحص الواجهة موثق داخل متصفح Chrome معزول بأحجام1440 و390 و320 بكسل؛ لا يمثل اختبار Safari أو آيفون فعلي أو اعتماد المستخدم. إعادة بناء الواجهة تستلزم إعادة فحص الملف الناتج قبل التغليف.

بصمة المصدر SHA-256:

`{sha(source)}`

حقوق النص وإسناده كما وردا في المرفق محفوظان داخل HTML والبيانات والتصدير؛ لا تُنسب قراءة النموذج إلى جهة نشر النص. الملفات السابقة محفوظة مستقلة في المشروع وسجل GitHub. تتضمن سجلات الطريقة والمراجعة حالات تاريخية محفوظة؛ الحالة الحالية تثبتها تقارير التحقق وبصمات هذا الإصدار.
'''
    readme=ROOT/'README-SEMANTIC-AR.md';readme.write_text(body)
    paths=[artifact,readme,source,ROOT/'analysis/combined.json',ROOT/'analysis/domains-a.json',ROOT/'analysis/domains-b.json']
    for name,extensions in {'ui':{'.js','.css','.html'},'scripts':{'.py','.cjs'},'data':{'.json','.md'}}.items():
        paths.extend(selected_files(ROOT/name,extensions))
    base=ROOT/'analysis/full-reading'
    paths.extend(base/name for name in ['PROTOCOL-AR.md','STUDY-ASSIGNMENTS.json','local-usage-proposals-root.json','part-a.jsonl','part-b.jsonl','part-c.jsonl','part-a-method.md','part-b-method.md','part-c-method.md'])
    for name in ['studies','systems','reviews']:paths.extend(selected_files(base/name,{'.json','.jsonl'} if name=='reviews' else {'.json'}))
    paths.extend(ROOT/item['path'] for item in export['outputs'])
    reports=['full-reading-verification.json','concept-study-verification.json','independent-review-verification.json','full-reading-build.json','semantic-artifact-build.json','semantic-export-verification.json','semantic-ui-verification.json','semantic-visual-review.json','network-snapshot-guard-verification.json','github-publication.json']
    paths.extend(ROOT/'reports'/name for name in reports)
    paths.extend((ROOT/'reports').glob('semantic-*.png'))
    paths=sorted(set(paths));assert all(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT.resolve()) and not any(x.startswith('.') for x in p.relative_to(ROOT).parts) for p in paths)
    manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha(source),'semanticScope':'All-source written reading with bounded independently reviewed studies/systems, not unique or exhaustive interpretation.','userAcceptance':'not_assumed','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]}
    mp=ROOT/'reports/semantic-delivery-manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');paths.append(mp)
    target=ROOT/'حزمة-التوأم-المعرفي-الدلالي.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in paths:z.write(p,p.relative_to(ROOT))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for item in manifest['files']:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
    result={'package':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'verifiedFiles':len(paths)}
    (ROOT/'reports/semantic-package-checksum.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
