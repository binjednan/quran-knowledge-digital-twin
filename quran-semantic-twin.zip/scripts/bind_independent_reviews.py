#!/usr/bin/env python3
"""Bind explicit independent acceptance to the exact reviewed content, not new claims."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
assignment_data=json.loads((ROOT/'analysis/full-reading/STUDY-ASSIGNMENTS.json').read_text())
assignment=assignment_data['assignments']
owners={cid:author for author,ids in assignment.items() for cid in ids}
owners.update(assignment_data['systemAuthors'])
def sha(x):return hashlib.sha256(json.dumps({k:v for k,v in x.items() if k not in ['reviewStatus','independentReview']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def refs(x):
    if isinstance(x,dict):
        for k,v in x.items():
            if k in ['refs','evidence','allReferences','references','nearContext','coreVerbReferences','comparisonOnlyVerbReferences'] and isinstance(v,list):yield from (r for r in v if isinstance(r,str) and ':' in r)
            elif k not in ['independentReview']:yield from refs(v)
    elif isinstance(x,list):
        for v in x:yield from refs(v)
counts={'bound':0,'alreadyCurrent':0,'unresolved':0,'stale':0};details=[]
for report in sorted((ROOT/'analysis/full-reading/reviews').glob('*.json')):
    r=json.loads(report.read_text());cid=r.get('id')
    if not cid or not r.get('contentSha256'):continue
    p=ROOT/f'analysis/full-reading/studies/{cid}.json'
    if not p.exists():p=ROOT/f'analysis/full-reading/systems/{cid}.json'
    if not p.exists():continue
    s=json.loads(p.read_text());actual=sha(s);reviewer=r.get('reviewer','').removeprefix('/root/')
    if r.get('status')!='accepted_as_scoped':counts['unresolved']+=1;details.append({'id':cid,'status':r.get('status')});continue
    if actual!=r['contentSha256']:counts['stale']+=1;details.append({'id':cid,'status':'stale_review'});continue
    owner=owners.get(cid)
    if not owner:raise SystemExit('Missing declared author: '+cid)
    if owner==reviewer:raise SystemExit('Review is not independent: '+cid)
    if not set(refs(s))<=set(r.get('reviewedEvidence',[])):
        counts['unresolved']+=1;details.append({'id':cid,'status':'review_evidence_incomplete','missing':sorted(set(refs(s))-set(r.get('reviewedEvidence',[])))});continue
    if s.get('reviewStatus')=='independently_reviewed_as_scoped' and s.get('independentReview',{}).get('contentSha256')==actual:counts['alreadyCurrent']+=1;continue
    s['reviewStatus']='independently_reviewed_as_scoped';s['independentReview']={'reviewer':reviewer,'report':str(report.relative_to(ROOT)),'contentSha256':actual,'status':r['status'],'limits':r.get('acceptanceLimits','Independent scoped reading assessment; not user acceptance or unique final meaning.')}
    p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');counts['bound']+=1
(ROOT/'reports/review-bindings.json').write_text(json.dumps({'counts':counts,'details':details,'policy':'Only explicit current-content acceptance is bound; unresolved or stale findings remain visible.'},ensure_ascii=False,indent=2))
print(json.dumps({'counts':counts,'details':details},ensure_ascii=False))
