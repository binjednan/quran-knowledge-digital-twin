/* Focused interaction, responsive layout and sampled accessibility checks.
   This is not a full WCAG, VoiceOver, Safari or physical-device certification. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||path.join(require('node:os').homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
const ROOT=path.resolve(__dirname,'..'),artifact=path.join(ROOT,'التوأم-المعرفي-للقرآن-الدلالي.html'),out=path.join(ROOT,'reports');
const checks=[],layout=[],contrastSamples=[],targetSamples=[],errors=[],networkRequests=[];let context;
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function check(name,ok,detail){checks.push({name,passed:!!ok,detail});assert.ok(ok,name+': '+(typeof detail==='string'?detail:JSON.stringify(detail||'')));}
function luminance(rgb){return rgb.slice(0,3).map(n=>n/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4).reduce((s,n,i)=>s+n*[.2126,.7152,.0722][i],0);}
function ratio(fg,bg){const a=luminance(fg),b=luminance(bg);return (Math.max(a,b)+.05)/(Math.min(a,b)+.05);}
async function inspectTextContrast(page,theme){
 const samples=await page.evaluate(()=>{
  const rgba=s=>{const m=s.match(/[\d.]+/g);if(!m)return[0,0,0,0];const ns=m.map(Number);if(s.startsWith('color(srgb'))return ns.slice(0,3).map(n=>n*255).concat(ns[3]??1);return ns;};
  const blend=(f,b)=>{const a=f[3]??1;return [0,1,2].map(i=>f[i]*a+b[i]*(1-a)).concat(1);};
  const visible=el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!el.closest('[hidden],details:not([open])>*:not(summary)');};
  const selectors=['.page-head h2','.page-head p','.eyebrow','#nav .nav-button.active','#nav .nav-button:not(.active)','.stat .value','.stat span:not(.value)','.primary','.network-motion-tools button:not(:disabled)','.network-motion-help','.name-pair-list button','.sidebar-note'];
  const results=[];
  for(const selector of selectors){
   const el=[...document.querySelectorAll(selector)].find(visible);if(!el)continue;
   const s=getComputedStyle(el);let bg=[255,255,255,1];const chain=[];for(let n=el;n;n=n.parentElement)chain.unshift(n);
   for(const n of chain)bg=blend(rgba(getComputedStyle(n).backgroundColor),bg);
   const fg=blend(rgba(s.color),bg),size=parseFloat(s.fontSize),weight=parseInt(s.fontWeight,10)||400;
   results.push({selector,text:el.innerText?.trim().slice(0,70),foreground:fg.slice(0,3),background:bg.slice(0,3),fontSize:size,fontWeight:weight,required:size>=24||(size>=18.6667&&weight>=700)?3:4.5});
  }
  return results;
 });
 check('contrast_samples_exist_'+theme,samples.length>=7,{sampleCount:samples.length});
 for(const sample of samples){const actual=ratio(sample.foreground,sample.background);contrastSamples.push({...sample,theme,ratio:actual});check('text_contrast_'+theme+'_'+sample.selector,actual+.015>=sample.required,{ratio:actual,required:sample.required,foreground:sample.foreground,background:sample.background});}
}
async function focusWithin(page,selector){return page.evaluate(selector=>document.querySelector(selector)?.contains(document.activeElement),selector);}
async function navigate(page,route){await page.evaluate(route=>QuranTwin.navigate(route),route);await page.waitForFunction(route=>QuranTwin.state.page===route,route);}
async function inspectRelationKey(page,theme){
 await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
 await navigate(page,'semantic');
 await page.selectOption('#semanticPolarity','نقل قول');
 const sample=await page.evaluate(()=>{
  const key=document.querySelector('#semantic-type-quote');
  const legendLine=key.querySelector('line');
  const sceneLine=document.querySelector('.semantic-edge[data-relation-kind="نقل قول"] .semantic-edge-line');
  const keyStyle=getComputedStyle(key);
  const legendStyle=getComputedStyle(legendLine);
  const sceneStyle=getComputedStyle(sceneLine);
  const rgb=value=>value.match(/[\d.]+/g).slice(0,3).map(Number);
  return {
   fg:rgb(keyStyle.color),bg:rgb(keyStyle.backgroundColor),
   sameEncoding:legendStyle.stroke===sceneStyle.stroke&&legendStyle.strokeDasharray===sceneStyle.strokeDasharray,
   distinctPatterns:new Set([...document.querySelectorAll('.semantic-key-list line')].map(line=>getComputedStyle(line).strokeDasharray)).size
  };
 });
 check('selected_relation_key_contrast_'+theme,ratio(sample.fg,sample.bg)>=4.5,sample);
 check('relation_key_matches_scene_'+theme,sample.sameEncoding&&sample.distinctPatterns===6,sample);
 await page.selectOption('#semanticPolarity','');
}
async function scaleText(page){await page.evaluate(()=>{
 const els=[...document.querySelectorAll('body *')].filter(el=>!el.closest('svg')&&!['SCRIPT','STYLE','OPTION'].includes(el.tagName));
 for(const el of els)if(el.dataset.a11yOriginalFont!==undefined){const prior=JSON.parse(el.dataset.a11yOriginalFont);if(prior.value)el.style.setProperty('font-size',prior.value,prior.priority);else el.style.removeProperty('font-size');delete el.dataset.a11yOriginalFont;}
 const samples=els.map(el=>({el,size:parseFloat(getComputedStyle(el).fontSize),original:{value:el.style.getPropertyValue('font-size'),priority:el.style.getPropertyPriority('font-size')}}));
 for(const {el,size,original} of samples){el.dataset.a11yOriginalFont=JSON.stringify(original);el.style.setProperty('font-size',size*2+'px','important');}
 });}
async function layoutBox(page){return page.evaluate(()=>{
 const textOffending=[],walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(walker.nextNode()){const t=walker.currentNode,el=t.parentElement;if(!t.textContent.trim()||!el||el.closest('script,style,option,svg,.sr-only'))continue;const range=document.createRange();range.selectNodeContents(t);for(const rect of range.getClientRects())if(rect.width>0&&(rect.left < -1||rect.right > innerWidth+1)){textOffending.push({text:t.textContent.trim().slice(0,90),tag:el.tagName,id:el.id,class:el.className,left:rect.left,right:rect.right,fontSize:getComputedStyle(el).fontSize});break;}if(textOffending.length>=12)break;}
 return{scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth,textOffending,offending:[...document.querySelectorAll('body *')].filter(el=>!el.closest('svg')).map(el=>({el,rect:el.getBoundingClientRect()})).filter(({rect})=>rect.width>0&&(rect.left < -1||rect.right > innerWidth+1)).slice(0,12).map(({el,rect})=>({tag:el.tagName,id:el.id,class:el.className,left:rect.left,right:rect.right,width:rect.width,text:el.innerText?.slice(0,80)}))};
 });}
async function report(status,exception){
 const uiFiles=['ui/app.js','ui/template.html','ui/full-reading.js','ui/names-network.js','ui/network-motion.js','ui/style.css','ui/full-reading.css','ui/names-network.css','ui/network-motion.css','ui/workbench.js','ui/workbench.css'].filter(p=>fs.existsSync(path.join(ROOT,p)));
 const result={status,testedAt:new Date().toISOString(),artifactSha256:sha(artifact),inputSha256:Object.fromEntries([...uiFiles,'scripts/test_ui_redesign.cjs'].map(p=>[p,sha(path.join(ROOT,p))])),checks,layout,contrastSamples,targetSamples,errors,networkRequests,exception,
  scope:'فحوص تفاعلية للبحث والتنقل والعرض الموسع والتركيز، وإعادة تدفق الصفحات، وأهداف لمس رئيسية، وعينات تباين نصي في الوضعين الفاتح والداكن.',
  limits:'Chrome معزول فقط بأحجام CSS معلنة. اختبار تكبير النص إلى200% منفصل عن تكبير المتصفح. عينات التباين تمزج ألوان CSS الصلبة ولا تقيس كل بكسل أو الرسم الكثيف. لم يُختبر VoiceOver أو Safari أو آيفون فعلي، ولا يُدّعى اعتماد WCAG شامل أو اعتماد المستخدم.'};
 fs.writeFileSync(path.join(out,'ui-redesign-accessibility.json'),JSON.stringify(result,null,2)+'\n');return result;
}
(async()=>{
 context=await chromium.launchPersistentContext(path.join(ROOT,'.work/ui-redesign-profile'),{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,viewport:{width:1440,height:1050},locale:'ar-AE',colorScheme:'light'});
 const page=await context.newPage();await page.emulateMedia({reducedMotion:'reduce',colorScheme:'light'});page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(/^https?:/.test(r.url()))networkRequests.push(r.url());});
 await page.goto(pathToFileURL(artifact).href);await page.waitForFunction(()=>window.QuranTwin?.fullReading&&window.QuranTwin?.names);
 await page.evaluate(()=>document.documentElement.dataset.theme='light');
 check('source_hash_retained',await page.evaluate(()=>QuranTwin.DATA.build.sourceSha256==='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'));
 check('arabic_rtl_document',await page.evaluate(()=>document.documentElement.lang==='ar'&&document.documentElement.dir==='rtl'));
 check('desktop_sidebar_visible',await page.locator('#appSidebar').isVisible());
 await page.locator('#nav [data-page="names"]').click();check('desktop_navigation_opens_names',await page.evaluate(()=>QuranTwin.state.page==='names'));
 await inspectTextContrast(page,'light');
 await navigate(page,'reading');await navigate(page,'semantic');await page.goBack();await page.waitForFunction(()=>QuranTwin.state.page==='reading');check('browser_back_restores_route',await page.locator('#nav [data-page="reading"]').getAttribute('aria-current')==='page');await page.goForward();await page.waitForFunction(()=>QuranTwin.state.page==='semantic');check('browser_forward_restores_route',await page.locator('#nav [data-page="semantic"]').getAttribute('aria-current')==='page');
 await page.goto(pathToFileURL(artifact).href+'#reading');await page.waitForFunction(()=>window.QuranTwin?.state.page==='reading');check('direct_reading_hash_route',await page.locator('#readingSurah').count()===1);

 // Search modal: keyboard invocation, focus containment, verse navigation and safe empty state.
 await page.locator('#globalSearchButton').focus();await page.keyboard.press('Enter');check('search_opens_by_keyboard',await page.locator('#searchDialog').evaluate(d=>d.open));check('search_input_gets_focus',await page.locator('#globalSearchInput').evaluate(el=>el===document.activeElement));
 for(let i=0;i<10;i++)await page.keyboard.press('Tab');check('search_tab_stays_in_dialog',await focusWithin(page,'#searchDialog'));
 await page.keyboard.press('Escape');check('search_escape_closes',!(await page.locator('#searchDialog').evaluate(d=>d.open)));check('search_restores_trigger_focus',await page.locator('#globalSearchButton').evaluate(el=>el===document.activeElement));
 await page.keyboard.press('Meta+k');check('command_k_opens_search',await page.locator('#searchDialog').evaluate(d=>d.open));
 await page.fill('#globalSearchInput','٤٩:٦');await page.waitForFunction(()=>document.querySelector('#globalSearchResults')?.textContent.includes('49:6'));await page.locator('#globalSearchInput').press('Enter');
 check('global_search_arabic_reference_opens_evidence',await page.locator('#evidenceDialog').evaluate(d=>d.open)&&(await page.locator('#evidenceBody [data-ref="49:6"]').count())>0);await page.locator('#closeEvidence').click();
 await page.locator('#globalSearchButton').click();await page.fill('#globalSearchInput','موسى');await page.waitForFunction(()=>document.querySelector('#globalSearchResults [data-search-index]')?.textContent.includes('موسى'));check('global_search_name_results',await page.locator('#globalSearchResults').innerText().then(t=>t.includes('موسى')));await page.locator('#globalSearchInput').press('ArrowDown');check('search_arrow_selects_result',await page.evaluate(()=>document.activeElement?.matches('#globalSearchResults [data-search-index]')||!!document.getElementById(document.querySelector('#globalSearchInput')?.getAttribute('aria-activedescendant')||'')));await page.keyboard.press('Enter');check('global_search_name_navigates',await page.evaluate(()=>QuranTwin.state.page==='names'&&!!QuranTwin.state.nameFocus));
 await page.locator('#globalSearchButton').click();await page.fill('#globalSearchInput','zzzxxyy_missing_123');await page.waitForTimeout(180);check('search_empty_state_readable',(await page.locator('#globalSearchResults [data-search-index]').count())===0&&(await page.locator('#globalSearchResults').innerText()).trim().length>5);
 await page.fill('#globalSearchInput','<img src=x onerror="window.__redesignXss=1">');await page.waitForTimeout(180);check('search_does_not_inject_html',await page.evaluate(()=>!window.__redesignXss&&document.querySelectorAll('#globalSearchResults img').length===0));await page.locator('#closeSearch').click();
 await page.locator('#globalSearchButton').click();await page.fill('#globalSearchInput','49:6');await page.locator('#globalSearchInput').press('Enter');check('immediate_enter_uses_current_query',await page.locator('#evidenceDialog').evaluate(d=>d.open)&&(await page.locator('#evidenceBody [data-ref="49:6"]').count())>0);
 await page.keyboard.press('Meta+k');check('search_can_open_above_evidence',await page.locator('#searchDialog').evaluate(d=>d.open));await page.fill('#globalSearchInput','موسى');await page.waitForFunction(()=>document.querySelector('#globalSearchResults [data-search-index]')?.textContent.includes('موسى'));await page.locator('#globalSearchInput').press('Enter');check('new_search_dismisses_old_evidence',!(await page.locator('#evidenceDialog').evaluate(d=>d.open))&&await page.evaluate(()=>QuranTwin.state.page==='names'&&!!QuranTwin.state.nameFocus));

 // Expanded graph must keep a way out and never orphan keyboard focus.
 await navigate(page,'names');
 await page.locator('[data-expand-graph]').first().click();await page.waitForTimeout(80);check('expanded_graph_exists',await page.locator('.chart-shell.graph-expanded').count()===1,await page.evaluate(()=>({activeElement:document.activeElement?.outerHTML?.slice(0,200),openDialogs:[...document.querySelectorAll('dialog[open]')].map(d=>d.id)})));check('expanded_graph_dialog_semantics',await page.locator('.chart-shell.graph-expanded').evaluate(el=>el.getAttribute('role')==='dialog'&&el.getAttribute('aria-modal')==='true'));
 check('expanded_graph_button_state',await page.locator('.graph-expanded [data-expand-graph]').evaluate(el=>el.getAttribute('aria-pressed')==='true'));
 for(let i=0;i<12;i++)await page.keyboard.press('Tab');check('expanded_graph_focus_contained',await focusWithin(page,'.graph-expanded'));
 await page.keyboard.press('Escape');check('expanded_graph_escape_closes',await page.locator('.graph-expanded').count()===0);check('expanded_graph_focus_restored',await page.evaluate(()=>document.activeElement?.matches('[data-expand-graph]')));
 const panMenu=page.locator('.motion-pan-menu').first();await panMenu.locator('summary').click();check('pan_menu_opens',await panMenu.evaluate(el=>el.open));const pan=page.locator('[data-motion-action="left"]').first();const before=await page.evaluate(()=>QuranNetworkMotion.getController(document.querySelector('#namesGraph')).getState());await pan.click();const after=await page.evaluate(()=>QuranNetworkMotion.getController(document.querySelector('#namesGraph')).getState());check('single_pointer_pan_alternative',after.panX!==before.panX||after.panY!==before.panY);await panMenu.locator('summary').click();await page.locator('#namesGraph').focus();await page.keyboard.press('ArrowLeft');const keyboardPan=await page.evaluate(()=>QuranNetworkMotion.getController(document.querySelector('#namesGraph')).getState());check('keyboard_pan_matches_button_direction',(keyboardPan.panX-after.panX)*(after.panX-before.panX)>0);
 await page.locator('[data-name-edge]').first().focus();await page.keyboard.press('Enter');check('evidence_dialog_keyboard',await page.locator('#evidenceDialog').evaluate(d=>d.open));await page.keyboard.press('Escape');check('evidence_escape_restores_connected_focus',await page.evaluate(()=>!document.querySelector('#evidenceDialog').open&&document.activeElement?.isConnected&&document.activeElement!==document.body));

 // Responsive content reflow and initial graphic access across desktop/tablet/phone widths.
 for(const width of [320,390,768,1440,1920]){
  await page.setViewportSize({width,height:width<800?844:1080});
  for(const route of ['home','names','reading','semantic','word','model']){
   await navigate(page,route);const sample=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth,header:document.querySelector('.masthead').getBoundingClientRect().height}));layout.push({width,route,...sample});check('reflow_'+width+'_'+route,sample.scroll<=sample.client+1,sample);
   if(width===1440){const duplicateIds=await page.evaluate(()=>{const counts=new Map();for(const el of document.querySelectorAll('[id]'))counts.set(el.id,(counts.get(el.id)||0)+1);return[...counts].filter(([,n])=>n>1).map(([id])=>id);});check('unique_ids_'+route,duplicateIds.length===0,duplicateIds);}
  }
  if(width===390){
   await navigate(page,'names');check('mobile_nav_initially_closed',await page.locator('#navToggle').getAttribute('aria-expanded')==='false');await page.locator('#navToggle').click();check('mobile_nav_opens',await page.locator('#navToggle').getAttribute('aria-expanded')==='true');check('mobile_sidebar_modal_semantics',await page.locator('#appSidebar').evaluate(el=>el.getAttribute('role')==='dialog'&&el.getAttribute('aria-modal')==='true'));
   for(let i=0;i<12;i++)await page.keyboard.press('Tab');check('mobile_nav_focus_contained',await focusWithin(page,'#appSidebar'));
   await page.keyboard.press('Escape');check('mobile_nav_escape_restores_trigger',await page.locator('#navToggle').getAttribute('aria-expanded')==='false'&&await page.locator('#navToggle').evaluate(el=>el===document.activeElement));
   await page.locator('#navToggle').click();await page.locator('#navClose').click();check('mobile_nav_close_button',await page.locator('#navToggle').getAttribute('aria-expanded')==='false');
   await page.locator('#navToggle').click();const backdropBox=await page.locator('#navBackdrop').boundingBox();await page.locator('#navBackdrop').click({position:{x:5,y:Math.min(400,backdropBox.height/2)}});check('mobile_nav_backdrop_close',await page.locator('#navToggle').getAttribute('aria-expanded')==='false');
   await page.locator('#navToggle').click();await page.locator('#nav [data-page="reading"]').click();check('mobile_nav_selection_closes_menu',await page.locator('#navToggle').getAttribute('aria-expanded')==='false'&&await page.evaluate(()=>QuranTwin.state.page==='reading'));
   await navigate(page,'names');const advanced=page.locator('#nameAdvancedFilters');check('advanced_filters_available',await advanced.count()===1);await advanced.locator('summary').click();check('advanced_filters_toggle',await advanced.evaluate(el=>el.open));await advanced.locator('summary').click();
   const samples=await page.evaluate(()=>[...document.querySelectorAll('#navToggle,#globalSearchButton,#themeToggle,.network-motion-tools button,.name-pair-list button')].filter(el=>{const r=el.getBoundingClientRect();return r.width&&r.height&&!el.disabled;}).map(el=>({id:el.id||el.dataset.motionAction||el.getAttribute('aria-label')||el.innerText.slice(0,30),width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height})));
   targetSamples.push(...samples);check('main_mobile_touch_targets_44px',samples.length>=8&&samples.every(s=>s.width>=43.5&&s.height>=43.5),samples.filter(s=>s.width<43.5||s.height<43.5));
   const musa=await page.evaluate(()=>QuranTwin.names.NN.nodes.find(n=>n.label==='موسى').id);await page.selectOption('#nameFocus',musa);await page.screenshot({path:path.join(out,'ui-redesign-mobile-names.png'),fullPage:true});await page.locator('.names-chart').screenshot({path:path.join(out,'ui-redesign-mobile-chart.png')});
  }
 }
 await page.setViewportSize({width:1440,height:1050});await navigate(page,'names');await page.screenshot({path:path.join(out,'ui-redesign-desktop-names.png'),fullPage:true});
 await page.evaluate(()=>document.documentElement.dataset.theme='dark');await inspectTextContrast(page,'dark');await page.screenshot({path:path.join(out,'ui-redesign-dark-names.png'),fullPage:true});
 await inspectRelationKey(page,'dark');await inspectRelationKey(page,'light');
 await page.evaluate(()=>document.documentElement.dataset.theme='light');await navigate(page,'home');await page.screenshot({path:path.join(out,'ui-redesign-desktop-home.png'),fullPage:true});
 await page.locator('[data-overview-pair]').first().click();check('overview_pair_opens_source_evidence',await page.locator('#evidenceDialog').evaluate(dialog=>dialog.open)&&await page.locator('#evidenceBody .ayah-card').count()>0);await page.locator('#closeEvidence').click();
 await navigate(page,'method');check('interface_references_have_direct_links',await page.locator('#designReferences article').count()===4&&await page.locator('#designReferences a[href^="https://neo4j.com/"]').count()===2);
 // Text-only scaling: restore any prior pass, snapshot each computed font, then apply exactly 2x.
 for(const width of [390,1440]){await page.setViewportSize({width,height:1050});for(const route of ['home','names','reading']){await navigate(page,route);await scaleText(page);const box=await layoutBox(page);check('text_200pct_reflow_'+width+'_'+route,box.scroll<=box.client+1,box);const target=page.locator('#view button:visible,#view select:visible,#view input:visible').first();await target.evaluate(el=>{el.scrollIntoView({block:'start'});el.focus();});const visibility=await target.evaluate(el=>({top:el.getBoundingClientRect().top,bottom:el.getBoundingClientRect().bottom,headerBottom:document.querySelector('.masthead').getBoundingClientRect().bottom}));check('text_200pct_focus_not_obscured_'+width+'_'+route,visibility.bottom>visibility.headerBottom+1,visibility);}}
 check('no_javascript_errors',errors.length===0,errors);check('no_external_runtime_requests',networkRequests.length===0,networkRequests);
 const result=await report('passed');console.log(JSON.stringify({status:result.status,checks:checks.length,contrastSamples:contrastSamples.length,layoutCases:layout.length,errors:errors.length}));
})().catch(async e=>{await report('failed',String(e));console.error(e);process.exitCode=1;}).finally(async()=>{if(context)await context.close();});
