#!/usr/bin/env python3
"""Index authored readings while preserving quotation, voice, negation and scope."""
from pathlib import Path
from collections import defaultdict,Counter
import argparse,datetime,hashlib,json,subprocess

ROOT=Path(__file__).resolve().parents[1]
def load(path):return json.loads((ROOT/path).read_text())
def dump(path,value):
    path=ROOT/path;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')))
def digest(value):return hashlib.sha256(value.encode()).hexdigest()[:20]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--draft',action='store_true');args=parser.parse_args()
    subprocess.run(['python3',str(ROOT/'scripts/verify_full_reading.py')]+([] if args.draft else ['--require-complete']),check=not args.draft)
    report=load('reports/full-reading-verification.json')
    if not args.draft and report['status']!='structurally_complete':raise SystemExit('Full source and candidate coverage required')
    corpus=load('quran-uthmani-numbered-ayahs.json')
    ayahs={f"{s['number']}:{a['number']}":a['text'] for s in corpus['surahs'] for a in s['ayahs']}
    domains=load('analysis/combined.json')['domains'];concepts={c['id']:c for d in domains for c in d['concepts']}
    dependencies=['quran-uthmani-numbered-ayahs.json','analysis/combined.json','scripts/build_full_reading.py','scripts/verify_full_reading.py']
    units=[];input_shas={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in dependencies}
    for path in sorted((ROOT/'analysis/full-reading').glob('part-*.jsonl')):
        input_shas[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        units.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    units.sort(key=lambda u:(u['surah'],u['start']))
    unit_index={};usage_index=defaultdict(list);lens_index=defaultdict(list);nodes={};edges=[];mentions=[]
    def node(label):
        key=digest(label)
        if key not in nodes:nodes[key]={'id':key,'label':label,'kind':'authored_label_group','evidence':set(),'units':set(),'incidentRelations':0}
        return nodes[key]
    for unit in units:
        for n in range(unit['start'],unit['end']+1):unit_index[f"{unit['surah']}:{n}"]=unit['id']
        for i,usage in enumerate(unit.get('seedUsages',[])):
            for ref in usage.get('refs',[]):usage_index[usage['conceptId']].append({'ref':ref,'unit':unit['id'],'usageIndex':i,'usage':usage['usage'],'confidence':usage['confidence'],'limits':usage['limits'],'authoringStatus':usage.get('authoringStatus','not_explicitly_tagged')})
        for lens in unit.get('lenses',[]):
            lid=lens['id'] if isinstance(lens,dict) else lens
            lens_index[lid].append({'unit':unit['id'],'annotation':lens})
        for concept in unit.get('concepts',[]):
            n=node(concept['label']);n['units'].add(unit['id']);n['evidence'].update(concept.get('evidence',[]))
            mentions.append({'unit':unit['id'],'labelId':n['id'],'localRole':concept.get('role',''),'evidence':concept.get('evidence',[])})
        for i,relation in enumerate(unit.get('relations',[])):
            a=node(relation['source']);b=node(relation['target'])
            for n in [a,b]:n['units'].add(unit['id']);n['evidence'].update(relation['evidence']);n['incidentRelations']+=1
            edges.append({'id':f"{unit['id']}::r{i}",'unit':unit['id'],'source':a['id'],'target':b['id'],**{k:v for k,v in relation.items() if k not in ['source','target']},'sourceLabel':relation['source'],'targetLabel':relation['target']})
    # Structural metrics are over literal authored labels, never an importance doctrine.
    neighbors=defaultdict(set);out=Counter();inc=Counter()
    for edge in edges:
        neighbors[edge['source']].add(edge['target']);neighbors[edge['target']].add(edge['source'])
        out[edge['source']]+=1;inc[edge['target']]+=1
    for n in nodes.values():
        n['evidence']=sorted(n['evidence'],key=lambda r:tuple(map(int,r.split(':'))));n['units']=sorted(n['units'])
        n['degree']=len(neighbors[n['id']]);n['outgoingRecords']=out[n['id']];n['incomingRecords']=inc[n['id']]
    authored_studies={}
    for path in sorted((ROOT/'analysis/full-reading/studies').glob('*.json')):
        study=json.loads(path.read_text());authored_studies[study['id']]=study;input_shas[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    reviews={};unit_hashes={u['id']:hashlib.sha256(json.dumps(u,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest() for u in units}
    for path in sorted((ROOT/'analysis/full-reading/reviews').glob('*.jsonl')):
        input_shas[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        for line in path.read_text().splitlines():
            if line.strip():
                review=json.loads(line)
                review['unitId']=review.get('unitId',review.get('id'))
                review['unitSha256']=review.get('unitSha256',review.get('contentSha256'))
                if not review['unitId']:raise SystemExit('Review record without a unit id: '+str(path))
                previous=reviews.get(review['unitId'])
                current=review['unitSha256']==unit_hashes.get(review['unitId'])
                previous_current=previous and previous.get('unitSha256')==unit_hashes.get(review['unitId'])
                # An explicit same-reader follow-up supersedes its original finding,
                # even when the correction was saved before the first record's hash.
                followup=bool(review.get('supersedes'))
                previous_followup=bool(previous and previous.get('supersedes'))
                if current and previous_current and review.get('status')!=previous.get('status') and not (followup or previous_followup):
                    if not args.draft:raise SystemExit('Conflicting current-content reviews without resolution: '+review['unitId'])
                if current and (not previous_current or followup or not previous_followup):reviews[review['unitId']]=review
                elif not current and not previous_current:reviews[review['unitId']]=review
    if not args.draft:
        for unit in units:
            review=reviews.get(unit['id'])
            if not review or review.get('status')!='accepted_as_scoped':raise SystemExit('Independent reading review missing or unresolved: '+unit['id'])
            if review.get('sourceSha256')!=report['sourceSha256']:raise SystemExit('Review source hash missing/stale: '+unit['id'])
            canonical=json.dumps(unit,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
            if review.get('unitSha256')!=hashlib.sha256(canonical).hexdigest():raise SystemExit('Unit changed after independent review: '+unit['id'])
            expected={f"{unit['surah']}:{a}" for a in range(unit['start'],unit['end']+1)}
            if not expected.issubset(review.get('reviewedEvidence',[])):raise SystemExit('Review does not cover full unit: '+unit['id'])
        missing_studies=set(concepts)-set(authored_studies)
        if missing_studies:raise SystemExit('Comparative studies remain: '+','.join(sorted(missing_studies)))
        for cid,study in authored_studies.items():
            if study.get('reviewStatus')!='independently_reviewed_as_scoped':raise SystemExit('Study peer review remains: '+cid)
            canonical={k:v for k,v in study.items() if k not in ['reviewStatus','independentReview']}
            content_sha=hashlib.sha256(json.dumps(canonical,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            if study.get('independentReview',{}).get('contentSha256')!=content_sha:raise SystemExit('Study changed after independent review: '+cid)
    metadata={'builtAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':report['sourceSha256'],'inputSha256':input_shas,'draft':args.draft,
        'sourceNotice':corpus['derivation'],'sourceMetadata':corpus['metadata'],'verification':report['status'],
        'scope':'Authored reading index. Literal label groups are not proof of semantic identity. Every relation retains its voice, polarity, scope and evidence. Mechanical integrity does not approve semantic entailment.'}
    reading={'metadata':metadata,'coverage':report['counts'],'units':units,'verseToUnit':unit_index,'lensIndex':dict(lens_index),'authoredStudies':authored_studies,'independentReviews':reviews}
    network={'metadata':metadata,'nodes':list(nodes.values()),'edges':edges,'mentions':mentions,'counts':{'labelGroups':len(nodes),'relations':len(edges),'authoredMentions':len(mentions),'polarity':dict(Counter(e['polarity'] for e in edges))},
      'metricsPolicy':'Degree counts distinct literal neighboring labels; incoming/outgoing and incident counts count authored relation records, including quotations, negation and conditions. Neither metric proves entity identity, truth of a quoted assertion, causal influence, or theological/ethical importance.'}
    dump('data/full-reading/reading.json',reading);dump('data/full-reading/network.json',network)
    # Packets are reading aids, explicitly not authored semantic conclusions.
    for cid,concept in concepts.items():
        ref_usages=defaultdict(list)
        for usage in usage_index.get(cid,[]):ref_usages[usage['ref']].append(usage)
        packet={'id':cid,'label':concept['label'],'forms':concept['forms'],'sourceSha256':report['sourceSha256'],'sourceNotice':corpus['derivation']['copyrightNotice'],'sourceWebsite':corpus['derivation']['sourceWebsite'],'priorDefinition':concept['centralMeaning'],
            'purpose':'Source-complete packet for comparative review; not a generated final meaning.',
            'declaredReferences':[{'ref':ref,'text':ayahs[ref],'writtenUnit':unit_index.get(ref),'localReadings':ref_usages.get(ref,[])} for ref in concept['occurrences']],
            'authoredStudy':authored_studies.get(cid),'missingLocalReadingReferences':[ref for ref in concept['occurrences'] if not ref_usages.get(ref)]}
        dump(f'analysis/full-reading/study-packets/{cid}.json',packet)
    dump('reports/full-reading-build.json',{'metadata':metadata,'counts':{'units':len(units),'indexedAyahs':len(unit_index),'relationRecords':len(edges),'labelGroups':len(nodes),'usageEntries':sum(len(x) for x in usage_index.values()),'authoredComparativeStudies':len(authored_studies)},'outputs':['data/full-reading/reading.json','data/full-reading/network.json','analysis/full-reading/study-packets/']})
    print(json.dumps({'draft':args.draft,'units':len(units),'indexedAyahs':len(unit_index),'relations':len(edges),'authoredStudies':len(authored_studies)},ensure_ascii=False))
if __name__=='__main__':main()
