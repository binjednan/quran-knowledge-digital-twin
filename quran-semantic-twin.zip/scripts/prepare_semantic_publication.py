#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage reviewed deliverables in the existing public-repository checkout."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
def load(name):return json.loads((ROOT/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    subprocess.run(['python3',str(ROOT/'scripts/verify_independent_reviews.py'),'--require-complete'],check=True)
    verification=load('reports/independent-review-verification.json')
    assert verification['status']=='current_scoped_reviews_complete',verification['status']
    build=load('reports/semantic-artifact-build.json')
    ui=load('reports/semantic-ui-verification.json')
    names_ui=load('reports/names-network-ui-verification.json');names_verify=load('reports/names-network-verification.json')
    package=load('reports/semantic-package-checksum.json')
    assert not build['draft'] and ui['status']=='passed' and ui['artifactSha256']==build['sha256']
    assert names_ui['status']=='passed' and names_ui['artifactSha256']==build['sha256'] and names_verify['status']=='passed'
    redesign=load('reports/ui-redesign-accessibility.json')
    assert redesign['status']=='passed' and redesign['artifactSha256']==build['sha256']
    for name,digest in redesign['inputSha256'].items():assert sha(ROOT/name)==digest,'Stale interface verification: '+name
    for name,digest in names_verify['inputSha256'].items():assert sha(ROOT/name)==digest,'Stale name verification: '+name
    for snapshot in [load('data/full-reading/reading.json')['metadata'],load('data/full-reading/systems.json')['metadata'],build]:
        for name,digest in snapshot['inputSha256'].items():assert sha(ROOT/name)==digest,'Stale input: '+name
    artifact=ROOT/build['artifact'];archive=ROOT/package['package']
    assert sha(artifact)==build['sha256'] and sha(archive)==package['sha256']
    manifest=load('reports/semantic-delivery-manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert z.read('reports/semantic-delivery-manifest.json')==(ROOT/'reports/semantic-delivery-manifest.json').read_bytes(),'Archive manifest differs'
        for item in manifest['files']:
            assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256'],'Archive member differs: '+item['path']
        required=[build['artifact'],'quran-uthmani-numbered-ayahs.json','data/full-reading/reading.json','data/full-reading/network.json','data/full-reading/systems.json','data/names/network.json','data/names/people-registry.json','data/names/entities-registry.json','exports/quran-semantic-twin.sqlite','exports/quran-semantic-twin.graphml']
        indexed={item['path']:item for item in manifest['files']}
        for name in required:assert name in indexed and sha(ROOT/name)==indexed[name]['sha256'],'Archive is stale: '+name
    source=ROOT/'quran-uthmani-numbered-ayahs.json'
    assert sha(source)=='25554fb91c5b905f3b8ce927271fa62551537dd00e433479f5f4986c7ee38589'
    dest=ROOT/'publication/github';assert (dest/'.git').is_dir(),'Existing checkout required'
    assert sha(dest/source.name)==sha(source),'Published source copy changed'
    shutil.copyfile(artifact,dest/'index.html')
    shutil.copyfile(archive,dest/'quran-semantic-twin.zip')
    counts=verification['counts']
    readme=f'''<div dir="rtl">

# التوأم المعرفي الرقمي للقرآن الكريم

الإصدار الدلالي الثاني: ملف تفاعلي مستقل مبني على النص المرفق وحده،مع النصوص والشواهد والسياقات ودرجات اليقين والأسئلة غير المحسومة. لم تستخدم تفاسير أو معاجم أو مصادر دينية أو تاريخية خارج النص.

- [تنزيل الحزمة الكاملة](quran-semantic-twin.zip): الملف التفاعلي والقراءات والدراسات والمنظومات وقواعد البيانات وسجلات المراجعة وأدوات إعادة البناء.
- [تشغيل الواجهة المحدثة](https://binjednan.github.io/quran-knowledge-digital-twin/): تنقل متكيف للماك والهاتف، وبحث موحد، وشبكات متحركة قابلة للتوسيع، ومرشحات تظهر عند الطلب. مراجع تصميم الواجهة متاحة داخل صفحة المنهج.
- [تشغيل شبكة أسماء الأعلام المتحركة](https://binjednan.github.io/quran-knowledge-digital-twin/#names): كل زوج يرد في الآية نفسها يرتبط بخط وزنه عدد الآيات المشتركة، مع السحب والتكبير وفتح الشواهد وإيقاف الحركة.
- [الملف التفاعلي](index.html): نزله ثم افتحه في المتصفح دون اتصال أو خادم. قد لا يعاين GitHub ملف HTML الكبير مباشرةً؛استخدم زر تنزيل الملف.
- [النص الأصلي](quran-uthmani-numbered-ayahs.json): محفوظ دون تغيير.

## النطاق المنجز

- 114 سورة و6236 آية وفق ترقيم المرفق،ضمن {counts['acceptedCurrentUnitReviews']} مقطع قراءة مكتوب ومراجع.
- {counts['studiesAcceptedCurrent']} دراسة مقارنة لبوابات البحث،و{counts['systemsAcceptedCurrent']} توليفاً للمنظومات المطلوبة.
- {build['relations']} سجل علاقة بشواهده وصوته وقيده،مع فصل الإثبات والنفي والقول والشرط والسؤال والتشبيه.
- خرائط شبكية محلية وعامة،وشجرات مكونات وجسور بين المنظومات،ومصفوفة وخرائط كثافة وتدفق وفهرس لفظي كامل.
- تنقل من المرجع إلى النص والسياق والقراءة والدراسة والشبكة،مع تصدير SQLite وGraphML وJSON داخل الحزمة.

المراجعة مستقلة بين مسارات التحليل الآلية،بسجلات اعتراضات وتصحيحات وبصمات مطابقة للمحتوى. لا تمثل مراجعة بشرية متخصصة أو اعتماد المستخدم. نجحت {len(ui['checks'])+len(names_ui['checks'])+len(redesign['checks'])} فحوص للواجهة والتفاعل والتخطيط وعينات التباين داخل Chrome معزول،بأحجام320 و390 و768 و1440 و1920 بكسل،دون طلبات شبكة خارجية. هذه فحوص محددة النطاق؛لا تمثل اختبار Safari أو آيفون فعلي أو اعتماد وصول شامل.

## حدود الاستنتاج

تغطية الآيات لا تعني استنفاد كل معنى أو كل علاقة ممكنة. الدراسات الثماني والثمانون نطاقات بحث معلنة،وليست معجماً جذرياً كاملاً لكل ألفاظ القرآن. النتائج البحثية قابلة للنقد من شواهدها؛الأسئلة والبدائل ظاهرة داخل الملف. درجات اليقين وصفية وليست نسباً احتمالية.

اشتراك الرسم أو الجذر المفترض لا يثبت وحدة المعنى،والتلازم والدرجة الشبكية لا يثبتان السببية أو الأهمية القيمية. تسميات المنظومات عدسات تنظيمية من طلب المستخدم،والأحداث معروضة بترتيب النص دون تواريخ مستوردة. شاشات الإصدار الأول محفوظة في الأداة للمقارنة وموسومة بحالتها السابقة،وسجل Git يحتفظ بالملف المنشور الأول.

بيانات ناشر المرفق ومكانه وتاريخه محفوظة للإسناد ولا تدخل الاستدلال. يبقى تنبيه المرفق بشأن افتتاح95:1 و97:1 ظاهراً دون تعديل النص.

مصدر النص بحسب المرفق: [Tanzil Project](https://tanzil.net)،والحقوق الواردة محفوظة في [NOTICE.txt](NOTICE.txt) وفي البيانات والأداة. البصمات الكاملة في [SHA256SUMS](SHA256SUMS).

</div>
'''
    (dest/'README.md').write_text(readme)
    names=['.nojekyll','NOTICE.txt','README.md','index.html','quran-semantic-twin.zip',source.name]
    (dest/'SHA256SUMS').write_text(''.join(f'{sha(dest/name)}  {name}\n' for name in names))
    staged={'edition':2,'files':[{'path':name,'bytes':(dest/name).stat().st_size,'sha256':sha(dest/name)} for name in names+['SHA256SUMS']],'status':'locally_staged_not_published'}
    (ROOT/'reports/semantic-publication-staging.json').write_text(json.dumps(staged,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':staged['status'],'files':len(staged['files']),'artifactBytes':artifact.stat().st_size,'packageBytes':archive.stat().st_size}))
if __name__=='__main__':main()
